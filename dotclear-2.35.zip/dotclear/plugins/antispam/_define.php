<?php

/**
 * @file
 * @brief       The plugin antispam definition
 * @ingroup     antispam
 *
 * @defgroup    antispam Plugin antispam.
 *
 * antispam, generic antispam plugin for Dotclear.
 *
 * @package     Dotclear
 *
 * @copyright   Olivier Meunier & Association Dotclear
 * @copyright   AGPL-3.0
 */
$this->registerModule(
    'Antispam',                             // Name
    'Generic antispam plugin for Dotclear', // Description
    'Alain Vagner',                         // Author
    '2.1',                                // Version
    [
        'type'        => 'plugin',
        'permissions' => 'My',
        'priority'    => 10,
        'settings'    => [
            'self' => '',
            'blog' => '#params.antispam_params',
        ],
    ]
);
