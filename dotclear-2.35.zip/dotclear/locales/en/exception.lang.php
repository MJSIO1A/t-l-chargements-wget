<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Site temporarily unavailable'] = '';
L10n::$locales['Bad Request'] = '';
L10n::$locales['Blog handling error'] = '';
L10n::$locales['Application configuration error'] = '';
L10n::$locales['Conflict'] = '';
L10n::$locales['Application context error'] = '';
L10n::$locales['Database connection error'] = '';
L10n::$locales['Not Found'] = '';
L10n::$locales['Precondition Failed'] = '';
L10n::$locales['Application process error'] = '';
L10n::$locales['Session handling error'] = '';
L10n::$locales['Template handling error'] = '';
L10n::$locales['Unauthorized'] = '';
L10n::$locales['Internal Server Error'] = '';
L10n::$locales['<p>This either means that the username and password information in your <strong>config.php</strong> file is incorrect or we can\'t contact the database server at "<em>%1$s</em>". This could mean your host\'s database server is down.</p><ul><li>Are you sure you have the correct username and password?</li><li>Are you sure that you have typed the correct hostname?</li><li>Are you sure that the database server is running?</li></ul><p>If you\'re unsure what these terms mean you should probably contact your host. If you still need help you can always visit the <a href="%2$s">Dotclear Support Forums</a>.</p>'] = '';
L10n::$locales['Dotclear release file is not readable'] = '';
L10n::$locales['Dotclear is not installed or failed to load config file.'] = '';
L10n::$locales['%s cryptographic algorithm configured is not strong enough, please change it.'] = '';
L10n::$locales['%s directory does not exist. Please create it.'] = '';
L10n::$locales['Dotclear release key %s was not found'] = '';
L10n::$locales['Application can not be started twice.'] = '';
L10n::$locales['Unable to load deprecated core'] = '';
L10n::$locales['<p>We apologize for this temporary unavailability.<br>Thank you for your understanding.</p>'] = '';
L10n::$locales['Unable to find class %s'] = '';
L10n::$locales['Unable to initialize class %s'] = '';
