<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['%Y-%m-%d %H:%M'] = '';
L10n::$locales['_Jan'] = 'Jan';
L10n::$locales['_Feb'] = 'Feb';
L10n::$locales['_Mar'] = 'Mar';
L10n::$locales['_Apr'] = 'Apr';
L10n::$locales['_May'] = 'May';
L10n::$locales['_Jun'] = 'Jun';
L10n::$locales['_Jul'] = 'Jul';
L10n::$locales['_Aug'] = 'Aug';
L10n::$locales['_Sep'] = 'Sep';
L10n::$locales['_Oct'] = 'Oct';
L10n::$locales['_Nov'] = 'Nov';
L10n::$locales['_Dec'] = 'Dec';
L10n::$locales['January'] = '';
L10n::$locales['February'] = '';
L10n::$locales['March'] = '';
L10n::$locales['April'] = '';
L10n::$locales['May'] = '';
L10n::$locales['June'] = '';
L10n::$locales['July'] = '';
L10n::$locales['August'] = '';
L10n::$locales['September'] = '';
L10n::$locales['October'] = '';
L10n::$locales['November'] = '';
L10n::$locales['December'] = '';
L10n::$locales['_Mon'] = 'Mon';
L10n::$locales['_Tue'] = 'Tue';
L10n::$locales['_Wed'] = 'Wed';
L10n::$locales['_Thu'] = 'Thu';
L10n::$locales['_Fri'] = 'Fri';
L10n::$locales['_Sat'] = 'Sat';
L10n::$locales['_Sun'] = 'Sun';
L10n::$locales['Monday'] = '';
L10n::$locales['Tuesday'] = '';
L10n::$locales['Wednesday'] = '';
L10n::$locales['Thursday'] = '';
L10n::$locales['Friday'] = '';
L10n::$locales['Saturday'] = '';
L10n::$locales['Sunday'] = '';
