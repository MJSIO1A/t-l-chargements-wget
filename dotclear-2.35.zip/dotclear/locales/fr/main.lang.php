<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['medium'] = 'moyenne';
L10n::$locales['small'] = 'petite';
L10n::$locales['thumbnail'] = 'vignette';
L10n::$locales['square'] = 'carrée';
L10n::$locales['Posts'] = 'Billets';
L10n::$locales['Pages'] = 'Pages';
L10n::$locales['administrator'] = 'administrateur·rice';
L10n::$locales['manage all entries and comments'] = 'gérer toutes les entrées et commentaires';
L10n::$locales['manage their own entries and comments'] = 'gérer ses propres entrées et commentaires';
L10n::$locales['publish entries and comments'] = 'publier des entrées et des commentaires';
L10n::$locales['delete entries and comments'] = 'supprimer des entrées et des commentaires';
L10n::$locales['manage categories'] = 'gérer les catégories';
L10n::$locales['manage all media items'] = 'gérer tous les médias';
L10n::$locales['manage their own media items'] = 'gérer ses propres médias';
L10n::$locales['That user does not exist in the database.'] = 'Cet·te utilisateur·rice n\'existe pas dans la base de données.';
L10n::$locales['That key does not exist in the database.'] = 'Cette clé n\'existe pas dans la base de données.';
L10n::$locales['Title'] = 'Titre';
L10n::$locales['Blogs'] = 'Blogs';
L10n::$locales['Back to blogs list'] = 'Retour à la liste des blogs';
L10n::$locales['Blogs actions'] = 'Actions sur les blogs';
L10n::$locales['Blog id'] = 'Identifiant du blog';
L10n::$locales['Blog name'] = 'Nom du blog';
L10n::$locales['Status'] = 'État';
L10n::$locales['Delete'] = 'Supprimer';
L10n::$locales['No blog selected'] = 'Pas de blog sélectionné';
L10n::$locales['Selected blogs have been successfully updated.'] = 'Les blogs sélectionnés ont été modifiées.';
L10n::$locales['Password verification failed'] = 'La vérification du mot de passe a échoué';
L10n::$locales['The current blog cannot be deleted.'] = 'Le blog courant ne peut être détruit.';
L10n::$locales['%d blog has been successfully deleted'] = [
	'%d blog a été supprimé',
	'Les %d blogs ont été supprimés',
];
L10n::$locales['Comments'] = 'Commentaires';
L10n::$locales['Back to comments list'] = 'Retour à la liste des commentaires';
L10n::$locales['Comments actions'] = 'Action sur les commentaires';
L10n::$locales['Author'] = 'Auteur·rice';
L10n::$locales['Blocklist IP'] = 'Ajouter en liste de blocage';
L10n::$locales['Blocklist IP (global)'] = 'Ajouter en liste de blocage (pour tous les blogs)';
L10n::$locales['IP address'] = 'Adresse IP';
L10n::$locales['No comment selected'] = 'Aucun commentaire sélectionné.';
L10n::$locales['Selected comments have been successfully updated.'] = 'Les publications sélectionnées ont été modifiées.';
L10n::$locales['Selected comments have been successfully deleted.'] = 'Les commentaires sélectionnés ont été supprimés.';
L10n::$locales['IP addresses for selected comments have been blocklisted.'] = 'Les adresses IP des commentaires sélectionnés ont été ajoutées en liste de blocage.';
L10n::$locales['Back to entries list'] = 'Retour à la liste des entrées';
L10n::$locales['Posts actions'] = 'Action sur les publications';
L10n::$locales['First publication'] = 'Première publication';
L10n::$locales['Never published'] = 'Jamais publié';
L10n::$locales['Already published'] = 'Déjà publié';
L10n::$locales['Mark'] = 'Marquer';
L10n::$locales['Mark as selected'] = 'Sélectionner';
L10n::$locales['Mark as unselected'] = 'Désélectionner';
L10n::$locales['Change'] = 'Changer';
L10n::$locales['Change category'] = 'Changer la catégorie';
L10n::$locales['Change language'] = 'Changer la langue';
L10n::$locales['Change author'] = 'Changer l\'auteur·rice';
L10n::$locales['No entry selected'] = 'Aucune publication sélectionnée';
L10n::$locales['Published entries cannot be set to scheduled'] = 'Les entrées publiées ne peuvent être positionnées au statut programmé';
L10n::$locales['%d entry has been successfully updated to status : "%s"'] = [
	'%d entrée a été positionnée au statut "%s"',
	'%d entrées ont été positionnées au statut "%s"',
];
L10n::$locales['%d entry has been successfully updated as: "%s"'] = [
	'%d entrée a été positionnée au statut "%s"',
	'%d entrées ont été positionnées au statut "%s"',
];
L10n::$locales['%d entry has been successfully marked as selected'] = [
	'%d entrée a été marquée sélectionnée',
	'%d entrées ont été marquées sélectionnées',
];
L10n::$locales['%d entry has been successfully marked as unselected'] = [
	'%d entrée a été marquée désélectionnée',
	'%d entrées ont été marquées désélectionnées',
];
L10n::$locales['%d entry has been successfully deleted'] = [
	'%d entrée a été supprimée',
	'%d entrées ont été supprimées',
];
L10n::$locales['(No cat)'] = '(aucune)';
L10n::$locales['%d entry has been successfully moved to category "%s"'] = [
	'%d entrée a été déplacée dans la catégorie "%s"',
	'%d entrées ont été déplacées dans la catégorie "%s"',
];
L10n::$locales['Change category for this selection'] = 'Changer la catégorie pour cette sélection';
L10n::$locales['Category:'] = 'Catégorie :';
L10n::$locales['Create a new category for the post(s)'] = 'Créer une nouvelle catégorie pour ce(s) billet(s)';
L10n::$locales['Title:'] = 'Titre :';
L10n::$locales['Parent:'] = 'Parent :';
L10n::$locales['Save'] = 'Enregistrer';
L10n::$locales['This user does not exist'] = 'Cet·te utilisateur·rice n\'existe pas';
L10n::$locales['%d entry has been successfully set to user "%s"'] = [
	'%d entrée a été affectée à l\'utilisateur·rice "%s"',
	'%d entrées ont été affectées à l\'utilisateur·rice "%s"',
];
L10n::$locales['Change author for this selection'] = 'Changer l\'auteur·rice pour cette sélection';
L10n::$locales['New author (author ID):'] = 'Nouvel auteur·rice (identifiant utilisateur·rice) :';
L10n::$locales['%d entry has been successfully set to language "%s"'] = [
	'%d entrée mise à jour avec la langue "%s"',
	'%d entrées mises à jour avec la langue "%s"',
];
L10n::$locales['Change language for this selection'] = 'Changer la langue de cette sélection';
L10n::$locales['Entry language:'] = 'Langue de l\'entrée :';
L10n::$locales['Most used'] = 'Plus utilisées';
L10n::$locales['Available'] = 'Disponible';
L10n::$locales['Other'] = 'Autre';
L10n::$locales['Descending'] = 'Décroissant';
L10n::$locales['Ascending'] = 'Croissant';
L10n::$locales['Date'] = 'Date';
L10n::$locales['Category'] = 'Catégorie';
L10n::$locales['Selected'] = 'Sélectionné';
L10n::$locales['Number of comments'] = 'Nombre de commentaires';
L10n::$locales['Number of trackbacks'] = 'Nombre de rétroliens';
L10n::$locales['Entry title'] = 'Titre de l\'entrée';
L10n::$locales['Entry date'] = 'Date de l\'entrée';
L10n::$locales['Spam filter'] = 'Filtre antispam';
L10n::$locales['IP'] = 'IP';
L10n::$locales['Last update'] = 'Dernière mise à jour';
L10n::$locales['Blog ID'] = 'Identifiant du blog';
L10n::$locales['Username'] = 'Identifiant';
L10n::$locales['Last Name'] = 'Nom';
L10n::$locales['First Name'] = 'Prénom';
L10n::$locales['Display name'] = 'Pseudonyme';
L10n::$locales['Number of entries'] = 'Nombre d\'entrées';
L10n::$locales['My favorites'] = 'Mes favoris';
L10n::$locales['My preferences'] = 'Mes préférences';
L10n::$locales['New post'] = 'Nouveau billet';
L10n::$locales['%d post'] = [
	'%d billet',
	'%d billets',
];
L10n::$locales['%d comment'] = [
	'%d commentaire',
	'%d commentaires',
];
L10n::$locales['Search'] = 'Rechercher';
L10n::$locales['Categories'] = 'Catégories';
L10n::$locales['Media manager'] = 'Médiathèque';
L10n::$locales['Blog settings'] = 'Paramètres du blog';
L10n::$locales['Blog appearance'] = 'Apparence du blog';
L10n::$locales['Users'] = 'Utilisateur·rice·s';
L10n::$locales['Plugins management'] = 'Gestion des plugins';
L10n::$locales['Plugins settings'] = 'Réglages des plugins';
L10n::$locales['Languages'] = 'Langues';
L10n::$locales['Global help'] = 'Aide générale';
L10n::$locales['Email:'] = 'Email :';
L10n::$locales['Web site:'] = 'Site web :';
L10n::$locales['Author:'] = 'Auteur·rice :';
L10n::$locales['Type:'] = 'Type :';
L10n::$locales['Comment'] = 'Commentaire';
L10n::$locales['Trackback'] = 'Rétrolien';
L10n::$locales['IP address:'] = 'Adresse IP :';
L10n::$locales['Media type:'] = 'Type de média :';
L10n::$locales['image'] = 'image';
L10n::$locales['text'] = 'texte';
L10n::$locales['audio'] = 'audio';
L10n::$locales['video'] = 'vidéo';
L10n::$locales['Format:'] = 'Format :';
L10n::$locales['Password:'] = 'Mot de passe :';
L10n::$locales['With password'] = 'Avec mot de passe';
L10n::$locales['Without password'] = 'Sans mot de passe';
L10n::$locales['Selected:'] = 'Sélectionné :';
L10n::$locales['Not selected'] = 'Non sélectionné';
L10n::$locales['Attachments:'] = 'Annexes :';
L10n::$locales['With attachments'] = 'Avec annexe(s)';
L10n::$locales['Without attachments'] = 'Sans annexes';
L10n::$locales['Month:'] = 'Mois :';
L10n::$locales['Lang:'] = 'Langue :';
L10n::$locales['Comments:'] = 'Commentaires :';
L10n::$locales['Opened'] = 'Ouverts';
L10n::$locales['Closed'] = 'Fermés';
L10n::$locales['Trackbacks:'] = 'Rétroliens :';
L10n::$locales['Filters'] = 'Filtres';
L10n::$locales['Order by:'] = 'Trier par :';
L10n::$locales['Sort:'] = 'Ordre :';
L10n::$locales['Show'] = 'Afficher';
L10n::$locales['Save current options'] = 'Sauvegarder ces options';
L10n::$locales['Display options'] = 'Options d\'affichage';
L10n::$locales['Show filters and display options'] = 'Afficher les filtres et options d\'affichage';
L10n::$locales['Apply filters and display options'] = 'Appliquer les filtres et options d\'affichage';
L10n::$locales['Search:'] = 'Chercher :';
L10n::$locales['&#171; prev.'] = '&#171; préc.';
L10n::$locales['next &#187;'] = 'suiv. &#187;';
L10n::$locales['No blog'] = 'Pas de blog';
L10n::$locales['No blog matches the filter'] = 'Aucun blog correspondant au filtre';
L10n::$locales['URL'] = 'URL';
L10n::$locales['Entries (all types)'] = 'Entrées (tous types)';
L10n::$locales['%d blog matches the filter.'] = [
	'%d blog correspondant au filtre',
	'%d blogs correspondants au filtre',
];
L10n::$locales['Blogs list'] = 'Liste des blogs';
L10n::$locales['Legend: '] = 'Légende : ';
L10n::$locales['Edit blog settings for %s'] = 'Modifier les paramètres de %s';
L10n::$locales['Edit blog settings'] = 'Modifier les paramètres du blog';
L10n::$locales['Switch to blog %s'] = 'Passer au blog %s';
L10n::$locales['No comments'] = 'Aucun commentaire';
L10n::$locales['No comments or trackbacks matches the filter'] = 'aucun commentaire ou rétrolien ne correspond au filtre';
L10n::$locales['Comment or trackback matching the filter.'] = [
	'Commentaire ou rétrolien correspondant au filtre.',
	'Liste des %s commentaires ou rétroliens correspondants au filtre.',
];
L10n::$locales['List of comments and trackbacks (%s)'] = 'Liste des commentaires et rétroliens (%s)';
L10n::$locales['Type'] = 'Type';
L10n::$locales['Entry'] = 'Entrée';
L10n::$locales['Edit the %1$s from %2$s'] = 'Modifier le %1$s de %2$s';
L10n::$locales['comment'] = 'commentaire';
L10n::$locales['trackback'] = 'rétrolien';
L10n::$locales['Edit'] = 'Modifier';
L10n::$locales['No file matches the filter'] = 'Aucun fichier correspondant au filtre';
L10n::$locales['No file.'] = 'Aucun fichier.';
L10n::$locales['%d file matches the filter.'] = [
	'%d fichier correspondant au filtre',
	'%d fichiers correspondants au filtre',
];
L10n::$locales['Nb of items: %d → %d folder(s) + %d file(s)'] = 'Nb d\'éléments : %d → %d dossier(s) + %d fichier(s)';
L10n::$locales['Nb of items: %d'] = 'Nb d\'éléments : %d';
L10n::$locales['Name'] = 'Nom :';
L10n::$locales['Size'] = 'Taille';
L10n::$locales['Select this file'] = 'Sélectionner ce fichier';
L10n::$locales['Attach this file to entry'] = 'Attacher ce fichier à l\'entrée';
L10n::$locales['Insert this file into entry'] = 'Insérer ce fichier dans l\'entrée';
L10n::$locales['private media'] = 'Média privé';
L10n::$locales['open'] = 'ouvrir';
L10n::$locales['No entry'] = 'Pas de résultat';
L10n::$locales['No entry matches the filter'] = 'Aucun résultat correspondant au filtre';
L10n::$locales['Trackbacks'] = 'Rétroliens';
L10n::$locales['List of %s entry matching the filter.'] = [
	'Liste de l\'entrée correspondant au filtre.',
	'Liste des %s entrées correspondant au filtre.',
];
L10n::$locales['List of entries (%s)'] = 'Liste des entrées (%s)';
L10n::$locales['Protected'] = 'Protégé';
L10n::$locales['Attachments'] = 'Annexes';
L10n::$locales['%d attachment'] = '%d annexe';
L10n::$locales['%d attachments'] = '%d annexes';
L10n::$locales['Select this post'] = 'Sélectionner ce billet';
L10n::$locales['Entries list'] = 'Liste des entrées';
L10n::$locales['No user'] = 'Aucun·e utilisateur·rice';
L10n::$locales['No user matches the filter'] = 'Aucun·e utilisateur·rice correspondant·e au filtre';
L10n::$locales['No. of entries'] = 'Nb d\'entrées';
L10n::$locales['List of %s users match the filter.'] = '%s utilisateur·rice·s correspondent au filtre.';
L10n::$locales['Users list'] = 'Liste des utilisateur·rice·s';
L10n::$locales['admin'] = 'administrateur·rice';
L10n::$locales['superadmin'] = 'Super administrateur·rice';
L10n::$locales['The “No. of entries” column includes all entry types (articles, pages, …) for all blogs in the installation. The link may not be relevant in some contexts'] = 'La colonne "Nb d\'entrées" comprend tous les types d\'entrées (articles, pages, …) pour tous les blogs de l\'installation. Le lien peut ne pas être pertinent dans certains contextes';
L10n::$locales['First page'] = 'Première page';
L10n::$locales['Previous page'] = 'Page précédente';
L10n::$locales['Next page'] = 'Page suivante';
L10n::$locales['Last page'] = 'Dernière page';
L10n::$locales['Page %1$s / %2$s'] = 'Page %1$s / %2$s';
L10n::$locales['Direct access page:'] = 'Aller à la page :';
L10n::$locales['ok'] = 'ok';
L10n::$locales['%s file found'] = [
	'%s fichier trouvé',
	'%s fichiers trouvés',
];
L10n::$locales['Blog'] = 'Blog';
L10n::$locales['System settings'] = 'Réglages système';
L10n::$locales['Plugins'] = 'Plugins';
L10n::$locales['Update'] = 'Mise à jour';
L10n::$locales['other'] = 'autres';
L10n::$locales['Search in repository:'] = 'Rechercher dans le dépôt :';
L10n::$locales['OK'] = 'Ok';
L10n::$locales['Reset search'] = 'réinitialiser la recherche';
L10n::$locales['Search is allowed on multiple terms longer than 2 chars, terms must be separated by space.'] = 'La recherche est autorisée sur plusieurs mots de 2 caractères minimum, séparés par un espace.';
L10n::$locales['Found %d result for search "%s":'] = [
	'%d résultat trouvé pour la recherche "%s" :',
	'%d résultats trouvés pour la recherche "%s" :',
];
L10n::$locales['current selection'] = 'sélection courante';
L10n::$locales['%d result'] = [
	'%d résultat',
	'%d résultats',
];
L10n::$locales['no results'] = 'pas de résultats';
L10n::$locales['Browse index:'] = 'Parcourir l\'index :';
L10n::$locales['Score'] = 'Score';
L10n::$locales['Version'] = 'Version';
L10n::$locales['Current version'] = 'Version courante';
L10n::$locales['Details'] = 'Détails';
L10n::$locales['Repository'] = 'Dépôt';
L10n::$locales['Action'] = 'Action';
L10n::$locales[' (%s)'] = ' (%s)';
L10n::$locales['This module cannot be disabled nor deleted, since the following modules are also enabled : %s'] = 'Ce module ne peut être désactivé ou supprimé car les modules suivants sont actifs : %s';
L10n::$locales['This module cannot be enabled, because of the following reasons :'] = 'Ce module ne peut activé pour les raisons suivantes :';
L10n::$locales['Official repository'] = 'Dépôt officiel';
L10n::$locales['Third-party repository'] = 'Dépôt alternatif';
L10n::$locales['Plugin from official distribution'] = 'Plugin de la distribution officielle';
L10n::$locales['Plugin in development'] = 'Plugin en développement';
L10n::$locales['Release date:'] = 'Date de publication :';
L10n::$locales['Support'] = 'Assistance';
L10n::$locales['update locked'] = 'mise à jour verrouillée';
L10n::$locales['Section:'] = 'Section : ';
L10n::$locales['Tags:'] = 'Mots-clés:';
L10n::$locales['No plugins matched your search.'] = 'Aucun plugin ne correspond à votre recherche.';
L10n::$locales['Plugins list'] = 'Liste des plugins';
L10n::$locales['Configure plugin'] = 'Configurer le plugin';
L10n::$locales['Plugin settings (in blog parameters)'] = 'Réglages du plugin (paramètres du blog)';
L10n::$locales['Plugin settings (in user preferences)'] = 'Réglages du plugin (mes préférences)';
L10n::$locales['Plugin settings'] = 'Réglages du plugin';
L10n::$locales['Plugin main page'] = 'Page principale du plugin';
L10n::$locales['Activate'] = 'Activer';
L10n::$locales['Deactivate'] = 'Désactiver';
L10n::$locales['Clone'] = 'Dupliquer';
L10n::$locales['Install'] = 'Installer';
L10n::$locales['Activate selected plugins'] = 'Activer les plugins sélectionnés';
L10n::$locales['Activate all plugins from this list'] = 'Activer tous les plugins de cette liste';
L10n::$locales['Deactivate selected plugins'] = 'Désactiver les plugins sélectionnés';
L10n::$locales['Deactivate all plugins from this list'] = 'Désactiver tous les plugins de cette liste';
L10n::$locales['Update selected plugins'] = 'Mettre à jour les plugins sélectionnés';
L10n::$locales['Update all plugins from this list'] = 'Mettre à jour tous les plugins de cette liste';
L10n::$locales['No such plugin.'] = 'Plugin inexistant.';
L10n::$locales['You don\'t have permissions to delete this plugin.'] = 'Vous n\'avez pas les permissions pour supprimer ce plugin.';
L10n::$locales['Some plugins have not been delete.'] = 'Certains plugins n\'ont pas pu être supprimés.';
L10n::$locales['Plugin has been successfully deleted.'] = [
	'Ce plugin a été supprimé.',
	'Ces plugins ont été supprimés.',
];
L10n::$locales['Plugin has been successfully installed.'] = [
	'Ce plugin a été installé.',
	'Ces plugins ont été installés.',
];
L10n::$locales['Plugin has been successfully activated.'] = [
	'Ce plugin a été activé.',
	'Ces plugins ont été activés.',
];
L10n::$locales['Some plugins have not been deactivated.'] = 'Certains plugins n\'ont pas pu être désactivés.';
L10n::$locales['Plugin has been successfully deactivated.'] = [
	'Ce plugin a été désactivé.',
	'Ces plugins ont été désactivés.',
];
L10n::$locales['Plugin has been successfully updated.'] = [
	'Ce plugin a été mis à jour.',
	'Ces plugins ont été mis à jour.',
];
L10n::$locales['Following plugins updates are locked: %s'] = 'Les mises à jour de plugins suivantes sont verrouillées : %s';
L10n::$locales['Unable to move uploaded file.'] = 'Impossible de déplacer le fichier téléchargé.';
L10n::$locales['The plugin has been successfully updated.'] = 'Ce plugin a été mis à jour.';
L10n::$locales['The plugin has been successfully installed.'] = 'Ce plugin a été installé.';
L10n::$locales['Upload a zip file'] = 'Déposer un fichier zip';
L10n::$locales['Fields preceded by %s are mandatory.'] = 'Les champs précédés de %s sont obligatoires.';
L10n::$locales['Zip file path:'] = 'Chemin du fichier zip :';
L10n::$locales['Password'] = 'Mot de passe';
L10n::$locales['Your password:'] = 'Votre mot de passe :';
L10n::$locales['Upload'] = 'Envoyer';
L10n::$locales['Download a zip file'] = 'Télécharger un fichier zip';
L10n::$locales['Zip file URL:'] = 'URL du fichier zip :';
L10n::$locales['Download'] = 'Télécharger';
L10n::$locales['Unknown plugin ID'] = 'ID de plugin inconnu';
L10n::$locales['This plugin has no configuration file.'] = 'Ce plugin n\'a pas de fichier de configuration.';
L10n::$locales['Insufficient permissions'] = 'Permissions insuffisantes';
L10n::$locales['Configure "%s"'] = 'Configurer "%s"';
L10n::$locales['Back'] = 'Retour';
L10n::$locales['Error:'] = 'Erreur :';
L10n::$locales['Errors:'] = 'Erreurs :';
L10n::$locales['%H:%M:%S'] = '%H:%M:%S';
L10n::$locales['Ok'] = 'Ok';
L10n::$locales['Blog:'] = 'Blog :';
L10n::$locales['Change blog'] = 'Changer de blog';
L10n::$locales['Blogs:'] = 'Blogs :';
L10n::$locales['Go to the content'] = 'Aller au contenu';
L10n::$locales['Go to the menu'] = 'Aller au menu';
L10n::$locales['Go to help'] = 'Aller à l\'aide';
L10n::$locales['My dashboard'] = 'Mon tableau de bord';
L10n::$locales['Go to site'] = 'Aller sur le site';
L10n::$locales['Logout %s'] = 'Déconnecter %s';
L10n::$locales['Hide main menu'] = 'Masquer le menu principal';
L10n::$locales['Show main menu'] = 'Afficher le menu principal';
L10n::$locales['Safe mode'] = 'Mode de secours';
L10n::$locales['You are in safe mode. All plugins have been temporarily disabled. Remind to log out then log in again normally to get back all functionalities'] = 'Vous êtes en mode de secours. Tous les plugins ont été temporairement désactivés. N\'oubliez-pas de vous déconnecter puis de vous reconnecter normalement pour retrouver toutes les fonctionnalités';
L10n::$locales['Thank you for using %s.'] = 'Merci d\'utiliser %s.';
L10n::$locales['Page top'] = 'Haut de page';
L10n::$locales['Dotclear logo'] = 'Logo Dotclear';
L10n::$locales['Go to dashboard'] = 'Mon tableau de bord';
L10n::$locales['Help about this page'] = 'Aide à propos de cette page';
L10n::$locales['See also %s'] = 'Voir aussi %s';
L10n::$locales['the global help'] = 'Aide générale';
L10n::$locales['uncover'] = 'récupérer';
L10n::$locales['hide'] = 'cacher';
L10n::$locales['Need help?'] = 'Besoin d\'aide ?';
L10n::$locales['new window'] = 'nouvelle fenêtre';
L10n::$locales['Hide'] = 'Cacher';
L10n::$locales['Select:'] = 'Sélectionner :';
L10n::$locales['No selection'] = 'Pas de sélection';
L10n::$locales['Select all'] = 'Tout sélectionner';
L10n::$locales['Invert selection'] = 'Inverser la sélection';
L10n::$locales['Entry has been successfully created.'] = 'L\'entrée a été créée.';
L10n::$locales['Edit entry'] = 'Éditer l\'entrée';
L10n::$locales['view entry'] = 'voir l\'entrée';
L10n::$locales['Are you sure you want to delete selected entries (%s)?'] = 'Êtes-vous sûr·e de vouloir supprimer les entrées sélectionnées (%s) ?';
L10n::$locales['Are you sure you want to delete selected medias (%d)?'] = 'Êtes-vous sûr·e de vouloir supprimer les médias sélectionnés (%d) ?';
L10n::$locales['Are you sure you want to delete selected categories (%s)?'] = 'Êtes-vous sûr·e de vouloir supprimer les catégories sélectionnées (%s) ?';
L10n::$locales['Are you sure you want to delete this entry?'] = 'Êtes-vous certain·e de vouloir supprimer cette entrée ?';
L10n::$locales['Click here to unlock the field'] = 'Cliquez ici pour déverrouiller le champ';
L10n::$locales['Are you sure you want to delete all spams?'] = 'Êtes-vous certain·e de vouloir supprimer tous les indésirables ?';
L10n::$locales['Are you sure you want to delete selected comments (%s)?'] = 'Êtes-vous sûr·e de vouloir supprimer les commentaires sélectionnés (%s) ?';
L10n::$locales['Are you sure you want to delete this comment?'] = 'Êtes-vous certain·e de vouloir supprimer ce commentaire ?';
L10n::$locales['Users with posts cannot be deleted.'] = 'Une utilisatrice ou un utilisateur avec des publications ne peut être supprimé.';
L10n::$locales['Are you sure you want to delete selected users (%s)?'] = 'Êtes-vous sûr·e de vouloir supprimer les utilisatrices et les utilisateurs sélectionnées (%s) ?';
L10n::$locales['Are you sure you want to delete selected blogs (%s)?'] = 'Êtes-vous sûr·e de vouloir supprimer les blogs sélectionnés (%s) ?';
L10n::$locales['Are you sure you want to delete category "%s"?'] = 'Êtes-vous certain·e de vouloir supprimer la catégorie "%s" ?';
L10n::$locales['Are you sure you want to reorder all categories?'] = 'Êtes-vous sûr·e de vouloir réordonner toutes les catégories ?';
L10n::$locales['Are you sure you want to remove media "%s"?'] = 'Êtes-vous certain·e de vouloir supprimer le média "%s" ?';
L10n::$locales['Are you sure you want to remove directory "%s"?'] = 'Êtes-vous certain·e de vouloir supprimer le répertoire "%s" ?';
L10n::$locales['Are you sure you want to extract archive in current directory?'] = 'Êtes-vous certain·e de vouloir extraire cette archive dans le répertoire courant ?';
L10n::$locales['Are you sure you want to remove attachment "%s"?'] = 'Êtes-vous certain·e de vouloir supprimer l\'annexe "%s" ?';
L10n::$locales['Are you sure you want to delete "%s" language?'] = 'Êtes-vous certain·e de vouloir supprimer la langue "%s" ?';
L10n::$locales['Are you sure you want to delete "%s" plugin?'] = 'Êtes-vous certain·e de vouloir supprimer le plugin "%s" ?';
L10n::$locales['Are you sure you want to delete selected plugins?'] = 'Êtes-vous sûr·e de vouloir supprimer les plugins sélectionnés ?';
L10n::$locales['Use this theme'] = 'Utiliser ce thème';
L10n::$locales['Remove this theme'] = 'Supprimer ce thème';
L10n::$locales['Are you sure you want to delete "%s" theme?'] = 'Êtes-vous certain·e de vouloir supprimer le thème "%s" ?';
L10n::$locales['Are you sure you want to delete selected themes?'] = 'Êtes-vous sûr·e de vouloir supprimer les thèmes sélectionnés ?';
L10n::$locales['Are you sure you want to delete this backup?'] = 'Êtes-vous certain·e de vouloir supprimer cette sauvegarde ?';
L10n::$locales['Are you sure you want to revert to this backup?'] = 'Êtes-vous certain·e de vouloir restaurer cette sauvegarde ?';
L10n::$locales['Zip file content'] = 'Contenu de l\'archive Zip';
L10n::$locales['HTML markup validator'] = 'Validateur HTML';
L10n::$locales['HTML content is valid.'] = 'Le contenu HTML est valide.';
L10n::$locales['There are HTML markup errors.'] = 'Il y a des erreurs de balisage HTML.';
L10n::$locales['Attention: an audit of a content not yet registered.'] = 'Attention : audit d\'un contenu qui n\'est pas encore enregistré.';
L10n::$locales['You have unsaved changes. Switch post format will loose these changes. Proceed anyway?'] = 'Vous avez des modifications non enregistrées. Changer le format de publication va perdre ces modifications. Continuer quand même ?';
L10n::$locales['Warning: post format change will not convert existing content. You will need to apply new format by yourself. Proceed anyway?'] = 'Attention : la modification du format de publication ne convertira pas le contenu existant. Vous devrez appliquer le nouveau format par vous-même. Continuer quand même ?';
L10n::$locales['Loading enhanced uploader, please wait.'] = 'Chargement de l\'interface améliorée, veuillez patienter.';
L10n::$locales['Help:'] = 'Aide :';
L10n::$locales['Show password'] = 'Montrer le mot de passe';
L10n::$locales['Hide password'] = 'Cacher le mot de passe';
L10n::$locales['Reset to now'] = 'Réinitialiser à maintenant';
L10n::$locales['The publication date has changed. Reset the base name of the entry URL?'] = 'La date de publication a été modifiée. Réinitialiser l\'URL spécifique de l\'entrée ?';
L10n::$locales['An ad blocker has been detected on this Dotclear dashboard (Ghostery, Adblock plus, uBlock origin, …) and it may interfere with some features. In this case you should disable it. Note that this detection may be disabled in your preferences.'] = 'Une bloqueur de publicité a été détecté sur ce tableau de bord de Dotclear (Ghostery, Adblock plus, uBlock origin, …) et il peut perturber certaines fonctionnalités. Dans ce cas vous devriez le désactiver. Notez que vous pouvez désactiver cette détection dans vos préférences.';
L10n::$locales['You have unsaved changes.'] = 'Vous avez des modifications non sauvegardées.';
L10n::$locales['your battery charge seems low (%d%) and you have unsaved changes, you should save them.'] = 'la charge de votre batterie semble faible (%d%) et vous avez des modifications non enregistrées, vous devriez les enregistrer.';
L10n::$locales['Temporarily activate enhanced uploader'] = 'Activer temporairement l\'interface avancée de la médiathèque';
L10n::$locales['Temporarily disable enhanced uploader'] = 'Désactiver temporairement l\'interface améliorée';
L10n::$locales['Limit exceeded.'] = 'La limite est dépassée.';
L10n::$locales['File size exceeds allowed limit.'] = 'La taille du fichier dépasse la limite autorisée.';
L10n::$locales['Canceled.'] = 'Annulé.';
L10n::$locales['HTTP Error:'] = 'Erreur HTTP :';
L10n::$locales['Choose file'] = 'Choisir un fichier';
L10n::$locales['Choose files'] = 'Choisir des fichiers';
L10n::$locales['Cancel'] = 'Annuler';
L10n::$locales['Clean'] = 'Vider';
L10n::$locales['Send'] = 'Envoyer';
L10n::$locales['File successfully uploaded.'] = 'Le fichier a été chargé.';
L10n::$locales['No file in queue.'] = 'Aucun fichier en attente.';
L10n::$locales['1 file in queue.'] = '1 fichier en file d\'attente.';
L10n::$locales['%d files in queue.'] = '%d fichiers dans la file d\'attente.';
L10n::$locales['Queue error:'] = 'Erreur de file d\'attente :';
L10n::$locales['Cancel filters and display options'] = 'Annuler les filtres et options d\'affichage';
L10n::$locales['(%s)'] = '(%s)';
L10n::$locales['ratio %.1f'] = 'ratio %.1f';
L10n::$locales['The \'public\' directory does not exist.'] = 'Le répertoire \'public\' n\'existe pas.';
L10n::$locales['The \'%s\' directory cannot be modified.'] = 'Le répertoire %s ne peut pas être modifié.';
L10n::$locales['The \'%s\' directory cannot be created.'] = 'Le répertoire \'%s\' ne peut pas être créé.';
L10n::$locales['At least one of the following functions is not available: imagecreatetruecolor, imagepng & imagecreatefrompng.'] = 'Au moins une des fonctions suivantes n\'est pas disponible : imagecreatetruecolor, imagepng & imagecreatefrompng.';
L10n::$locales['Unable to create images.'] = 'Impossible de créer des images.';
L10n::$locales['Invalid file type.'] = 'Type de fichier invalide.';
L10n::$locales['An error occurred while writing the file.'] = 'Une erreur est survenue pendant l\'écriture du fichier.';
L10n::$locales['Uploaded image is not %s pixels wide.'] = 'L\'image envoyée n\'a pas %s pixels de large.';
L10n::$locales['Score: %s'] = 'Score : %s';
L10n::$locales['%s screenshot.'] = 'Capture d\'écran de %s.';
L10n::$locales['(%s template set)'] = '(jeu de template %s)';
L10n::$locales['by %s'] = 'par %s';
L10n::$locales['version %s'] = 'version %s';
L10n::$locales['released on %s'] = 'publié le %s';
L10n::$locales['(current version %s)'] = '(version courante %s)';
L10n::$locales['(built on "%s")'] = '(basé sur "%s")';
L10n::$locales['(requires "%s")'] = '(nécessite "%s")';
L10n::$locales['Configure theme'] = 'Personnaliser le thème';
L10n::$locales['No themes matched your search.'] = 'Aucun thème ne correspond à votre recherche.';
L10n::$locales['Use this one'] = 'Utiliser celui-ci';
L10n::$locales['Preview'] = 'Prévisualiser';
L10n::$locales['Update selected themes'] = 'Mettre à jour les thèmes selectionnés';
L10n::$locales['Update all themes from this list'] = 'Mettre à jour tous les thèmes de cette liste';
L10n::$locales['No such theme.'] = 'Thème inexistant.';
L10n::$locales['Theme %s has been successfully selected.'] = 'Le thème %s a été sélectionné.';
L10n::$locales['Theme has been successfully activated.'] = [
	'Ce thème a été activé.',
	'Ces thèmes ont été activés.',
];
L10n::$locales['Some themes have not been deactivated.'] = 'Certains thèmes n\'ont pas pu être désactivés.';
L10n::$locales['Theme has been successfully deactivated.'] = [
	'Ce thème a été désactivé.',
	'Ces thèmes ont été désactivés.',
];
L10n::$locales['Theme has been successfully cloned.'] = [
	'Ce thème a été dupliqué.',
	'Ces thèmes ont été dupliqués.',
];
L10n::$locales['You don\'t have permissions to delete this theme.'] = 'Vous n\'avez pas les permissions pour supprimer ce thème.';
L10n::$locales['Some themes have not been delete.'] = 'Certains thèmes n\'ont pas pu être effacés.';
L10n::$locales['Theme has been successfully deleted.'] = [
	'Ce thème a été supprimé.',
	'Ces thèmes ont été supprimés.',
];
L10n::$locales['Theme has been successfully installed.'] = [
	'Ce thème a été installé.',
	'Ces thèmes ont été installés.',
];
L10n::$locales['Theme has been successfully updated.'] = [
	'Ce thème a été mis à jour.',
	'Ces thèmes ont été mis à jour.',
];
L10n::$locales['Following themes updates are locked: %s'] = 'Les mises à jour des thèmes suivants sont verrouillées : %s';
L10n::$locales['The theme has been successfully updated.'] = 'Ce thème a été mis à jour.';
L10n::$locales['The theme has been successfully installed.'] = 'Ce thème a été installé.';
L10n::$locales['users per page'] = 'utilisateur·rice·s par page';
L10n::$locales['posts per page'] = 'billets par page';
L10n::$locales['comments per page'] = 'commentaires par page';
L10n::$locales['blogs per page'] = 'blogs par page';
L10n::$locales['media per page'] = 'médias par page';
L10n::$locales['results per page'] = 'résultats par page';
L10n::$locales['There seems to be no Session table in your database. Is Dotclear completly installed?'] = 'Il semble de la table Session n\'existe pas dans votre base de données. Dotclear est-il bien installé correctement ?';
L10n::$locales['You are not allowed to add categories'] = 'Vous n\'êtes pas autorisé·e à créer des catégories';
L10n::$locales['You are not allowed to update categories'] = 'Vous n\'êtes pas autorisé·e à modifier des catégories';
L10n::$locales['You are not allowed to delete categories'] = 'Vous n\'êtes pas autorisé·e à supprimer des catégories';
L10n::$locales['This category is not empty.'] = 'Cette catégorie n\'est pas vide.';
L10n::$locales['You are not allowed to reset categories order'] = 'Vous n\'êtes pas autorisé·e à réinitialiser l\'ordre des catégories';
L10n::$locales['Empty category URL'] = 'URL de la catégorie vide';
L10n::$locales['You must provide a category title'] = 'Vous devez indiquer un titre de catégorie';
L10n::$locales['You must provide a category URL'] = 'Vous devez indiquer une URL de catégorie';
L10n::$locales['You are not allowed to create an entry'] = 'Vous n\'êtes pas autorisé·e à créer des entrées';
L10n::$locales['You are not allowed to update entries'] = 'Vous n\'êtes pas autorisé·e à modifier les entrées';
L10n::$locales['No such entry ID'] = 'Identifiant d\'entrée inconnu';
L10n::$locales['You are not allowed to edit this entry'] = 'Vous n\'êtes pas autorisé·e à modifier cette entrée';
L10n::$locales['You are not allowed to change this entry status'] = 'Vous n\'êtes pas autorisé·e à modifier l\'état de cette entrée';
L10n::$locales['You are not allowed to change this entry category'] = 'Vous n\'êtes pas autorisé·e à modifier la catégorie de cette entrée';
L10n::$locales['You are not allowed to change entries category'] = 'Vous n\'êtes pas autorisé·e à modifier la catégorie des entrées';
L10n::$locales['You are not allowed to delete entries'] = 'Vous n\'êtes pas autorisé·e à supprimer des entrées';
L10n::$locales['No entry title'] = 'Pas de titre d\'entrée';
L10n::$locales['No entry content'] = 'Pas de contenu d\'entrée';
L10n::$locales['Notes'] = 'Notes';
L10n::$locales['Note'] = 'Note';
L10n::$locales['Empty entry URL'] = 'URL de l\'entrée vide';
L10n::$locales['You are not allowed to update comments'] = 'Vous n\'êtes pas autorisé·e à modifier des commentaires';
L10n::$locales['No such comment ID'] = 'Identifiant de commentaire inconnu';
L10n::$locales['You are not allowed to update this comment'] = 'Vous n\'êtes pas autorisé·e à modifier ce commentaire';
L10n::$locales['You are not allowed to change this comment\'s status'] = 'Vous n\'êtes pas autorisé·e à changer l\'état de ce commentaire';
L10n::$locales['You are not allowed to delete comments'] = 'Vous n\'êtes pas autorisé·e à supprimer des commentaires';
L10n::$locales['You must provide a comment'] = 'Vous devez écrire un commentaire';
L10n::$locales['You must provide an author name'] = 'Vous devez indiquer un nom';
L10n::$locales['Email address is not valid.'] = 'Adresse email invalide.';
L10n::$locales['Unable to retrieve namespaces:'] = 'Impossible d\'obtenir les espaces de nom :';
L10n::$locales['Invalid setting namespace: %s'] = 'Espace de nom du paramètre invalide : %s';
L10n::$locales['Invalid setting dcNamespace: %s'] = 'Espace de nom du paramètre invalide : %s';
L10n::$locales['Unable to retrieve settings:'] = 'Impossible d\'obtenir les paramètres :';
L10n::$locales['%s is not a valid setting id'] = '%s n\'est pas un identifiant de paramètre valide';
L10n::$locales['No namespace specified'] = 'Aucun espace de nom spécifié';
L10n::$locales['You are not an administrator'] = 'Vous n\'êtes pas administrateur·rice';
L10n::$locales['Blog ID must contain at least 2 characters using letters, numbers or symbols.'] = 'L\'identifiant du blog doit contenir au moins 2 caractères composés de lettres, chiffres ou symboles.';
L10n::$locales['No blog name'] = 'Pas de nom de blog';
L10n::$locales['No blog URL'] = 'Pas d\'URL de blog';
L10n::$locales['You must provide a valid email address.'] = 'Vous devez indiquer une adresse e-mail valide.';
L10n::$locales['Something went wrong while trying to read the database.'] = 'Un problème s\'est produit lors de la lecture de la base de données.';
L10n::$locales['Blog is not defined.'] = 'Le blog n\'est pas défini.';
L10n::$locales['This blog is offline. Please try again later.'] = 'Ce blog est hors ligne. Veuillez réessayer plus tard.';
L10n::$locales['This either means you removed your default theme or set a wrong theme path in your blog configuration. Please check theme_path value in about:config module or reinstall default theme. ('] = 'Cela signifie que vous avez supprimé votre thème par défaut ou que vous avez défini un mauvais chemin d\'accès au thème dans la configuration de votre blog. Veuillez vérifier la valeur theme_path dans le module about:config ou réinstallez le thème par défaut. (';
L10n::$locales['Default theme not found.'] = 'Thème par défaut introuvable.';
L10n::$locales['Something went wrong while loading template file for your blog.'] = 'Un problème s\'est produit lors du chargement du fichier modèle de votre blog.';
L10n::$locales['Can\'t create template files.'] = 'Impossible de créer des fichiers modèles.';
L10n::$locales['PHP version is %s (%s or earlier needed).'] = 'La version de PHP est %s (%s ou plus récente nécessaire).';
L10n::$locales['Multibyte string module (mbstring) is not available.'] = 'Le support des chaînes multi-octets (mbstring) n\'est pas disponible.';
L10n::$locales['Iconv module is not available.'] = 'Le module iconv n\'est pas disponible.';
L10n::$locales['Output control functions are not available.'] = 'Les fonctions de bufferisation de sortie ne sont pas disponibles.';
L10n::$locales['SimpleXML module is not available.'] = 'Le module SimpleXML n\'est pas disponible.';
L10n::$locales['DOM XML module is not available.'] = 'Le module DOM XML n\'est pas disponible.';
L10n::$locales['PCRE engine does not support UTF-8 strings.'] = 'Le moteur d\'expressions rationnelles PCRE n\'accepte pas les chaînes UTF-8.';
L10n::$locales['SPL module is not available.'] = 'Le module SPL n\'est pas disponible.';
L10n::$locales['MySQL version is %1$s (%2$s or earlier needed).'] = 'La version de PHP est %1$s (%2$s ou plus récente nécessaire).';
L10n::$locales['MySQL InnoDB engine is not available.'] = 'Le gestionnaire de stockage InnoDB de MySQL n\'est pas disponible.';
L10n::$locales['PostgreSQL version is %s (%s or earlier needed).'] = 'La version de PHP est %s (%s ou plus récente nécessaire).';
L10n::$locales['No log message'] = 'Pas de message dans le journal';
L10n::$locales['No blog defined.'] = 'Aucun blog défini.';
L10n::$locales['You are not a super administrator.'] = 'Vous n\'êtes pas super administrateur·rice.';
L10n::$locales['Permission denied.'] = 'Permission refusée.';
L10n::$locales['You are not the file owner.'] = 'Vous n\'êtes pas le ou la propriétaire de ce fichier.';
L10n::$locales['This file is not allowed.'] = 'Ce fichier n\'est pas autorisé.';
L10n::$locales['New file already exists.'] = 'Le nouveau fichier existe déjà.';
L10n::$locales['File does not exist in the database.'] = 'Ce fichier n\'existe pas dans la base de données.';
L10n::$locales['Extract destination directory %s already exists.'] = 'Le répertoire de destination d\'extraction %s existe déjà.';
L10n::$locales['No notice message'] = 'Pas de message';
L10n::$locales['%s has still been pinged'] = 'Un rétrolien vers %s a déjà été fait';
L10n::$locales['Unable to ping URL'] = 'Impossible de réaliser le rétrolien';
L10n::$locales['Bad server response code'] = 'Code de réponse du serveur incorrect';
L10n::$locales['%s is not a ping URL'] = '%s n\'est pas une URL de rétrolien';
L10n::$locales['%s, ping error:'] = '%s, erreur de rétrolien :';
L10n::$locales['Don\'t repeat yourself, please.'] = 'Ne vous répêtez pas, s\'il vous plait.';
L10n::$locales['Where\'s your title?'] = 'Où est votre titre ?';
L10n::$locales['Sorry, an internal problem has occured.'] = 'Désolé, une erreur interne est survenue.';
L10n::$locales['Thanks, mate. It was a pleasure.'] = 'Merci, c\'était un plaisir.';
L10n::$locales['Any chance you ping one of my contents? No? Really?'] = 'Y a-t-il une chance que vous envoyiez un ping à l\'un de mes contenus ? Non ? Vraiment ?';
L10n::$locales['Sorry but you can not ping this type of content.'] = 'Désolé, vous ne pouvez pas pinguer ce type de contenu.';
L10n::$locales['Oops. Kinda "not found" stuff. Please check the target URL twice.'] = 'Oops, non trouvé. Vérifiez à nouveau l\'URL cible.';
L10n::$locales['Sorry, dude. This entry does not accept pingback at the moment.'] = 'Désolé, cette entrée n\'accepte pas les pingbacks pour le moment.';
L10n::$locales['Your source URL does not look like a supported content type. Sorry. Bye, bye!'] = 'Votre URL source ne semble pas être un contenu supporté. Désolé.';
L10n::$locales['No valid source URL provided? Try again!'] = 'Aucune URL source valide fournie ? Essayez encore !';
L10n::$locales['No valid target URL provided? Try again!'] = 'Aucune URL destinataire valide fournie ? Essayez encore !';
L10n::$locales['LOL!'] = 'MDR !';
L10n::$locales['System'] = 'Système';
L10n::$locales['Dotclear\'s update dashboard'] = 'Tableau de bord de mise à jour de Dotclear';
L10n::$locales['Go to normal dashboard'] = 'Aller au tableau de bord normal';
L10n::$locales['Digests file not found.'] = 'Fichier de contrôle introuvable.';
L10n::$locales['No file to download'] = 'Aucun fichier à télécharger';
L10n::$locales['Root directory is not writable.'] = 'Le répertoire principal n\'est pas accessible en écriture.';
L10n::$locales['An error occurred while downloading archive.'] = 'Une erreur est survenue lors du téléchargement de l\'archive.';
L10n::$locales['Archive not found.'] = 'Archive introuvable.';
L10n::$locales['Unable to read current digests file.'] = 'Impossible de lire le fichier de contrôle actuel.';
L10n::$locales['Downloaded file does not seem to be a valid archive.'] = 'Le fichier téléchargé ne semble pas être une archive valide.';
L10n::$locales['Incomplete archive.'] = 'Archive incomplète.';
L10n::$locales['Unable to read digests file.'] = 'Impossible de lire le fichier de contrôle.';
L10n::$locales['Invalid digests file.'] = 'Fichier de contrôle invalide.';
L10n::$locales['Something went wrong with auto upgrade:'] = 'Une erreur est survenue durant la mise à jour automatique :';
L10n::$locales['On this page you can update dotclear to the latest release.'] = 'Sur cette page, vous pouvez mettre à jour dotclear avec la dernière version.';
L10n::$locales['Attic'] = 'Grenier';
L10n::$locales['On this page you can update dotclear to a release between yours and latest.'] = 'Sur cette page, vous pouvez mettre à jour dotclear à une version comprise entre la vôtre et la plus récente.';
L10n::$locales['Backups'] = 'Sauvegardes';
L10n::$locales['On this page you can revert your previous installation or delete theses files.'] = 'Sur cette page, vous pouvez revenir à l\'installation précédente ou supprimer ces fichiers.';
L10n::$locales['Here you can install, upgrade or remove languages for your Dotclear installation.'] = 'Sur cette page, vous pouvez installer, mettre à jour ou supprimer des langues de votre installation de Dotclear.';
L10n::$locales['On this page you will manage plugins.'] = 'Sur cette page, vous allez gérer les plugins.';
L10n::$locales['Cache'] = 'Cache';
L10n::$locales['On this page, you can clear templates and repositories cache.'] = 'Sur cette page, vous pouvez effacer le cache des templates et des dépôts.';
L10n::$locales['Digests'] = 'Digests';
L10n::$locales['On this page, you can bypass corrupted files or modified files in order to perform update.'] = 'Sur cette page, vous pouvez ignorer des fichiers altérés ou des fichiers modifiés afin d\'effectuer une mise à jour.';
L10n::$locales['Replay'] = 'Rejouer';
L10n::$locales['On this page, you can try to replay update action from a given version if some files remain from last update.'] = 'Sur cette page, vous pouvez essayer de rejouer l\'action de mise à jour à partir d\'une version donnée s\'il reste des fichiers de la dernière mise à jour.';
L10n::$locales['Unable to retrieve workspaces:'] = 'Impossible d\'obtenir les espaces de travail :';
L10n::$locales['Invalid UserWorkspace: %s'] = 'Espace de travail utilisateur invalide : %s';
L10n::$locales['Invalid dcWorkspace: %s'] = 'Espace de travail de la préférence invalide : %s';
L10n::$locales['Unable to retrieve prefs:'] = 'Impossible d\'obtenir les préférences :';
L10n::$locales['%s is not a valid pref id'] = '%s n\'est pas un identifiant de préférence valide';
L10n::$locales['No workspace specified'] = 'Aucun espace de travail spécifié';
L10n::$locales['No user ID given'] = 'Aucun identifiant utilisateur·rice spécifié';
L10n::$locales['No password given'] = 'Aucun mot de passe spécifié';
L10n::$locales['User ID must contain at least 2 characters using letters, numbers or symbols.'] = 'L\'identifiant utilisateur·rice doit contenir au moins 2 caractères composés de lettres, chiffres ou symboles.';
L10n::$locales['Password must contain at least 6 characters.'] = 'Le mot de passe doit contenir au moins 6 caractères.';
L10n::$locales['Invalid user language code'] = 'Code langue de l\'utilisateur·rice invalide';
L10n::$locales['SQL DELETE requires a FROM source'] = 'SQL DELETE requiert une source FROM';
L10n::$locales['SQL DROP TABLE requires a FROM source'] = 'SQL DROP TABLE requiert une table source';
L10n::$locales['SQL INSERT requires an INTO source'] = 'SQL INSERT requiert une source INTO';
L10n::$locales['SQL JOIN requires a FROM source'] = 'SQL JOIN requiert une source';
L10n::$locales['SQL SELECT requires a FROM source'] = 'SQL SELECT requiert une source FROM';
L10n::$locales['SQL TRUNCATE TABLE requires a FROM source'] = 'SQL TRUNCATE TABLE requiert une table source';
L10n::$locales['SQL UPDATE requires a FROM source'] = 'SQL UPDATE requiert une source FROM';
L10n::$locales['Bad range'] = 'Bornes incorrectes';
L10n::$locales['Invalid range'] = 'Bornes invalides';
L10n::$locales['Invalid line number'] = 'Numéro de ligne invalide';
L10n::$locales['Chunk is out of range'] = 'Le fragment est hors des bornes';
L10n::$locales['Bad context'] = 'Contexte incorrect';
L10n::$locales['Bad context (in deletion)'] = 'Contexte incorrect (en suppression)';
L10n::$locales['Invalid diff format'] = 'Fichier de patch invalide';
L10n::$locales['Unable to create directory.'] = 'Impossible de créer le répertoire.';
L10n::$locales['File is not writable.'] = 'Le fichier n\'est pas accessible en écriture.';
L10n::$locales['Unable to open file.'] = 'Impossible d\'ouvrir le fichier.';
L10n::$locales['Not an uploaded file.'] = 'Fichier invalide';
L10n::$locales['The uploaded file exceeds the maximum file size allowed.'] = 'La taille du fichier envoyé excède la taille maximale autorisée.';
L10n::$locales['The uploaded file was only partially uploaded.'] = 'Le fichier a été partiellement envoyé.';
L10n::$locales['No file was uploaded.'] = 'Aucun fichier n\'a été envoyé.';
L10n::$locales['Missing a temporary folder.'] = 'Un répertoire temporaire est manquant.';
L10n::$locales['Failed to write file to disk.'] = 'Impossible d\'écrire le fichier sur le disque.';
L10n::$locales['A PHP extension stopped the file upload.'] = 'Une extension PHP a stoppé l\'envoi du fichier.';
L10n::$locales['%s is not a directory.'] = '%s n\'est pas un répertoire.';
L10n::$locales['Can\'t get file path'] = 'Impossible d\'obtenir le chemin d\'accès au fichier';
L10n::$locales['Can\'t lock a directory'] = 'Impossible de verrouiller un répertoire';
L10n::$locales['Can\'t call php function named flock'] = 'Impossible d\'appeler la fonction PHP nommée flock';
L10n::$locales['Can\'t create file'] = 'Impossible de créer un fichier';
L10n::$locales['Can\'t open file'] = 'Impossible d\'ouvrir le fichier';
L10n::$locales['Can\'t lock file'] = 'Impossible de verrouiller le fichier';
L10n::$locales['File cannot be removed.'] = 'Le fichier ne peut être supprimé.';
L10n::$locales['Not enough memory to open image.'] = 'Pas assez de mémoire pour ouvrir l\'image';
L10n::$locales['Uploading this file is not allowed.'] = 'L\'envoi de ce fichier n\'est pas autorisé.';
L10n::$locales['Destination directory is not in jail.'] = 'Le répertoire de destination n\'est pas interdit.';
L10n::$locales['File already exists.'] = 'Le fichier existe déjà.';
L10n::$locales['Cannot write in this directory.'] = 'Impossible d\'écrire dans ce répertoire.';
L10n::$locales['Source file does not exist.'] = 'Le fichier source n\'existe pas.';
L10n::$locales['File is not in jail.'] = 'Le fichier n\'est pas interdit.';
L10n::$locales['Destination directory is not writable.'] = 'Le répertoire de destination n\'est pas accessible en écriture.';
L10n::$locales['Unable to rename file.'] = 'Impossible de renommer le fichier.';
L10n::$locales['Directory is not in jail.'] = 'Le répertoire n\'est pas interdit.';
L10n::$locales['Directory cannot be removed.'] = 'Le répertoire ne peut pas être retiré.';
L10n::$locales['File %s is not compressed in the zip.'] = 'Le fichier %s n\'existe pas dans l\'archive zip.';
L10n::$locales['Trying to unzip a folder name %s'] = 'Tentative de décompression du dossier %s';
L10n::$locales['Unable to write destination file.'] = 'Impossible d\'écrire le fichier de destination.';
L10n::$locales['Unable to write in target directory, permission denied.'] = 'Impossible d\'écrire dans le repertoire de destination, les permissions sont insuffisantes.';
L10n::$locales['Not enough memory to open file.'] = 'Pas assez de mémoire pour ouvrir le fichier.';
L10n::$locales['File does not exist'] = 'Le fichier n\'existe pas.';
L10n::$locales['Cannot read file'] = 'Impossible de lire le fichier';
L10n::$locales['Directory does not exist'] = 'Le répertoire est inexistant';
L10n::$locales['Cannot read directory'] = 'Impossible de lire le répertoire';
L10n::$locales['Unable to write ZIP archive'] = 'Impossible d\'écrire l\'archive ZIP';
L10n::$locales['Did not find closing tag for block <tpl:%s>. Content has been ignored.'] = 'Aucune balise fermante n\'a été trouvée pour le bloc <tpl:%s>. Le contenu a été ignoré.';
L10n::$locales['Unexpected closing tag </tpl:%s> found.'] = 'Une balise fermante </tpl:%s> sans correspondance a été trouvée.';
L10n::$locales['WARNING: the following errors have been found while parsing template file :'] = 'ATTENTION: les erreurs suivantes ont été rencontrées lors de la compilation du fichier de template :';
L10n::$locales['Status:'] = 'État :';
L10n::$locales['Module "%1$s" requires module "%2$s" which is not installed'] = 'Le module « %1$s » nécessite le module « %2$s » qui n\'est pas installé';
L10n::$locales['Module "%1$s" requires "%2$s" version %3$s, but version %4$s is installed'] = 'Le module "%1$s" nécessite la version "%2$s" %3$s, mais la version %4$s est installée';
L10n::$locales['Module "%1$s" requires module "%2$s" which is disabled'] = 'Le module « %1$s » nécessite le module « %2$s » qui est désactivé';
L10n::$locales['Module "%1$s" has type "%2$s" that mismatch required module type "%3$s".'] = 'Le module "%1$s" est de type "%2$s" incompatible avec "%3$s".';
L10n::$locales['Module "%1$s" is installed twice in "%2$s" and "%3$s".'] = 'Le module "%1$s" est installé en double dans "%2$s" et "%3$s".';
L10n::$locales['Empty module zip file.'] = 'Fichier zip de module vide.';
L10n::$locales['The zip file does not appear to be a valid Dotclear module.'] = 'Le fichier zip ne semble pas être un fichier de module Dotclear valide.';
L10n::$locales['Module is not installed: %s'] = 'Le module n\'est pas installé : %s';
L10n::$locales['Unable to upgrade "%s". (update locked)'] = 'Impossible de mettre à jour "%s". (mise à jour verrouillée)';
L10n::$locales['An error occurred during module deletion.'] = 'Une erreur est survenue durant la suppression du module.';
L10n::$locales['Unable to upgrade "%s". (older or same version)'] = 'Impossible de mettre à jour "%s" (plus ancienne ou même version).';
L10n::$locales['Unable to read new %s file'] = 'Impossible de lire le nouveau fichier %s';
L10n::$locales['Cannot deactivate plugin.'] = 'Le plugin ne peut pas être désactivé.';
L10n::$locales['No such module.'] = 'Module inexistant.';
L10n::$locales['Cannot remove module files'] = 'Impossible de supprimer les fichiers du module';
L10n::$locales['Cannot activate plugin.'] = 'Le plugin ne peut pas être activé.';
L10n::$locales['An error occurred while downloading the file.'] = 'Une erreur est survenue pendant le téléchargement du fichier.';
L10n::$locales['Wrong data feed'] = 'Données du flux incorrectes';
L10n::$locales['Themes folder unreachable'] = 'Le répertoire des thèmes n\'est pas accessible';
L10n::$locales['Themes folder unreadable'] = 'Le répertoire des thèmes n\'est pas lisible';
L10n::$locales[' (copy #%s)'] = ' (copie %s)';
L10n::$locales[' (copy)'] = ' (copie)';
L10n::$locales['Unable to modify _define.php'] = 'Impossible de modifier le fichier _define.php';
L10n::$locales['Destination folder already exist'] = 'Le répertoire de destination existe déjà';
L10n::$locales['Dotclear has been upgraded.'] = 'Dotclear a été mis à jour.';
L10n::$locales['Password reset'] = 'Réinitialisation du mot de passe';
L10n::$locales['Someone has requested to reset the password for the following site and username.'] = 'Quelqu\'un a demandé la réinitialisation du mot de passe pour le site et l\'utilisateur·rice suivants.';
L10n::$locales['To reset your password visit the following address, otherwise just ignore this email and nothing will happen.'] = 'Pour réinitialiser votre mot de passe, rendez-vous à l\'adresse suivante. Sinon ignorez simplement ce message et rien ne se passera.';
L10n::$locales['Username:'] = 'Nom d\'utilisatrice ou d\'utilisateur :';
L10n::$locales['The e-mail was sent successfully to %s.'] = 'Le message a été envoyé à %s.';
L10n::$locales['Your new password'] = 'Votre nouveau mot de passe';
L10n::$locales['Your new password is in your mailbox.'] = 'Votre nouveau mot de passe est dans votre boîte à lettres.';
L10n::$locales['Passwords don\'t match'] = 'Les mots de passe ne correspondent pas';
L10n::$locales['You didn\'t change your password.'] = 'Vous n\'avez pas changé votre mot de passe.';
L10n::$locales['You have to change your password before you can login.'] = 'Vous devez changer de mot de passe avant de vous connecter.';
L10n::$locales['In order to login, you have to change your password now.'] = 'Afin de vous connecter, vous devez changer votre mot de passe.';
L10n::$locales['Safe Mode can only be used for super administrators.'] = 'Le mode sans échec ne peut être utilisé que par un·e super administrateur·rice.';
L10n::$locales['Administration session expired'] = 'Session d\'administration expirée';
L10n::$locales['Wrong username or password'] = 'Nom d\'utilisateur·rice ou mot de passe incorrect';
L10n::$locales['Password strength: %s'] = 'Force du mot de passe : %s';
L10n::$locales['weak'] = 'faible';
L10n::$locales['strong'] = 'forte';
L10n::$locales['Back to login screen'] = 'Retour à la page de connexion';
L10n::$locales['Request a new password'] = 'Demander un nouveau mot de passe';
L10n::$locales['recover'] = 'récupérer';
L10n::$locales['Other option'] = 'Autres options';
L10n::$locales['Change your password'] = 'Changer mon mot de passe';
L10n::$locales['New password:'] = 'Nouveau mot de passe :';
L10n::$locales['Confirm password:'] = 'Confirmer le mot de passe :';
L10n::$locales['change'] = 'changer';
L10n::$locales['Safe mode login'] = 'Mode de secours';
L10n::$locales['This mode allows you to login without activating any of your plugins. This may be useful to solve compatibility problems'] = 'Ce mode vous permet de vous connecter sans activer de plugins. Il peut être utile pour résoudre un problème de compatibilité';
L10n::$locales['Update, disable or delete any plugin suspected to cause trouble, then log out and log back in normally.'] = 'Mettez à jour, désactivez, ou supprimez les plugins suspectés de poser problème, puis déconnectez-vous et reconnectez-vous normalement.';
L10n::$locales['Remember my ID on this device'] = 'Retenir mon identifiant sur cet appareil';
L10n::$locales['log in'] = 'Connexion';
L10n::$locales['You must accept cookies in order to use the private area.'] = 'Vous devez accepter les cookies pour utiliser la partie privée.';
L10n::$locales['Get back to normal authentication'] = 'Retour à la connexion normale';
L10n::$locales['Connection issue?'] = 'Problème de connexion ?';
L10n::$locales['I forgot my password'] = 'J\'ai oublié mon mot de passe';
L10n::$locales['I want to log in in safe mode'] = 'Connexion en mode de secours';
L10n::$locales['Blog "%s" successfully created'] = 'Le blog "%s" a été créé.';
L10n::$locales['New blog'] = 'Nouveau blog';
L10n::$locales['Blog ID:'] = 'Identifiant du blog :';
L10n::$locales['At least 2 characters using letters, numbers or symbols.'] = 'Au moins 2 caractères, composés de lettres non accentuées, chiffres ou symboles.';
L10n::$locales['Blog name:'] = 'Nom du blog :';
L10n::$locales['Blog URL'] = 'URL du blog';
L10n::$locales['Blog URL:'] = 'URL du blog :';
L10n::$locales['Blog description:'] = 'Description du blog :';
L10n::$locales['Create'] = 'Créer';
L10n::$locales['No such blog ID'] = 'Identifiant de blog inconnu';
L10n::$locales['Blog "%s" successfully deleted'] = 'Le blog "%s" a été supprimé.';
L10n::$locales['Delete a blog'] = 'Supprimer un blog';
L10n::$locales['Warning'] = 'Attention';
L10n::$locales['You are about to delete the blog %s. Every entry, comment and category will be deleted.'] = 'Vous êtes sur le point de supprimer le blog %s. Toutes ses entrées, commentaires et catégories seront supprimées.';
L10n::$locales['Please give your password to confirm the blog deletion.'] = 'Veuillez indiquer votre mot de passe pour confirmer la suppression du blog.';
L10n::$locales['Delete this blog'] = 'Supprimer ce blog';
L10n::$locales['No given blog id.'] = 'Pas d\'identifiant de blog.';
L10n::$locales['No such blog.'] = 'Blog inexistant.';
L10n::$locales['year/month/day/title'] = 'année/mois/jour/titre';
L10n::$locales['year/month/title'] = 'année/mois/titre';
L10n::$locales['year/title'] = 'année/titre';
L10n::$locales['title'] = 'titre';
L10n::$locales['post id/title'] = 'identificateur du billet/titre';
L10n::$locales['post id'] = 'identificateur du billet';
L10n::$locales['H4'] = 'H4';
L10n::$locales['H3'] = 'H3';
L10n::$locales['P'] = 'P';
L10n::$locales['(none)'] = '(sans)';
L10n::$locales['Description'] = 'Description';
L10n::$locales['Description, Date'] = 'Description, date';
L10n::$locales['Description, Country, Date'] = 'Description, pays, date';
L10n::$locales['Description, City, Country, Date'] = 'Description, ville, pays, date';
L10n::$locales['original'] = 'originale';
L10n::$locales['None'] = 'Aucun';
L10n::$locales['Left'] = 'Gauche';
L10n::$locales['Right'] = 'Droite';
L10n::$locales['Center'] = 'Centre';
L10n::$locales['Legend and alternate text'] = 'Légende et texte alternatif';
L10n::$locales['Alternate text'] = 'Texte alternatif';
L10n::$locales['I would like search engines and archivers to index and archive my blog\'s content.'] = 'Je souhaite que mon blog soit indexé et archivé par les moteurs de recherche et archiveurs.';
L10n::$locales['I would like search engines and archivers to index but not archive my blog\'s content.'] = 'Je souhaite que mon blog soit indexé mais pas archivé par les moteurs de recherche et archiveurs.';
L10n::$locales['I would like to prevent search engines and archivers from indexing or archiving my blog\'s content.'] = 'Je souhaite que mon blog ne soit ni indexé ni archivé par les moteurs de recherche et archiveurs.';
L10n::$locales['Default'] = 'Défaut';
L10n::$locales['Never'] = 'Jamais';
L10n::$locales['Three months'] = 'Trois mois';
L10n::$locales['Six months'] = 'Six mois';
L10n::$locales['One year'] = 'Un an';
L10n::$locales['Two years'] = 'Deux ans';
L10n::$locales['This blog ID is already used.'] = 'Cet identifiant est déjà utilisé.';
L10n::$locales['Invalid language code'] = 'Code langue invalide';
L10n::$locales['Blog has been successfully updated.'] = 'Le blog a été mis à jour.';
L10n::$locales['Warning: except for special configurations, it is generally advised to have a trailing "/" in your blog URL in PATH_INFO mode.'] = 'Attention : sauf cas particulier, il est généralement conseillé de terminer l\'URL de votre blog par "/" en mode PATH_INFO.';
L10n::$locales['Warning: except for special configurations, it is generally advised to have a trailing "?" in your blog URL in QUERY_STRING mode.'] = 'Attention: sauf cas particulier, il est généralement conseillé de terminer l\'URL de votre blog par \"?\" en mode QUERY_STRING.';
L10n::$locales['Sample:'] = 'Exemple :';
L10n::$locales['Blog has been successfully created.'] = 'Le blog a été créé.';
L10n::$locales['Blog status:'] = 'État du blog :';
L10n::$locales['Blog details'] = 'Informations du blog';
L10n::$locales['Required field'] = 'Champ obligatoire';
L10n::$locales['Blog configuration'] = 'Configuration du blog';
L10n::$locales['Blog editor name:'] = 'Nom de l\'auteur·rice du blog :';
L10n::$locales['Default language:'] = 'Langue par défaut :';
L10n::$locales['Blog timezone:'] = 'Fuseau horaire du blog :';
L10n::$locales['Copyright notice:'] = 'Note de copyright :';
L10n::$locales['Comments and trackbacks'] = 'Commentaires et rétroliens';
L10n::$locales['Accept comments'] = 'Accepter les commentaires';
L10n::$locales['Moderate comments'] = 'Modérer les commentaires';
L10n::$locales['Leave comments open for'] = 'Laissez les commentaires ouverts pendant';
L10n::$locales['days'] = 'jours';
L10n::$locales['No limit: set to 0 (zero).'] = 'Pas de limite : définir à 0 (zéro).';
L10n::$locales['Wiki syntax for comments'] = 'Autoriser la syntaxe wiki pour les commentaires';
L10n::$locales['Preview of comment before submit is not mandatory'] = 'Rendre optionnelle la prévisualisation des commentaires';
L10n::$locales['Accept trackbacks'] = 'Accepter les rétroliens';
L10n::$locales['Moderate trackbacks'] = 'Modérer les rétroliens';
L10n::$locales['Leave trackbacks open for'] = 'Laissez les rétroliens ouverts pendant';
L10n::$locales['Add "nofollow" relation on comments and trackbacks links'] = 'Ajouter la relation "nofollow" aux liens des commentaires et rétroliens';
L10n::$locales['Disable all comments and trackbacks on the blog after a period of time without new posts:'] = 'Désactiver les commentaires et les rétroliens sur le blog après ce délai sans aucun nouveau billet :';
L10n::$locales['Blog presentation'] = 'Présentation du blog';
L10n::$locales['Date format:'] = 'Format des dates :';
L10n::$locales['Pattern of date'] = 'Modèle de date';
L10n::$locales['Time format:'] = 'Format des heures :';
L10n::$locales['Pattern of time'] = 'Modèle d\'heure';
L10n::$locales['Don\'t load standard stylesheet (used for media alignement)'] = 'Ne pas charger la feuille de style standard (utilisée pour l\'alignement des médias)';
L10n::$locales['Display smilies on entries and comments'] = 'Afficher des émoticônes dans les entrées et commentaires';
L10n::$locales['Disable internal search system'] = 'Désactiver la recherche interne';
L10n::$locales['Display'] = 'Afficher';
L10n::$locales['entries on first page'] = 'entrées sur la première page';
L10n::$locales['entries per page'] = 'entrées par page';
L10n::$locales['entries per feed'] = 'entrées par flux de syndication';
L10n::$locales['comments per feed'] = 'commentaires par flux de syndication';
L10n::$locales['Truncate feeds'] = 'Tronquer les flux de syndication';
L10n::$locales['Include sub-categories in category page and category posts feed'] = 'Inclure les sous-catégories dans la page des catégories et dans les flux de billets pour une catégorie';
L10n::$locales['Display an entry as static home page'] = 'Afficher une entrée comme page d\'accueil statique';
L10n::$locales['Entry URL (its content will be used for the static home page):'] = 'URL de l\'entrée (son contenu sera utilisé pour la page d\'accueil statique) :';
L10n::$locales['Choose an entry'] = 'Sélectionner une entrée';
L10n::$locales['Leave empty to use the default presentation.'] = 'Laissez vide pour utiliser la présentation par défaut.';
L10n::$locales['Media and images'] = 'Médias et images';
L10n::$locales['Generated image sizes (max dimension in pixels)'] = 'Tailles des miniatures générées (dimension maximum en pixels)';
L10n::$locales['Be carefull if you share it with other blogs in your installation.'] = 'Soyez prudent·e si plusieurs blogs de l\'installation partagent la même médiathèque.';
L10n::$locales['Please note that if you change current settings bellow, they will now apply to all new images in the media manager.'] = 'Veuillez noter que si vous changez ces réglages, ils s\'appliqueront désormais à toutes les nouvelles images ajoutées à la médiathèque.';
L10n::$locales['Set -1 to use the default size, set 0 to ignore this thumbnail size (images only).'] = 'Mettez -1 pour utiliser la taille par défaut, mettez 0 pour ignorer cette taille de miniature (images seulement).';
L10n::$locales['Thumbnail'] = 'Vignette';
L10n::$locales['Small'] = 'Petite';
L10n::$locales['Medium'] = 'Moyenne';
L10n::$locales['Thumbnail character prefix:'] = 'Caractère de préfixe des miniatures :';
L10n::$locales['Leave empty to use the default one (.)'] = 'Laisser vide pour utiliser le caractère par défaut (.)';
L10n::$locales['Default size of the inserted video (in pixels)'] = 'Taille par defaut des vidéos insérées (en pixels)';
L10n::$locales['Width'] = 'Largeur';
L10n::$locales['Height'] = 'Hauteur';
L10n::$locales['A value of 0 means that the corresponding size is not included when inserting a video. A value of -1 restores the default value.'] = 'Une valeur de 0 signifie que la taille correspondante n\'est pas prise en compte lors de l\'insertion d\'une vidéo. Une valeur de -1 rétablit la valeur par défaut.';
L10n::$locales['Default image insertion attributes'] = 'Attributs par défaut pour l\'insertion d\'image';
L10n::$locales['Inserted image legend:'] = 'Attributs par défaut pour l\'insertion d\'image :';
L10n::$locales['Use original media date if possible'] = 'Utiliser la date originelle du média si possible';
L10n::$locales['Do not display date if alone in title'] = 'Ne pas afficher la date si elle est seule dans le titre';
L10n::$locales['It is retrieved from the picture\'s metadata.'] = 'Ces informations sont obtenues depuis les métadonnées de l\'image.';
L10n::$locales['Size of inserted image:'] = 'Taille de l\'image insérée :';
L10n::$locales['Image alignment:'] = 'Alignement de l\'image :';
L10n::$locales['Insert a link to the original image'] = 'Insérer le lien vers l\'image originale';
L10n::$locales['Image legend and alternate text:'] = 'Légende de l\'image et texte alternatif :';
L10n::$locales['Blog parameters'] = 'Paramètres du blog';
L10n::$locales['The URL of blog or the URL scan method might not be well set (<code>%1$s</code> return a <strong>%2$s</strong> status).'] = 'L\'URL du blog ou la méthode de lecture de l\'URL ne semblent pas être bien réglées (<code>%1$s</code> retourne un statut <strong>%2$s</strong>)';
L10n::$locales['The URL of blog or the URL scan method might not be well set (<code>%s</code> does not return an ATOM feed).'] = 'L\'URL du blog ou la méthode de lecture de l\'URL ne semblent pas être bien réglées (<code>%s</code> ne retourne pas un flux ATOM)';
L10n::$locales['Please note that changing your blog ID may require changes in your public index.php file.'] = 'Veuillez noter que changer l\'identifiant de votre blog peut nécessiter des modifications de votre fichier index.php public.';
L10n::$locales['URL scan method:'] = 'Méthode de lecture de l\'URL :';
L10n::$locales['New post URL format:'] = 'Format d\'URL des nouveaux billets :';
L10n::$locales['Dotclear'] = 'Dotclear';
L10n::$locales['HTML tag for the title of the notes on the blog:'] = 'Balise HTML pour le titre des notes sur le blog :';
L10n::$locales['Search engines robots policy'] = 'Paramètres d\'indexation par les moteurs de recherche';
L10n::$locales['AI text and data mining'] = 'Extraction de textes et de données par l\'IA';
L10n::$locales['Allow text and data analysis by AIs’ crawlers'] = 'Permettre l\'analyse de textes et de données par les robots d\'indexation des IA';
L10n::$locales['Legacy javascript library'] = 'Bibliothèque javascript historique';
L10n::$locales['Load the Legacy JS library'] = 'Charger la bibliothèque javascript historique';
L10n::$locales['jQuery javascript library'] = 'Bibliothèque javascript jQuery';
L10n::$locales['Load the jQuery library'] = 'Charger la bibliothèque jQuery';
L10n::$locales['jQuery version to be loaded for this blog:'] = 'Version de la bibliothèque jQuery à charger pour ce blog :';
L10n::$locales['Blog security'] = 'Sécurité du blog';
L10n::$locales['Protect the blog from Clickjacking (see <a href="%s">Wikipedia</a>)'] = 'Protéger le blog contre le Clickjacking (voir <a href="%s">Wikipedia)</a>';
L10n::$locales['Advanced parameters'] = 'Paramètres avancés du blog';
L10n::$locales['Plugins parameters'] = 'Paramètres des plugins pour ce blog';
L10n::$locales['Only superadmin can delete a blog.'] = 'Seul un ou une super-administrateur·rice peut supprimer un blog.';
L10n::$locales['Parameters'] = 'Paramètres';
L10n::$locales['No users'] = 'Aucun utilisateur·rice';
L10n::$locales['%1$s: %2$s'] = '%1$s : %2$s';
L10n::$locales['Super administrator'] = 'Super administrateur·rice';
L10n::$locales['All rights on all blogs.'] = 'Tous les droits sur tous les blogs.';
L10n::$locales['All rights on this blog.'] = 'Tous les droits sur ce blog.';
L10n::$locales['[%s] (unreferenced permission)'] = '[%s] (permission non référencée)';
L10n::$locales['Change permissions'] = 'Changer les permissions';
L10n::$locales['Back to user card'] = 'Retour à la carte de l\'utilisateur·ice';
L10n::$locales['Publications on this blog:'] = 'Publications sur ce blog :';
L10n::$locales['Permissions:'] = 'Permissions :';
L10n::$locales['Users on this blog'] = 'Utilisateur·rice·s de ce blog';
L10n::$locales['The following themes have been disabled :'] = 'Les thèmes suivants ont été désactivés :';
L10n::$locales['Theme configuration'] = 'Personnaliser ce thème';
L10n::$locales['Themes management'] = 'Gestion des thèmes';
L10n::$locales['Installed themes'] = 'Thèmes installés';
L10n::$locales['(in normal mode)'] = '(en mode normal)';
L10n::$locales['Activated themes'] = 'Thèmes activés';
L10n::$locales['You can configure and manage installed themes from this list.'] = 'Vous pouvez configurer et gérer les thèmes de cette liste.';
L10n::$locales['Deactivated themes'] = 'Thèmes désactivés';
L10n::$locales['Deactivated themes are installed but not usable. You can activate them from here.'] = 'Les thèmes désactivés sont installés mais non utilisables. Vous pouvez les activer depuis cette page.';
L10n::$locales['Official repository could not be updated as there is no URL set in configuration.'] = 'Le dépôt officiel n\'a pas pu être mis à jour car il n\'y a pas d\'URL définie dans la configuration.';
L10n::$locales['Manual checking of themes update done successfully.'] = 'La vérification manuelle de mise à jour des thèmes a été effectuée.';
L10n::$locales['Update themes'] = 'Mettre à jour les thèmes';
L10n::$locales['Force checking update of themes'] = 'Forcer la vérification de mise à jour des thèmes';
L10n::$locales['No updates available for themes.'] = 'Aucune mise à jour n\'est disponible pour les thèmes.';
L10n::$locales['There is one theme update available:'] = [
	'Il y a une mise à jour de thème disponible :',
	'Il y a %s mises à jour de thème disponibles :',
];
L10n::$locales['Visit %s repository, the resources center for Dotclear.'] = 'Visitez le dépôt %s, le centre de ressources pour Dotclear';
L10n::$locales['Add themes'] = 'Ajouter des thèmes';
L10n::$locales['Add themes from repository'] = 'Ajouter des thèmes depuis le dépôt';
L10n::$locales['Install or upgrade manually'] = 'Installer ou mettre à jour manuellement';
L10n::$locales['Add themes from a package'] = 'Ajouter des thèmes depuis un package';
L10n::$locales['You can install themes by uploading or downloading zip files.'] = 'Vous pouvez installer des thèmes en déposant ou téléchargeant des fichiers zip.';
L10n::$locales['Some functions are disabled, please give write access to your themes directory to enable them.'] = 'Certaines fonctions sont désactivées, donnez un accès en écriture à votre répertoire de thèmes pour les activer.';
L10n::$locales['List of blogs'] = 'Liste des blogs';
L10n::$locales['Create a new blog'] = 'Créer un nouveau blog';
L10n::$locales['Actions'] = 'Actions';
L10n::$locales['Selected blogs action:'] = 'Action sur les blogs sélectionnés :';
L10n::$locales['Please give your password to confirm blog(s) deletion:'] = 'Veuillez indiquer votre mot de passe pour confirmer la suppression du ou des blogs :';
L10n::$locales['This category does not exist.'] = 'Cette catégorie n\'existe pas.';
L10n::$locales['The category "%s" has been successfully deleted.'] = 'La catégorie "%s" a été supprimée.';
L10n::$locales['Category where to move entries does not exist'] = 'La catégorie où les publications seront déplacées n\'existe pas.';
L10n::$locales['The entries have been successfully moved to category "%s"'] = 'Les entrées ont été déplacés dans la catégorie "%s".';
L10n::$locales['Categories have been successfully reordered.'] = 'Les catégories ont été réordonnées.';
L10n::$locales['Categories order has been successfully reset.'] = 'Les catégories ont été réordonnées par défaut.';
L10n::$locales['The category has been successfully removed.'] = 'La catégorie a été supprimée.';
L10n::$locales['Entries have been successfully moved to the category you choose.'] = 'Les entrées ont été déplacées dans la catégorie choisie.';
L10n::$locales['New category'] = 'Nouvelle catégorie';
L10n::$locales['No category so far.'] = 'Pas de catégorie pour le moment.';
L10n::$locales['To rearrange categories order, move items by drag and drop, then click on “Save categories order” button.'] = 'Pour modifier l\'ordre des catégories, déplacez les items par glisser-déposer puis cliquez sur le bouton "Enregistrer l\'ordre des catégories".';
L10n::$locales['Save categories order'] = 'Enregistrer l\'ordre des catégories';
L10n::$locales['Reorder all categories on the top level'] = 'Replacer toutes les catégories au premier niveau';
L10n::$locales['%d entries'] = '%d entrées';
L10n::$locales['%d entry'] = '%d entrée';
L10n::$locales['total:'] = 'total :';
L10n::$locales['URL:'] = 'URL :';
L10n::$locales['Move entries to'] = 'Déplacer les entrées vers';
L10n::$locales['Delete category'] = 'Supprimer la catégorie';
L10n::$locales['Top level'] = 'Premier niveau';
L10n::$locales['The category has been successfully moved'] = 'La catégorie a été déplacée.';
L10n::$locales['The category has been successfully updated.'] = 'La catégorie a été mise à jour.';
L10n::$locales['The category "%s" has been successfully created.'] = 'La catégorie "%s" a été créée.';
L10n::$locales['Category has been successfully updated.'] = 'La catégorie a été mise à jour.';
L10n::$locales['Category information'] = 'Détails de la catégorie';
L10n::$locales['Name:'] = 'Nom :';
L10n::$locales['Warning: If you set the URL manually, it may conflict with another category.'] = 'Attention : si vous indiquez l\'URL manuellement, celle-ci peut entrer en conflit avec une autre catégorie.';
L10n::$locales['Description:'] = 'Description :';
L10n::$locales['Category parent'] = 'Catégorie parente';
L10n::$locales['Category sibling'] = 'Catégorie voisine';
L10n::$locales['Move current category'] = 'Déplacer la catégorie';
L10n::$locales['before'] = 'avant';
L10n::$locales['after'] = 'après';
L10n::$locales['position: '] = 'position : ';
L10n::$locales['Move this category'] = 'Déplacer cette catégorie';
L10n::$locales['Entry does not exist.'] = 'Cette entrée n\'existe pas.';
L10n::$locales['Comment has been successfully created.'] = 'Le commentaire a été créé.';
L10n::$locales['Comment has been successfully updated.'] = 'Le commentaire a été mis à jour.';
L10n::$locales['Comment has been successfully deleted.'] = 'Le commentaire a été effacé.';
L10n::$locales['You can\'t edit this comment.'] = 'Vous ne pouvez pas modifier ce commentaire.';
L10n::$locales['Edit comment'] = 'Modifier le commentaire';
L10n::$locales['Information collected'] = 'Informations recueillies';
L10n::$locales['Date:'] = 'Date :';
L10n::$locales['Comment submitted'] = 'Commentaire déposé';
L10n::$locales['Hi!

You wrote a comment on:
%s


'] = 'Bonjour,

Vous avez déposé un commentaire sur :
%s


';
L10n::$locales['Your comment on my blog %s'] = 'Votre commentaire sur mon blog %s';
L10n::$locales['Send an e-mail'] = 'Envoyer un email';
L10n::$locales['Comment:'] = 'Commentaire :';
L10n::$locales['Spam comments have been successfully deleted.'] = 'Les commentaires indésirables ont été supprimés.';
L10n::$locales['You have one spam comment.'] = 'Vous avez un commentaire indésirable.';
L10n::$locales['Show it.'] = 'L\'afficher.';
L10n::$locales['You have %s spam comments.'] = 'Vous avez %s commentaires indésirables.';
L10n::$locales['Show them.'] = 'Les afficher.';
L10n::$locales['Delete all spams'] = 'Supprimer tous les indésirables';
L10n::$locales['Selected comments action:'] = 'Action sur les commentaires sélectionnés :';
L10n::$locales['The following plugins have been disabled:'] = 'Les plugins suivants ont été désactivés:';
L10n::$locales['Your last donation date has been saved.'] = 'La date de votre dernier don a été enregistrée.';
L10n::$locales['Dashboard area\'s drag and drop is disabled'] = 'L\'ordonnancement par glisser-déposer des zones du tableau de bord est désactivé';
L10n::$locales['Dashboard area\'s drag and drop is enabled'] = 'L\'ordonnancement par glisser-déposer des zones du tableau de bord est activé';
L10n::$locales['Dashboard'] = 'Tableau de bord';
L10n::$locales['Make this blog my default blog'] = 'Définir comme blog par défaut';
L10n::$locales['This blog is offline'] = 'Ce blog est hors ligne';
L10n::$locales['This blog is removed'] = 'Ce blog est retiré de la publication';
L10n::$locales['%s is not defined, you should edit your configuration file.'] = '%s n\'est pas défini, vous devriez corriger votre fichier de configuration.';
L10n::$locales['See <a href="%s">documentation</a> for more information.'] = 'Voir la <a href="%s">documentation</a> pour plus d\'informations.';
L10n::$locales['The cache directory does not exist or is not writable. You must create this directory with sufficient rights and affect this location to "DC_TPL_CACHE" in inc/config.php file.'] = 'Le répertoire de cache n\'existe pas ou n\'est pas accessible en écriture. Vous devez créer ce répertoire avec les droits suffisants et affecter celui-ci à "DC_TPL_CACHE" dans le fichier inc/config.php.';
L10n::$locales['The cache directory does not exist or is not writable. You should contact your administrator.'] = 'Le répertoire de cache n\'existe pas ou n\'est pas accessible en écriture. Vous devriez contacter votre administrateur·rice.';
L10n::$locales['There is no writable directory /public/ at the location set in about:config "public_path". You must create this directory with sufficient rights (or change this setting).'] = 'Il n\'existe pas de répertoire /public/ à l\'endroit spécifié pour le réglage "public_path" dans about:config. Vous devez créer ce répertoire avec les droits suffisants (ou changer ce réglage).';
L10n::$locales['There is no writable root directory for the media manager. You should contact your administrator.'] = 'Il n\'existe pas de répertoire principal accessible en écriture pour la médiathèque. Vous devriez contacter votre administrateur·rice.';
L10n::$locales['Following plugins have been installed:'] = 'Les plugins suivants ont été installés :';
L10n::$locales['Following plugins have not been installed:'] = 'Les plugins suivants n\'ont pas été installés :';
L10n::$locales['Errors have occured with following plugins:'] = 'Des erreurs se sont produites avec les plugins suivants :';
L10n::$locales['Quick post'] = 'Billet rapide';
L10n::$locales['Content:'] = 'Contenu :';
L10n::$locales['Content'] = 'Contenu';
L10n::$locales['Add a new category'] = 'Créer une nouvelle catégorie';
L10n::$locales['This category will be created when you will save your post.'] = 'Cette catégorie sera créée lorsque vous enregistrerez votre billet.';
L10n::$locales['Save and publish'] = 'Enregister et publier';
L10n::$locales['Donate to Dotclear'] = 'Faire un don à Dotclear';
L10n::$locales['Dotclear is not a commercial project — using Dotclear is <strong>free</strong> and <strong>always</strong> will be. If you wish to, you may contribute to Dotclear to help us cover project-related expenses.'] = 'Dotclear n\'est pas un projet commercial - l\'utilisation de Dotclear est <strong>gratuite</strong> et le sera <strong>toujours</strong>. Si vous le souhaitez, vous pouvez contribuer à Dotclear pour nous aider à couvrir les dépenses liées au projet.';
L10n::$locales['The collected funds will be spent as follows:'] = 'Les fonds collectés seront dépensés comme suit :';
L10n::$locales['Paying for the website hosting and translations'] = 'Payer l\'hébergement du site et les traductions';
L10n::$locales['Paying for the domain names'] = 'Payer les noms de domaine';
L10n::$locales['Supporting related projects such as Dotaddict.org'] = 'Soutenir des projets connexes tels que Dotaddict.org';
L10n::$locales['Cover the costs of events set up by Dotclear'] = 'Couvrir les coûts des événements organisés par Dotclear';
L10n::$locales['See <a href="%s">this page</a> for more information and donation'] = 'Voir <a href="%s">cette page</a> pour plus d\'informations et de dons';
L10n::$locales['For the record, here is the date of my last donation to Dotclear:'] = 'Pour mémoire, je peux consigner ici la date de mon dernier don à Dotclear :';
L10n::$locales['Documentation and support'] = 'Documentation et support';
L10n::$locales['No such installed language'] = 'Cette langue n\'est pas installée';
L10n::$locales['You can\'t remove English language.'] = 'Vous ne pouvez pas supprimer la langue anglaise.';
L10n::$locales['Permissions to delete language denied.'] = 'Permission de supprimer la langue refusée.';
L10n::$locales['Language has been successfully deleted.'] = 'La langue a été supprimée.';
L10n::$locales['Invalid language file URL.'] = 'URL de fichier de langue invalide.';
L10n::$locales['Unable to make a HTTP request.'] = 'Impossible d\'effectuer une requête HTTP.';
L10n::$locales['Language has been successfully upgraded'] = 'La langue a été mise à jour.';
L10n::$locales['Language has been successfully installed.'] = 'La langue a été installée.';
L10n::$locales['Languages management'] = 'Gestion des langues';
L10n::$locales['You can change your user language in your <a href="%1$s">preferences</a> or change your blog\'s main language in your <a href="%2$s">blog settings</a>.'] = 'Vous pouvez changer votre langue d\'utilisateur dans vos <a href="%1$s">préférences</a> ou changer la langue principale de votre blog dans les <a href="%2$s">paramètres de votre blog</a>.';
L10n::$locales['Installed languages'] = 'Langues installées';
L10n::$locales['No additional language is installed.'] = 'Aucune langue supplémentaire n\'est installée.';
L10n::$locales['Language'] = 'Langue';
L10n::$locales['Install or upgrade languages'] = 'Installer ou mettre à jour une langue';
L10n::$locales['You can install or remove a language by adding or removing the relevant directory in your %s folder.'] = 'Vous pouvez installer ou supprimer une langue en ajoutant ou supprimant le répertoire correspondant dans votre répertoire %s.';
L10n::$locales['Available languages'] = 'Langues disponibles';
L10n::$locales['You can download and install a additional language directly from Dotclear server. Proposed languages are based on your version: %s.'] = 'Vous pouvez télécharger et installer une langue supplémentaire directement à partir du serveur Dotclear. Les langues proposées sont basées sur votre version : %s.';
L10n::$locales['Language:'] = 'Langue :';
L10n::$locales['Install language'] = 'Installer la langue';
L10n::$locales['You can install languages by uploading zip files.'] = 'Vous pouvez installer des langues en déposant des fichiers zip.';
L10n::$locales['Language zip file:'] = 'Fichier zip de la langue :';
L10n::$locales['Upload language'] = 'Déposer la langue';
L10n::$locales['Invalid language zip file.'] = 'Fichier zip de langue invalide.';
L10n::$locales['The zip file does not appear to be a valid Dotclear language pack.'] = 'Le fichier zip ne semble pas être un fichier de langue Dotclear valide.';
L10n::$locales['An error occurred during language upgrade.'] = 'Une erreur est survenue durant la mise à jour de la langue.';
L10n::$locales['Add a link'] = 'Ajouter un lien';
L10n::$locales['Link URL:'] = 'URL du lien :';
L10n::$locales['Link title:'] = 'Titre du lien :';
L10n::$locales['Link language:'] = 'Langue du lien :';
L10n::$locales['Insert'] = 'Insérer';
L10n::$locales['Not a valid directory'] = 'Répertoire invalide';
L10n::$locales['Directory or file "%s" already exists.'] = 'Le répertoire ou le fichier "%s" existe déjà.';
L10n::$locales['Directory "%s" has been successfully created.'] = 'Le répertoire "%s" a été créé.';
L10n::$locales['Files have been successfully uploaded.'] = 'Le fichier a été chargé.';
L10n::$locales['Successfully delete one media.'] = [
	'Suppression d\'un média effectuée.',
	'Suppression de %d médias effectuée.',
];
L10n::$locales['Directory has been successfully removed.'] = 'Le répertoire a été supprimé.';
L10n::$locales['File has been successfully removed.'] = 'Le fichier a été supprimé.';
L10n::$locales['Directory "%s" has been successfully completed.'] = 'Les miniatures manquantes du répertoire "%s" ont été construites.';
L10n::$locales['Directory "%s" has been successfully rebuild.'] = 'Les miniatures du répertoire "%s" ont été reconstruites avec succès.';
L10n::$locales['confirm removal'] = 'Confirmer la suppression';
L10n::$locales['Are you sure you want to remove %s?'] = 'Êtes-vous certain·e de vouloir supprimer %s ?';
L10n::$locales['Yes'] = 'oui';
L10n::$locales['Remove this folder from your favorites'] = 'Retirer ce dossier de vos favoris';
L10n::$locales['Add this folder to your favorites'] = 'Ajouter ce dossier à vos favoris';
L10n::$locales['Goto recent folder:'] = 'Aller au dossier récent :';
L10n::$locales['You do not have sufficient permissions to write to this folder.'] = 'Vous n\'avez pas les droits suffisants pour écrire dans ce répertoire.';
L10n::$locales['Select a file by clicking on %s'] = 'Choisissez un fichier en cliquant sur %s';
L10n::$locales['Select files and click on <strong>%s</strong> button'] = 'Selectionnez les fichiers et cliquez sur le bouton <strong>%s</strong>';
L10n::$locales['Choose selected medias'] = 'Choisir les médias sélectionnés';
L10n::$locales['or'] = 'ou';
L10n::$locales['upload a new file'] = 'envoyez un nouveau fichier';
L10n::$locales['Choose a file to attach to entry %1$s by clicking on %2$s'] = 'Choisissez un fichier à attacher à l\'entrée %1$s en cliquant sur %2$s';
L10n::$locales['Choose a file to insert into entry by clicking on %s'] = 'Choisissez un fichier à insérer dans l\'entrée en cliquant sur %s';
L10n::$locales['Grid display mode'] = 'Afficher sous forme de grille';
L10n::$locales['List display mode'] = 'Afficher sous forme de liste';
L10n::$locales['Remove selected medias'] = 'Supprimer les médias sélectionnés';
L10n::$locales['Create new directory'] = 'Créer un répertoire';
L10n::$locales['Directory Name:'] = 'Nom du répertoire :';
L10n::$locales['Build missing thumbnails in directory'] = 'Construire les miniatures manquantes des images du répertoire';
L10n::$locales['Build'] = 'Construire';
L10n::$locales['Force rebuild all thumbnails in directory'] = 'Forcer la reconstruction de toutes les miniatures du répertoire';
L10n::$locales['Force rebuild'] = 'Forcer la reconstruction';
L10n::$locales['Use with caution especially if there is a large numbers of media if this directory.'] = 'A utiliser avec précaution, surtout si ce répertoire contient un grand nombre de médias.';
L10n::$locales['Backup content of %s'] = 'Sauvegarder le contenu de %s';
L10n::$locales['Download zip file'] = 'Télécharger un fichier zip';
L10n::$locales['Add files'] = 'Ajouter des fichiers';
L10n::$locales['Please take care to publish media that you own and that are not protected by copyright.'] = 'Veuillez prendre garde à ne publier que des médias que vous possédez ou qui ne sont pas protégés par le droit d\'auteur.';
L10n::$locales['Maximum file size allowed:'] = 'Taille maximale de fichier autorisée :';
L10n::$locales['Private'] = 'Privé';
L10n::$locales['To send several files at the same time, you can activate the enhanced uploader in'] = 'Pour envoyer plusieurs fichiers à la fois, vous pouvez activer l\'interface avancée dans';
L10n::$locales['Refresh'] = 'Actualiser';
L10n::$locales['Clear all'] = 'Tout annuler';
L10n::$locales['In %s:'] = 'Dans %s :';
L10n::$locales['Current settings for medias and images are defined in %s'] = 'Les réglages actuels pour les médias et les images sont définis dans les %s';
L10n::$locales['Not a valid file'] = 'Fichier invalide';
L10n::$locales['File has been successfully updated.'] = 'Le fichier a été mis à jour.';
L10n::$locales['Thumbnails have been successfully updated.'] = 'Les miniatures ont été mises à jour.';
L10n::$locales['Zip file has been successfully extracted.'] = 'Le fichier zip a été extrait.';
L10n::$locales['Default media insertion settings have been successfully updated.'] = 'Les paramètres par défaut d\'insertion des médias ont été mis à jour.';
L10n::$locales['Media insertion settings have been successfully registered for this folder.'] = 'Les réglages d\'insertion ont été enregistrés pour ce dossier.';
L10n::$locales['Media insertion settings have been successfully removed for this folder.'] = 'Les réglages d\'insertion ont été supprimés pour ce dossier.';
L10n::$locales['Image size:'] = 'Taille de l\'image :';
L10n::$locales['Select media item'] = 'Insérer un média';
L10n::$locales['Select'] = 'Sélectionner';
L10n::$locales['Image legend and alternate text'] = 'Légende de l\'image et texte alternatif';
L10n::$locales['Alternate text:'] = 'Texte alternatif : ';
L10n::$locales['Legend:'] = 'Légende :';
L10n::$locales['Image alignment'] = 'Alignement de l\'image';
L10n::$locales['Image insertion'] = 'Insertion de l\'image';
L10n::$locales['As a single image'] = 'En tant qu\'image uniquement';
L10n::$locales['As a link to the original image'] = 'En tant que lien vers l\'image originale';
L10n::$locales['MP3 disposition'] = 'Disposition du MP3';
L10n::$locales['Please note that you cannot insert mp3 files with standard editor in WYSIWYG HTML mode.'] = 'Veuillez noter que vous ne pouvez pas insérer de fichiers mp3 avec l\'éditeur standard en mode HTML WYSIWYG.';
L10n::$locales['Video size'] = 'Taille de la vidéo';
L10n::$locales['Width:'] = 'Largeur :';
L10n::$locales['Height:'] = 'Hauteur :';
L10n::$locales['A value of 0 means that the corresponding size is not included when inserting a video.'] = 'Une valeur de 0 signifie que la taille correspondante n\'est pas prise en compte lors de l\'insertion d\'une vidéo.';
L10n::$locales['Video disposition'] = 'Disposition de la vidéo';
L10n::$locales['Please note that you cannot insert video files with standard editor in WYSIWYG HTML mode.'] = 'Veuillez noter que vous ne pouvez pas insérer de fichiers vidéo avec l\'éditeur standard en mode HTML WYSIWYG.';
L10n::$locales['Media item will be inserted as a link.'] = 'Le média sera inséré en tant que lien.';
L10n::$locales['Make current settings as default'] = 'Mémoriser ces réglages d\'insertion';
L10n::$locales['For the blog'] = 'Pour le blog';
L10n::$locales['For this folder only'] = 'Pour ce dossier seulement';
L10n::$locales['Settings exist for this folder:'] = 'Des réglages d\'insertion existent pour ce dossier :';
L10n::$locales['Remove them'] = 'Les supprimer';
L10n::$locales['Insert media item'] = 'Insérer un média';
L10n::$locales['Available sizes:'] = 'Tailles disponibles :';
L10n::$locales['Image width:'] = 'Largeur de l\'image :';
L10n::$locales['Image height:'] = 'Hauteur de l\'image :';
L10n::$locales['File size:'] = 'Taille du fichier :';
L10n::$locales['File URL:'] = 'URL du fichier :';
L10n::$locales['Thumbnail details'] = 'Détails de la miniature';
L10n::$locales['File owner:'] = 'Propriétaire du fichier :';
L10n::$locales['File type:'] = 'Type de fichier :';
L10n::$locales['Show entries containing this media'] = 'Afficher les entrées contenant ce média';
L10n::$locales['No entry seems contain this media.'] = 'Aucune entrée ne semble contenir ce média.';
L10n::$locales['Inside the entry'] = 'A l\'intérieur du contenu de l\'entrée';
L10n::$locales['Linked to entry'] = 'Attaché à l\'entrée';
L10n::$locales['Entries containing this media'] = 'Entrées contenant ce média';
L10n::$locales[':'] = ' :';
L10n::$locales['Metadata'] = 'Métadonnées';
L10n::$locales['Media details'] = 'Détails du média';
L10n::$locales['Update thumbnails'] = 'Mettre à jour les miniatures';
L10n::$locales['This will create or update thumbnails for this image.'] = 'Ceci va créer ou mettre à jour les miniatures pour cette image.';
L10n::$locales['Extract in a new directory'] = 'Extraire dans un nouveau répertoire';
L10n::$locales['Extract in current directory'] = 'Extraire dans le répertoire actuel';
L10n::$locales['Extract archive'] = 'Extraire l\'archive';
L10n::$locales['This will extract archive in a new directory that should not exist yet.'] = 'Ceci va extraire l\'archive dans un nouveau répertoire qui ne doit pas encore exister.';
L10n::$locales['This will extract archive in current directory and will overwrite existing files or directory.'] = 'Ceci va extraire l\'archive dans le répertoire actuel et écrasera les fichiers ou répertoires existants.';
L10n::$locales['Extract mode:'] = 'Mode d\'extraction :';
L10n::$locales['Extract'] = 'Extraire';
L10n::$locales['Change media properties'] = 'Changer les propriétés du média';
L10n::$locales['File name:'] = 'Nom du fichier :';
L10n::$locales['File date:'] = 'Date du fichier :';
L10n::$locales['New directory:'] = 'Nouveau répertoire :';
L10n::$locales['Change file'] = 'Changer le fichier';
L10n::$locales['Choose a file:'] = 'Choisir un fichier :';
L10n::$locales['Maximum size %s'] = 'Taille maximale %s';
L10n::$locales['Delete this media'] = 'Supprimer ce média';
L10n::$locales['Updates and modifications'] = 'Mises à jour et modifications';
L10n::$locales['No content found on this plugin.'] = 'Aucun contenu pour ce plugin.';
L10n::$locales['Plugin not found'] = 'Plugin introuvable';
L10n::$locales['The plugin you reached does not exist or does not have an admin page.'] = 'Le plugin que vous essayez d\'atteindre n\'existe pas ou n\'a pas de page d\'administration.';
L10n::$locales['The following plugins have been disabled :'] = 'Les plugins suivants ont été désactivés :';
L10n::$locales['Activated plugins'] = 'Plugins activés';
L10n::$locales['Installed plugins'] = 'Plugins installés';
L10n::$locales['You can configure and manage installed plugins from this list.'] = 'Vous pouvez configurer et gérer les plugins installés depuis cette liste.';
L10n::$locales['Deactivated plugins'] = 'Plugins désactivés';
L10n::$locales['Deactivated plugins are installed but not usable. You can activate them from here.'] = 'Les plugins désactivés sont installés mais non utilisables. Vous pouvez les activer depuis cette page.';
L10n::$locales['Manual checking of plugins update done successfully.'] = 'La vérification manuelle de mise à jour des plugins a été effectuée.';
L10n::$locales['No updates available for plugins.'] = 'Aucune mise à jour n\'est disponible pour les plugins.';
L10n::$locales['There is one plugin update available:'] = [
	'Une mise à jour de plugin est disponible :',
	'Il y a %s mises à jour de plugin disponibles :',
];
L10n::$locales['Update plugins'] = 'Mise à jour des plugins';
L10n::$locales['Force checking update of plugins'] = 'Forcer la vérification de mise à jour des plugins';
L10n::$locales['Add plugins'] = 'Ajouter des plugins';
L10n::$locales['Add plugins from repository'] = 'Ajouter des plugins depuis le dépôt';
L10n::$locales['Add plugins from a package'] = 'Ajouter des plugins depuis un package';
L10n::$locales['You can install plugins by uploading or downloading zip files.'] = 'Vous pouvez installer des plugins en déposant ou téléchargeant des fichiers zip.';
L10n::$locales['Some functions are disabled, please give write access to your plugins directory to enable them.'] = 'Certaines fonctions sont désactivées, donnez un accès en écriture à votre répertoire de plugins pour les activer.';
L10n::$locales['Plugin configuration'] = 'Configuration du plugin';
L10n::$locales['Edit post'] = 'Modifier le billet';
L10n::$locales['Next post'] = 'Billet suivant';
L10n::$locales['Previous post'] = 'Billet précédent';
L10n::$locales['All pings sent.'] = 'Tous les rétroliens ont été envoyés.';
L10n::$locales['Invalid publication date'] = 'Date de publication invalide';
L10n::$locales['The post "%s" has been successfully updated'] = 'Le billet "%s" a été mis à jour.';
L10n::$locales['Entry has been successfully updated.'] = 'L\'entrée a été mise à jour.';
L10n::$locales['File has been successfully attached.'] = 'Le fichier a été attaché.';
L10n::$locales['Attachment has been successfully removed.'] = 'L\'annexe a été retirée.';
L10n::$locales['Don\'t forget to validate your XHTML conversion by saving your post.'] = 'Enregistrez votre billet pour valider la transformation en HTML.';
L10n::$locales['Go to this entry on the site'] = 'Voir cette entrée sur le site';
L10n::$locales['Entry status'] = 'État de l\'entrée';
L10n::$locales['Publication date and hour'] = 'Date et heure de publication';
L10n::$locales['Entry language'] = 'Langue de l\'entrée';
L10n::$locales['Text formatting'] = 'Formatage du texte';
L10n::$locales['Convert to HTML'] = 'Convertir en HTML';
L10n::$locales['Filing'] = 'Classement';
L10n::$locales['Selected entry'] = 'Entrée sélectionnée';
L10n::$locales['Options'] = 'Options';
L10n::$locales['Comments and trackbacks list'] = 'Liste des commentaires et des rétroliens';
L10n::$locales['Warning: Comments are no longer accepted for this entry.'] = 'Attention : les commentaires ne sont plus acceptés pour cette entrée.';
L10n::$locales['Comments are not accepted on this blog so far.'] = 'Les commentaires ne sont pas acceptés sur ce blog pour le moment.';
L10n::$locales['Warning: Trackbacks are no longer accepted for this entry.'] = 'Attention : les rétroliens ne sont plus acceptés pour cette entrée.';
L10n::$locales['Trackbacks are not accepted on this blog so far.'] = 'Les rétroliens sont fermés sur ce blog pour le moment.';
L10n::$locales['Edit basename'] = 'URL spécifique';
L10n::$locales['Warning: If you set the URL manually, it may conflict with another entry.'] = 'Attention : si vous indiquez l\'URL manuellement, celle-ci peut entrer en conflit avec une autre entrée.';
L10n::$locales['Excerpt:'] = 'Extrait :';
L10n::$locales['Introduction to the post.'] = 'Introduction au billet.';
L10n::$locales['Personal notes:'] = 'Notes personnelles :';
L10n::$locales['Unpublished notes.'] = 'Notes non publiées.';
L10n::$locales['Add a comment'] = 'Ajouter un commentaire';
L10n::$locales['No trackback'] = 'Aucun rétrolien';
L10n::$locales['Selected trackbacks action:'] = 'Action sur les rétroliens sélectionnés :';
L10n::$locales['Previously sent pings'] = 'Rétroliens déjà envoyés';
L10n::$locales['Ping blogs'] = 'Envoyer des rétroliens';
L10n::$locales['URLs to ping:'] = 'URLs à rétrolier :';
L10n::$locales['Excerpt to send:'] = 'Extrait à envoyer :';
L10n::$locales['Auto discover ping URLs'] = 'Découverte automatique des URL à rétrolier';
L10n::$locales['select this comment'] = 'Sélectionner ce commentaire';
L10n::$locales['select this trackback'] = 'Sélectionner ce rétrolien';
L10n::$locales['Edit this comment'] = 'Modifier ce commentaire';
L10n::$locales['Edit this trackback'] = 'Modifier ce rétrolien';
L10n::$locales['This attachment does not exist'] = 'Cette annexe n\'existe pas';
L10n::$locales['Remove attachment'] = 'Supprimer l\'annexe';
L10n::$locales['Are you sure you want to remove this attachment?'] = 'Êtes-vous certain·e de vouloir supprimer cette annexe ?';
L10n::$locales['Selected entries have been successfully updated.'] = 'Les entrées sélectionnées ont été modifiées.';
L10n::$locales['Selected entries have been successfully deleted.'] = 'Les entrées sélectionnées ont été supprimées.';
L10n::$locales['Selected entries action:'] = 'Action sur les entrées sélectionnées :';
L10n::$locales['Add a link to an entry'] = 'Ajouter un lien vers une entrée';
L10n::$locales['Entry type:'] = 'Type d\'entrée :';
L10n::$locales['Search entry:'] = 'Rechercher une entrée :';
L10n::$locales['cancel'] = 'annuler';
L10n::$locales['Dotclear news not available'] = 'Nouvelles de Dotclear non disponibles';
L10n::$locales['%d %B %Y:'] = '%d %B %Y :';
L10n::$locales['Dotclear news'] = 'Actualité de Dotclear';
L10n::$locales['Dotclear update not available'] = 'Mise à jour de Dotclear non disponible';
L10n::$locales['Dotclear %s is available!'] = 'Dotclear %s est disponible !';
L10n::$locales['Upgrade now'] = 'Mettre à jour maintenant';
L10n::$locales['Remind me later'] = 'Me le rappeler plus tard';
L10n::$locales['Information about this version'] = 'Informations sur cette version';
L10n::$locales['A new version of Dotclear is available but needs PHP version ≥ %1$s, your\'s is currently %2$s'] = 'Une nouvelle version de Dotclear est disponible mais nécessite une version de PHP ≥ %1$s, la votre est actuellement la %2$s';
L10n::$locales['The next versions of Dotclear will not support PHP version < %1$s, your\'s is currently %2$s'] = 'Les prochaines versions de Dotclear ne supporteront pas les versions de PHP < %1$s, la votre est actuellement la %2$s';
L10n::$locales['No updates are available'] = 'Aucune mise à jour n\'est disponible';
L10n::$locales['An update is available'] = [
	'Une mise à jour est disponible.',
	'%s mises à jour sont disponibles.',
];
L10n::$locales['List options saved'] = 'Options de liste sauvegardées';
L10n::$locales['Search options'] = 'Options de recherche';
L10n::$locales['Query:'] = 'Requête :';
L10n::$locales['In:'] = 'Où :';
L10n::$locales['No results found'] = 'Pas de résultats';
L10n::$locales['Search in entries'] = 'Rechercher dans les entrées';
L10n::$locales['Search in comments'] = 'Rechercher dans les commentaires';
L10n::$locales['one entry found'] = [
	'une entrée trouvée',
	'%d entrées trouvées',
];
L10n::$locales['one comment found'] = [
	'un commentaire trouvé',
	'%d commentaires trouvés',
];
L10n::$locales['Configuration'] = 'Configuration';
L10n::$locales['User preferences'] = 'Mes préférences';
L10n::$locales['Settings'] = 'Réglages';
L10n::$locales['Other settings'] = 'Autres réglages';
L10n::$locales['Management'] = 'Gestion';
L10n::$locales['Widgets'] = 'Widgets';
L10n::$locales['Unknown'] = 'Inconnu';
L10n::$locales['This page does not allow you to manage plugins (update, install, uninstall, activate, deactivate, etc.). If you need to, go to <a href="%s">this page</a>.'] = 'Cette page ne permet pas de gérer les plugins (mise à jour, installation, désinstallation, activation, désactivation, etc.) Si vous en avez besoin, rendez-vous sur <a href="%s">cette page</a>.';
L10n::$locales['ID'] = 'ID';
L10n::$locales['User'] = 'Utilisateur';
L10n::$locales['Columns description:'] = 'Description des colonnes :';
L10n::$locales['<strong>Configuration</strong> indicates that plugin has a specific configuration page.'] = '<strong>Configuration</strong> indique que le plugin dispose d\'une page de configuration spécifique.';
L10n::$locales['<strong>Blog</strong> indicates that plugin has specific settings in blog parameters, generally used to add or modify some behaviors or aspects of the public blog.'] = '<strong>Blog</strong> indique que le plugin a des réglages spécifiques dans les paramètres du blog, généralement utilisés pour ajouter ou modifier certains comportements ou aspects du blog public.';
L10n::$locales['<strong>User</strong> indicates that the plugin has a specific configuration in the user preferences, generally used to add or modify certain behaviors or aspects of blog administration for the user.'] = '<strong>Utilisateur</strong> indique que le plugin a une configuration spécifique dans les préférences de l\'utilisateur, généralement utilisée pour ajouter ou modifier certains comportements ou aspects de l\'administration du blog pour l\'utilisateur.';
L10n::$locales['<strong>Settings</strong> indicates that the plugin has specific parameters on its management page.'] = '<strong>Paramètres</strong> indique que le plugin a des réglages spécifiques sur sa page de gestion.';
L10n::$locales['<strong>Other settings</strong> indicates that plugin has specific settings in other context.'] = '<strong>Autres paramètres</strong> indique que le plugin a des paramètres spécifiques dans un autre contexte.';
L10n::$locales['<strong>Management</strong> indicates that the plugin has a specific management page.'] = '<strong>Gestion</strong> indique que le plugin dispose d\'une page de gestion spécifique.';
L10n::$locales['<strong>Widgets</strong> indicates that the plugin provide one or more widgets.'] = '<strong>Widgets</strong> indique que le plugin fournit un ou plusieurs widgets.';
L10n::$locales['New user'] = 'Nouvel utilisateur·rice';
L10n::$locales['User has been successfully updated.'] = 'L\'utilisateur·rice a été mis·e à jour.';
L10n::$locales['User "%s" already exists.'] = 'L\'utilisateur·rice "%s" existe déjà.';
L10n::$locales['User has been successfully created.'] = 'L\'utilisateur·rice a été créé·e.';
L10n::$locales['User has no permission, he will not be able to login yet. See below to add some.'] = 'L\'utilisateur·rice n\'a aucune permission, elle ou il ne sera pas en mesure de se connecter. Voir plus bas pour en ajouter.';
L10n::$locales['User is disabled, he will not be able to login yet.'] = 'L\'utilisateur·rice est désactivé·e, il ou elle ne pourra pas se connecter.';
L10n::$locales['User profile'] = 'Profil utilisateur·rice';
L10n::$locales['Login'] = 'Identifiant';
L10n::$locales['User ID:'] = 'Identifiant (login) :';
L10n::$locales['If you change your username, you will have to log in again.'] = 'Si vous changez votre login, vous devrez vous identifier à nouveau.';
L10n::$locales['Warning:'] = 'Attention :';
L10n::$locales['Password change required to connect'] = 'Changement de mot de passe requis à la prochaine connexion';
L10n::$locales['Last Name:'] = 'Nom :';
L10n::$locales['First Name:'] = 'Prénom :';
L10n::$locales['Display name:'] = 'Pseudonyme :';
L10n::$locales['Mandatory for password recovering procedure.'] = 'Indispensable pour la procédure de récupération de mot de passe.';
L10n::$locales['Alternate emails (comma separated list):'] = 'Emails alternatifs (liste séparée par des virgules) :';
L10n::$locales['Invalid emails will be automatically removed from list.'] = 'Les emails invalides seront automatiquement retirés de la liste.';
L10n::$locales['Alternate URLs (comma separated list):'] = 'URLs alternatives (liste séparée par des virgules) :';
L10n::$locales['Invalid URLs will be automatically removed from list.'] = 'Les URLs invalides seront automatiquement retirées de la liste.';
L10n::$locales['Interface'] = 'Interface';
L10n::$locales['Timezone:'] = 'Fuseau horaire :';
L10n::$locales['Edition'] = 'Édition';
L10n::$locales['Preferred format:'] = 'Format d\'édition préféré :';
L10n::$locales['Default entry status:'] = 'État des entrées par défaut :';
L10n::$locales['Entry edit field height:'] = 'Taille de la zone d\'édition :';
L10n::$locales['Miscellaneous'] = 'Divers';
L10n::$locales['Your administrator password:'] = 'Votre mot de passe administrateur·rice :';
L10n::$locales['Save and create another'] = 'Enregistrer et créer un·e nouveau·elle';
L10n::$locales['No permissions so far.'] = 'Aucune permission pour le moment.';
L10n::$locales['Permissions'] = 'Permissions';
L10n::$locales['%s is super admin (all rights on all blogs).'] = '%s est super administrateur·rice (tous les droits sur tous les blogs).';
L10n::$locales['Add new permissions'] = 'Ajouter de nouvelles permissions';
L10n::$locales['Back to user profile'] = 'Retour au profil de l\'utilisateur·rice';
L10n::$locales['Direct links'] = 'Liens directs';
L10n::$locales['List of posts'] = 'Liste des billets';
L10n::$locales['List of comments'] = 'Liste des commentaires';
L10n::$locales['Light'] = 'Clair';
L10n::$locales['Dark'] = 'Sombre';
L10n::$locales['Automatic'] = 'Automatique';
L10n::$locales['Smallest'] = 'Très petite';
L10n::$locales['Smaller'] = 'Petite';
L10n::$locales['Larger'] = 'Grande';
L10n::$locales['Largest'] = 'Très grande';
L10n::$locales['Blog description (in blog parameters)'] = 'La description du blog (paramètres du blog)';
L10n::$locales['Category description'] = 'La description des catégories';
L10n::$locales['If you want to change your email or password you must provide your current password.'] = 'Si vous voulez modifier votre adresse email ou votre mot de passe, vous devez indiquer votre mot de passe actuel.';
L10n::$locales['Personal information has been successfully updated.'] = 'Vos informations personnelles ont été enregistrées.';
L10n::$locales['Personal options has been successfully updated.'] = 'Vos options personnelles ont été enregistrées.';
L10n::$locales['Dashboard options has been successfully updated.'] = 'Vos options du tableau de bord ont été enregistrées.';
L10n::$locales['No favorite selected'] = 'Aucun favori sélectionné';
L10n::$locales['Favorites have been successfully added.'] = 'Les favoris ont été ajoutés.';
L10n::$locales['Favorites have been successfully removed.'] = 'Les favoris ont été retirés.';
L10n::$locales['Favorites have been successfully updated.'] = 'Les favoris ont été mis à jour.';
L10n::$locales['Default favorites have been successfully updated.'] = 'Les favoris par défaut ont été enregistrés.';
L10n::$locales['Dashboard items order have been successfully reset.'] = 'Le positionnement des éléments du tableau de bord a été réinitialisé.';
L10n::$locales['Are you sure you want to remove selected favorites?'] = 'Êtes-vous sûr·e de vouloir retirer les favoris sélectionnés ?';
L10n::$locales['Change my password'] = 'Changer mon mot de passe';
L10n::$locales['Confirm new password:'] = 'Confirmer le nouveau mot de passe :';
L10n::$locales['Your current password:'] = 'Votre mot de passe actuel :';
L10n::$locales['If you have changed your email or password you must provide your current password to save these modifications.'] = 'Si vous avez modifié votre adresse email ou votre mot de passe, vous devez indiquer votre mot de passe actuel pour enregistrer ces modifications.';
L10n::$locales['My profile'] = 'Mon profil';
L10n::$locales['Language for my interface:'] = 'Langue de mon interface :';
L10n::$locales['My timezone:'] = 'Mon fuseau horaire :';
L10n::$locales['Update my profile'] = 'Mettre à jour mon profil';
L10n::$locales['List'] = 'Liste';
L10n::$locales['Order by'] = 'Trier par';
L10n::$locales['Sort'] = 'Tri';
L10n::$locales['Preferred editor for %s:'] = 'Éditeur préféré pour le format %s :';
L10n::$locales['Choose an editor'] = 'Choisissez un éditeur';
L10n::$locales['My options'] = 'Mes options';
L10n::$locales['Theme:'] = 'Thème :';
L10n::$locales['Activate enhanced uploader in media manager'] = 'Activer l\'interface avancée de la médiathèque';
L10n::$locales['Preview the entry being edited in a blank window or tab (depending on your browser settings).'] = 'Prévisualiser l\'entrée en cours d\'édition dans une fenêtre ou un onglet vierge (selon les paramètres de votre navigateur).';
L10n::$locales['Disable javascript powered drag and drop for ordering items'] = 'Désactiver le glisser-déposer pour ordonnancer les éléments';
L10n::$locales['If checked, numeric fields will allow to type the elements\' ordering number.'] = 'Si cette option est cochée, des champs numériques permettront d\'indiquer la position des éléments.';
L10n::$locales['Hide all secondary information and notes'] = 'Cacher les informations secondaires et les notes';
L10n::$locales['Hide help button'] = 'Cacher le bouton d\'aide';
L10n::$locales['Font size:'] = 'Taille de police de caractère :';
L10n::$locales['Use operating system font'] = 'Utiliser la police système';
L10n::$locales['Number of recent folders proposed in media manager:'] = 'Nombre de dossiers récents proposés dans la médiathèque :';
L10n::$locales['Set to 0 (zero) to ignore, displayed only if Javascript is enabled in your browser.'] = 'Régler à 0 (zéro) pour ignorer, affiché seulement si Javascript est activé dans votre navigateur.';
L10n::$locales['Do not use standard favicon'] = 'Ne pas utiliser le favicon standard de Dotclear';
L10n::$locales['This will be applied for all users'] = 'Ce choix sera appliqué pour tous les utilisateur·rice·s';
L10n::$locales['Disable Ad-blocker check'] = 'Désactiver la détection de bloqueurs de publicité';
L10n::$locales['Some ad-blockers (Ghostery, Adblock plus, uBloc origin, …) may interfere with some feature as inserting link or media in entries with CKEditor; in this case you should disable it for this Dotclear installation (backend only). Note that Dotclear do not add ads ot trackers in the backend.'] = 'Certains bloqueurs de publicité (Ghostery, Adblock plus, uBloc origin, …) peuvent interférer avec certaines fonctionnalités comme l\'insertion de lien ou de média dans les entrées avec CKEditor ; dans ce cas vous devriez les désactiver pour cette installation Dotclear (administration seulement). Notez que Dotclear n\'ajoute aucune publicité ou pisteur dans les pages de l\'administration.';
L10n::$locales['Note also that deactivating this detection of ad blockers will not deactivate the installed ad blockers. Dotclear cannot interfere with the operation of browser extensions!'] = 'Notez également que la désactivation de cette détection des bloqueurs de publicité ne désactivera pas les bloqueurs de publicité installés. Dotclear ne peut pas interférer avec le fonctionnement des extensions de navigateur !';
L10n::$locales['Quick menu character:'] = 'Caractère d\'accès rapide aux menus :';
L10n::$locales['Leave empty to use the default character <kbd>:</kbd>'] = 'Laisser vide pour utiliser le caractère par défaut <kbd>:</kbd>';
L10n::$locales['Keep the main menu at the top of the page as much as possible'] = 'Conserver le menu principal en haut de la page autant que possible';
L10n::$locales['Optional columns displayed in lists'] = 'Colonnes optionnelles affichées dans les listes';
L10n::$locales['Options for lists'] = 'Options des listes';
L10n::$locales['Apply filters on the fly'] = 'Appliquer les filtres à la volée';
L10n::$locales['Enable WYSIWYG mode'] = 'Activer l\'éditeur visuel';
L10n::$locales['Display editor\'s toolbar at bottom of textarea (if possible)'] = 'Afficher la barre d\'outil des éditeurs en bas de la zone de saisie (si possible)';
L10n::$locales['Use HTML editor for:'] = 'Utiliser l\'éditeur HTML pour :';
L10n::$locales['Other options'] = 'Autres options';
L10n::$locales['Save my options'] = 'Enregistrer mes options';
L10n::$locales['position of %s'] = 'position de %s';
L10n::$locales['Save order'] = 'Enregistrer l\'ordre';
L10n::$locales['Delete selected favorites'] = 'Retirer les favoris sélectionnés';
L10n::$locales['If you are a super administrator, you may define this set of favorites to be used by default on all blogs of this installation.'] = 'Si vous êtes super administrateur·rice, vous pouvez faire de ces favoris le jeu par défaut pour tous les blogs de l\'installation.';
L10n::$locales['Define as default favorites'] = 'Définir comme favoris par défaut';
L10n::$locales['Currently no personal favorites.'] = 'La liste de vos favoris est vide pour le moment.';
L10n::$locales['(default favorite)'] = '(favori par défaut)';
L10n::$locales['Add to my favorites'] = 'Ajouter à mes favoris';
L10n::$locales['Other available favorites'] = 'Autres favoris disponibles';
L10n::$locales['Menu'] = 'Menu';
L10n::$locales['Display favorites at the top of the menu'] = 'Afficher les favoris en haut du menu';
L10n::$locales['Dashboard icons'] = 'Icônes du tableau de bord';
L10n::$locales['Display dashboard icons'] = 'Afficher les icônes du tableau de bord';
L10n::$locales['Dashboard modules'] = 'Modules du tableau de bord';
L10n::$locales['Display documentation links'] = 'Afficher les liens vers la documentation';
L10n::$locales['Display donate links'] = 'Afficher les liens de don';
L10n::$locales['Display Dotclear news'] = 'Afficher les nouvelles de Dotclear';
L10n::$locales['Display quick entry form'] = 'Afficher le formulaire d\'entrée rapide';
L10n::$locales['Do not display Dotclear updates'] = 'Ne pas afficher les mises à jour de Dotclear';
L10n::$locales['Save my dashboard options'] = 'Enregistrer les options de mon tableau de bord';
L10n::$locales['Dashboard items order'] = 'Positionnement des éléments du tableau de bord';
L10n::$locales['Reset dashboard items order'] = 'Réinitialiser le positionnement des éléments du tableau de bord';
L10n::$locales['Set permissions'] = 'Définir les permissions';
L10n::$locales['User has been successfully removed.'] = 'L\'utilisateur·rice a été supprimé·e.';
L10n::$locales['The permissions have been successfully updated.'] = 'Les permissions ont été mises à jour.';
L10n::$locales['Selected users action:'] = 'Action sur les utilisateur·rice·s sélectionné·e·s :';
L10n::$locales['Back to users list'] = 'Retour à la liste des utilisateur·rice·s';
L10n::$locales['No blog or user given.'] = 'Vous n\'avez pas indiqué de blog ou d\'utilisateur';
L10n::$locales['User has been successfully enabled.'] = 'L\'utilisateur·rice a été activé·e avec succès.';
L10n::$locales['You cannot disable yourself.'] = 'Vous ne pouvez pas vous désactiver vous-même.';
L10n::$locales['User has been successfully deleted.'] = 'L\'utilisateur·rice a été supprimé·e.';
L10n::$locales['You cannot delete yourself.'] = 'Vous ne pouvez pas vous supprimer vous-même.';
L10n::$locales['Choose one or more blogs to which you want to give permissions to users %s.'] = 'Choisissez un ou plusieurs blogs pour lesquels les utilisateur·rice·s suivant·e·s auront des permissions : %s.';
L10n::$locales['select'] = 'sélectionner';
L10n::$locales['Entries'] = 'Entrées';
L10n::$locales['You are about to change permissions on the following blogs for users %s.'] = 'Vous allez changer les permissions des utilisateur·rice·s %s pour ces blogs.';
L10n::$locales['Validate permissions'] = 'Valider les permissions';
L10n::$locales['Please set a master key (DC_MASTER_KEY) in configuration file.'] = 'Veuillez indiquer une clé de référence (DC_MASTER_KEY) dans le fichier de configuration.';
L10n::$locales['Dotclear is already installed.'] = 'Dotclear est déjà installé.';
L10n::$locales['Dotclear cannot be installed.'] = 'Dotclear ne peut pas être installé.';
L10n::$locales['Invalid email address'] = 'Adresse email incorrecte';
L10n::$locales['My first blog'] = 'Mon premier blog';
L10n::$locales['%A, %B %e %Y'] = '%A %e %B %Y';
L10n::$locales['Welcome to Dotclear!'] = 'Bienvenue sur Dotclear !';
L10n::$locales['This is your first entry. When you\'re ready to blog, log in to edit or delete it.'] = 'Ceci est votre première entrée. Quand vous serez prêt à bloguer, connectez-vous pour la modifier ou la supprimer.';
L10n::$locales['Dotclear Team'] = 'L\'équipe Dotclear';
L10n::$locales['<p>This is a comment.</p>
<p>To delete it, log in and view your blog\'s comments. Then you might remove or edit it.</p>'] = '<p>Ceci est un commentaire</p>
<p>Pour le supprimer, connectez-vous et affichez les commentaires de votre blog. Vous pourrez alors le supprimer ou le modifier.</p>';
L10n::$locales['Dotclear Install'] = 'Installation de Dotclear';
L10n::$locales['show'] = 'voir';
L10n::$locales['Dotclear installation'] = 'Installation de Dotclear';
L10n::$locales['Cache directory %s is not writable.'] = 'Le répertoire de cache %s n\'est pas accessible en écriture.';
L10n::$locales['Configuration file has been successfully created.'] = 'Le fichier de configuration a été créé.';
L10n::$locales['User information'] = 'Informations utilisateur';
L10n::$locales['Please provide the following information needed to create the first user.'] = 'Merci de fournir les informations suivantes pour créer le ou la premier·ière utilisateur·rice.';
L10n::$locales['Username and password'] = 'Identifiant et mot de passe';
L10n::$locales['All done!'] = 'C\'est terminé !';
L10n::$locales['Dotclear has been successfully installed. Here is some useful information you should keep.'] = 'Dotclear est installé. Conservez les informations suivantes précieusement.';
L10n::$locales['Your account'] = 'Votre compte';
L10n::$locales['Your blog'] = 'Votre blog';
L10n::$locales['Blog address:'] = 'Adresse du blog :';
L10n::$locales['Administration interface:'] = 'Interface d\'administration :';
L10n::$locales['Manage your blog now'] = 'Gérez votre blog';
L10n::$locales['Installation can not be completed'] = 'L\'installation ne peut pas être terminée';
L10n::$locales['For the said reasons, Dotclear can not be installed. Please refer to <a href="%s">the documentation</a> to learn how to correct the problem.'] = 'Pour ces raisons, Dotclear ne peut pas être installé. Veuillez vous référer à <a href="%s">la documentation</a> pour savoir comment corriger le problème.';
L10n::$locales['Path <strong>%s</strong> is not writable.'] = 'Le chemin <strong>%s</strong> n\'est pas accessible en écriture.';
L10n::$locales['Dotclear installation wizard could not create configuration file for you. You must change folder right or create the <strong>config.php</strong> file manually, please refer to <a href="%s">the documentation</a> to learn how to do this.'] = 'L\'assistant d\'installation de Dotclear n\'a pas pu créer le fichier de configuration pour vous. Vous devez changer de dossier ou créer le fichier <strong>config.php</strong> manuellement, veuillez vous référer à la <a href="%s">documentation</a> pour savoir comment faire.';
L10n::$locales['Cannot write "%s" directory.'] = 'Impossible d\'écrire dans le répertoire "%s".';
L10n::$locales['Master email is not valid.'] = 'Adresse email principale incorrecte.';
L10n::$locales['File %s does not exist.'] = 'Le fichier %s n\'existe pas.';
L10n::$locales['Cannot write %s file.'] = 'Impossible d\'écrire le fichier %s.';
L10n::$locales['Dotclear installation wizard'] = 'Assistant d\'installation de Dotclear';
L10n::$locales['Welcome'] = 'Bienvenue';
L10n::$locales['To complete your Dotclear installation and start writing on your blog, we just need to know how to access your database and who you are. Just fill this two steps wizard with this information and we will be done.'] = 'Pour achever votre installation de Dotclear, il ne manque plus que les informations concernant votre base de données, puis vos informations personnelles. Remplissez simplement les deux formulaires suivants et vous pourrez commencer à utiliser votre blog.';
L10n::$locales['Attention:'] = 'Attention :';
L10n::$locales['this wizard may not function on every host. If it does not work for you, please refer to <a href="%s">the documentation</a> to learn how to create the <strong>config.php</strong> file manually.'] = 'cet assistant peut ne pas fonctionner sur tous les hôtes. Si cela ne fonctionne pas pour vous, veuillez vous référer à la <a href="%s">documentation</a> pour apprendre à créer le fichier <strong>config.php</strong> manuellement.';
L10n::$locales['System information'] = 'Informations système';
L10n::$locales['Please provide the following information needed to create your configuration file.'] = 'Merci de fournir les informations suivantes qui sont nécessaires pour créer votre fichier de configuration.';
L10n::$locales['Database type:'] = 'Type de base de données :';
L10n::$locales['MySQLi'] = 'MySQLi';
L10n::$locales['MySQLi (full UTF-8)'] = 'MySQLi (UTF-8 complet)';
L10n::$locales['PostgreSQL'] = 'PostgreSQL';
L10n::$locales['SQLite'] = 'SQLite';
L10n::$locales['Driver'] = 'Pilote';
L10n::$locales['Database Host Name:'] = 'Nom d\'hôte de la base de données :';
L10n::$locales['Database Name:'] = 'Nom de la base de données :';
L10n::$locales['Database User Name:'] = 'Nom d\'utilisateur·rice de la base de données :';
L10n::$locales['Database Password:'] = 'Mot de passe de la base de données :';
L10n::$locales['Database Tables Prefix:'] = 'Préfixe des tables de la base de données :';
L10n::$locales['Prefix'] = 'Préfixe';
L10n::$locales['Master Email: (used as sender for password recovery)'] = 'Email principal : (utilisé pour l\'envoi pour la récupération de mot de passe)';
L10n::$locales['Continue'] = 'Continuer';
L10n::$locales['Dotclear update'] = 'Mise à jour de Dotclear';
L10n::$locales['Precheck update error'] = 'Erreur avant mise à jour';
L10n::$locales['It seems that backup directory does not exist, upgrade can not be performed.'] = 'Il semble que le répertoire de sauvegarde n\'existe pas, la mise à niveau ne peut pas être effectuée.';
L10n::$locales['It seems that there are no "digests" file on your system, upgrade can not be performed.'] = 'Il semble qu\'il n\'y ait pas de fichier "digests" sur votre système, la mise à jour ne peut pas être effectuée.';
L10n::$locales['Downloaded Dotclear archive seems to be corrupted. Try <a %s>download it</a> again.'] = 'L\'archive de Dotclear téléchargée semble être corrompue. Essayer de la <a %s>télécharger</a> à nouveau.';
L10n::$locales['If this problem persists try to <a href="%s">update manually</a>.'] = 'Si le problème persiste, essayez de <a href="%s">mettre à jour manuellement</a>.';
L10n::$locales['The following files of your Dotclear installation have been modified so we won\'t try to update your installation. Please try to <a href="%s">update manually</a>.'] = 'Les fichiers suivants de votre installation Dotclear ont été modifiés et nous n\'essayons pas de mettre à jour votre installation. Veuillez essayer de <a href="%s">mettre à jour manuellement</a>.';
L10n::$locales['(<a href="%s">You can bypass this warning by updating installation disgets file</a>).'] = '(<a href="%s">Vous pouvez contourner cet avertissement en mettant à jour le fichier d\'installation digests</a>).';
L10n::$locales['The following files of your Dotclear installation are not readable. Please fix this or try to make a backup file named %s manually.'] = 'Les fichiers suivants de votre installation de Dotclear ne peuvent pas être lus. Veuillez corriger ceci ou créer un fichier de backup nommé %s manuellement.';
L10n::$locales['The following files of your Dotclear installation cannot be written. Please fix this or try to <a href="%s">update manually</a>.'] = 'Les fichiers suivants de votre installation Dotclear ne peuvent pas être écrits. Veuillez corriger ce problème ou essayer de <a href="%s">mettre à jour manuellement</a>.';
L10n::$locales['No newer Dotclear version available.'] = 'Aucune nouvelle version de Dotclear n\'est disponible.';
L10n::$locales['Force checking update Dotclear'] = 'Forcer la vérification de mise à jour de Dotclear';
L10n::$locales['Required PHP version %s or higher'] = 'Version requise de PHP %s ou supérieure';
L10n::$locales['Release note'] = 'Note de mise à jour';
L10n::$locales['Select intermediate stable release to update to:'] = 'Sélectionnez la version stable intermédiaire à mettre à jour :';
L10n::$locales['There are no additionnal informations about releases listed here, you should carefully read the information post associated with selected release on Dotclear\'s blog.'] = 'Il n\'y a aucune information additionnelle sur les versions listées ici, vous devriez lire attentivement le message d\'information associé à la version sélectionnée sur le blog de Dotclear.';
L10n::$locales['Are you sure to update to version %s?'] = 'Êtes-vous sûr de vouloir mettre à jour vers la version %s?';
L10n::$locales['Update Dotclear'] = 'Mettre à jour Dotclear';
L10n::$locales['Congratulations, you\'re one click away from the end of the update.'] = 'Félicitations, vous êtes à un clic de la fin de la mise à jour.';
L10n::$locales['Finish the update.'] = 'Finir la mise à jour.';
L10n::$locales['Upgrade'] = 'Mise à jour';
L10n::$locales['Back to normal dashboard'] = 'Retourner au tableau de bord normal';
L10n::$locales['Backups and restore'] = 'Sauvegarde et restauration';
L10n::$locales['Unable to delete file %s'] = 'Impossible de supprimer le fichier %s';
L10n::$locales['Backup deleted.'] = 'Sauvegarde supprimée.';
L10n::$locales['Backup restored.'] = 'Sauvegarde restaurée.';
L10n::$locales['There are no backups available.'] = 'Aucune sauvegarde n\'est disponible.';
L10n::$locales['Backups of previously updates'] = 'Sauvegarde des mises à jour précédentes';
L10n::$locales['Revert to selected file'] = 'Rétablir le fichier sélectionné';
L10n::$locales['Delete selected file'] = 'Supprimer le fichier sélectionné';
L10n::$locales['Please note that reverting your Dotclear version may have some unwanted side-effects. Consider reverting only if you experience strong issues with this new version.'] = 'Merci de noter que rétablir votre version de Dotclear peut avoir des effets indésirables. N\'envisagez ceci que si vous rencontrez d\'importantes difficultés avec cette nouvelle version.';
L10n::$locales['You should not revert to version prior to last one (%s).'] = 'Vous ne devez pas rétablir une version précédant la dernière (%s).';
L10n::$locales['Delete all files but last'] = 'Supprimer tous les fichiers sauf le dernier';
L10n::$locales['Templates cache directory emptied.'] = 'Le répertoire de cache des « templates » a été vidé.';
L10n::$locales['Repositories cache directory emptied.'] = 'Le répertoire cache des dépôts a été vidé.';
L10n::$locales['Dotclear versions cache directory emptied.'] = 'Le répertoire de cache des versions de Dotclear a été vidé.';
L10n::$locales['Cache management'] = 'Gestion du cache';
L10n::$locales['Cache folders'] = 'Dossiers de cache';
L10n::$locales['Empty templates cache directory'] = 'Vider le répertoire de cache des « templates »';
L10n::$locales['Empty repositories cache directory'] = 'Vider le répertoire cache des dépôts';
L10n::$locales['Empty Dotclear versions cache directory'] = 'Vider le répertoire de cache des versions de Dotclear';
L10n::$locales['The updates have been performed.'] = 'Les mises à jour ont été effectuées.';
L10n::$locales['No changed filed have been found, nothing to do!'] = 'Aucun fichier modifié n\'a été trouvé, il n\'y a rien à faire !';
L10n::$locales['This tool has already been run once.'] = 'Cet outil a déjà été utilisé une fois.';
L10n::$locales['Files'] = 'Médias';
L10n::$locales['Corrupted files'] = 'Fichiers corrompus';
L10n::$locales['Download backup of digests file.'] = 'Télécharger une copie de sauvegarde du fichier d\'analyse.';
L10n::$locales['Digests file is up to date.'] = 'Le fichier Digests est à jour.';
L10n::$locales['The following files will have their checksum faked:'] = 'Les fichiers suivants verront leur somme de contrôle falsifiée :';
L10n::$locales['The following files digests will have their checksum cleaned:'] = 'La somme de contrôle des fichiers suivants sera nettoyée :';
L10n::$locales['Still ok to continue'] = 'Il est encore possible de continuer';
L10n::$locales['Remove the backup digest file, I want to play again'] = 'Supprimez le fichier de sauvegarde, je veux rejouer';
L10n::$locales['I have read and understood the disclaimer and wish to continue anyway.'] = 'J\'ai lu et compris la clause de non-responsabilité et je souhaite continuer malgré tout.';
L10n::$locales['Installed Dotclear version is %s'] = 'La version installée de Dotclear est %s';
L10n::$locales['Installed PHP version is %s, next Dotclear release required %s or earlier.'] = 'La version de PHP installée est %s, la prochaine version de Dotclear doit être %s ou postérieure.';
L10n::$locales['Backup directory "%s" does not exist or is not writable.'] = 'Le répertoire de sauvegarde "%s" n\'existe pas ou n\'est pas accessible en écriture.';
L10n::$locales['Your are using Sqlite database driver, Database structure upgrade will NOT be performed.'] = 'Vous utilisez le pilote de base de données Sqlite, la mise à jour de la structure de la base de données ne sera PAS effectuée.';
L10n::$locales['Your are using developement release, some features are not available.'] = 'Vous utilisez une version de développement, certaines fonctionnalités ne sont pas disponibles.';
L10n::$locales['Dotclear digests file "%s" is not readable.'] = 'Le fichier Dotclear digests "%s" n\'est pas lisible.';
L10n::$locales['Official plugins repository could not be updated as there is no URL set in configuration.'] = 'Le dépôt officiel de plugins n\'a pas pu être mis à jour car il n\'y a pas d\'URL définie dans la configuration.';
L10n::$locales['Do you read the official post about this release on Dotclear\'s blog?'] = 'Avez-vous lu le message officiel à propos de cette version sur le blog de Dotclear?';
L10n::$locales['Does your system support this release requirements like PHP version?'] = 'Votre système prend-il en charge les exigences de cette version, comme la version de PHP ?';
L10n::$locales['Does your plugins and themes are up to date?'] = 'Vos plugins et thèmes sont-ils à jour ?';
L10n::$locales['Note if some plugins crash your installation, go back here to disable or to remove or to update them.'] = 'Notez que si certains plugins bloquent votre installation, revenez ici pour les désactiver, les supprimer ou les mettre à jour.';
L10n::$locales['Once update done, do not forget to check and update blogs themes.'] = 'Une fois la mise à jour effectuée, n\'oubliez pas de vérifier et de mettre à jour les thèmes des blogs.';
L10n::$locales['Before performing update you should take into account some informations listed bellow:'] = 'Avant d\'effectuer la mise à jour, vous devez prendre en compte certaines informations énumérées ci-dessous :';
L10n::$locales['Install or upgrade languages from available languages'] = 'Installer ou mettre à jour les langues disponibles';
L10n::$locales['Install or upgrade languages from an upload a zip file'] = 'Installer ou mettre à jour les langues à partir d\'un fichier zip';
L10n::$locales['Some plugins could not be loaded.'] = 'Certains plugins n\'ont pas pu être chargés.';
L10n::$locales['There is no module to check'] = 'Il n\'y a pas de module à vérifier';
L10n::$locales['Store version'] = 'Version du dépôt';
L10n::$locales['Check stores versions'] = 'Vérifier les versions des dépôts';
L10n::$locales['Check lastest stores versions'] = 'Vérifier les dernières versions des dépôts';
L10n::$locales['You can check repositories for modules written explicitly for Dotclear release greater than %s.'] = 'Vous pouvez vérifier les dépôts pour les modules écrits explicitement pour une version de Dotclear supérieure à %s.';
L10n::$locales['No version available'] = 'Pas de version disponible';
L10n::$locales['No update available'] = 'Pas de mise à jour disponible';
L10n::$locales['Newer version available'] = 'Nouvelle version disponible';
L10n::$locales['Modules list'] = 'Liste des modules';
L10n::$locales['Latest version'] = 'Dernière version';
L10n::$locales['Written for Dotclear'] = 'Ecrit pour Dotclear';
L10n::$locales['Grow up from version %s successfully replayed.'] = 'Mise à niveau à partir de la version %s rejouée avec succès.';
L10n::$locales['Replay update actions'] = 'Réexécuter les actions de mise à jour';
L10n::$locales['Replay grow up action from version:'] = 'Réexécution de l\'action de mise à niveau à partir de la version:';
L10n::$locales['Replay version lower than the last one can break your installation, do it at your own risk.'] = 'Rejouer la version inférieure à la dernière peut casser votre installation, le faire à vos propres risques.';
L10n::$locales['Dotclear %s is available.'] = 'Dotclear %s est disponible.';
L10n::$locales['PHP version is %1$s (%2$s or earlier needed).'] = 'La version de PHP est %1$s (%2$s ou plus récente nécessaire).';
L10n::$locales['To upgrade your Dotclear installation simply click on the following button. A backup file of your current installation will be created in your root directory.'] = 'Pour mettre à jour votre installation de Dotclear, cliquez sur le bouton suivant. Un fichier de sauvegarde de votre installation actuelle sera créé dans votre répertoire principal.';
L10n::$locales['This update may potentially require some precautions, you should carefully read the information post associated with this release (see above).'] = 'Cette mise à jour peut potentiellement nécessiter des précautions, vous devriez lire attentivement le billet d\'information associé à cette version (voir ci-dessus).';
L10n::$locales['unknown'] = 'inconnu';
L10n::$locales['Read'] = 'Lire';
L10n::$locales['Online'] = [
	'En ligne',
	'En ligne',
];
L10n::$locales['Offline'] = [
	'Hors ligne',
	'Hors ligne',
];
L10n::$locales['Removed'] = [
	'Retiré',
	'Retirés',
];
L10n::$locales['Undefined'] = [
	'Non défini',
	'Non définis',
];
L10n::$locales['Published'] = [
	'Publié',
	'Publiés',
];
L10n::$locales['Unpublished'] = [
	'Non publié',
	'Non publiés',
];
L10n::$locales['Pending'] = [
	'En attente',
	'En attente',
];
L10n::$locales['Junk'] = [
	'Indésirable',
	'Indésirables',
];
L10n::$locales['Scheduled'] = [
	'Programmé',
	'Programmés',
];
L10n::$locales['Enabled'] = [
	'Activé·e',
	'Activé·es',
];
L10n::$locales['Disabled'] = [
	'Désactivé·e',
	'Désactivé·es',
];
