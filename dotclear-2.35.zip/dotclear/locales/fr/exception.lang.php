<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Site temporarily unavailable'] = 'Site temporairement indisponible';
L10n::$locales['Bad Request'] = 'Mauvaise requête';
L10n::$locales['Blog handling error'] = 'Erreur de gestion du blog';
L10n::$locales['Application configuration error'] = 'Erreur de configuration de l\'application';
L10n::$locales['Conflict'] = 'Conflit';
L10n::$locales['Application context error'] = 'Erreur de contexte de l\'application';
L10n::$locales['Database connection error'] = 'Erreur de connexion à la base de données';
L10n::$locales['Not Found'] = 'Non trouvé';
L10n::$locales['Precondition Failed'] = 'Échec de la précondition';
L10n::$locales['Application process error'] = 'Erreur du processus de l\'application';
L10n::$locales['Session handling error'] = 'Erreur de gestion de la session';
L10n::$locales['Template handling error'] = 'Erreur de gestion du template';
L10n::$locales['Unauthorized'] = 'Non autorisé';
L10n::$locales['Internal Server Error'] = 'Erreur interne du serveur';
L10n::$locales['<p>This either means that the username and password information in your <strong>config.php</strong> file is incorrect or we can\'t contact the database server at "<em>%1$s</em>". This could mean your host\'s database server is down.</p><ul><li>Are you sure you have the correct username and password?</li><li>Are you sure that you have typed the correct hostname?</li><li>Are you sure that the database server is running?</li></ul><p>If you\'re unsure what these terms mean you should probably contact your host. If you still need help you can always visit the <a href="%2$s">Dotclear Support Forums</a>.</p>'] = '<p>Cela signifie soit que les informations relatives au nom d\'utilisateur et au mot de passe dans votre fichier <strong>config.php</strong> sont incorrectes, soit que nous ne pouvons pas contacter le serveur de base de données à l\'adresse "<em>%1$s</em>". Cela peut signifier que le serveur de base de données de votre hébergeur est en panne.</p><ul><li>Êtes-vous sûr d\'avoir le bon nom d\'utilisateur et le bon mot de passe ?</li><li>Êtes-vous sûr d\'avoir tapé le bon nom d\'hôte ?</li><li>Êtes-vous sûr que le serveur de base de données fonctionne ?</li></ul><p>Si vous n\'êtes pas sûr de la signification de ces termes, vous devriez probablement contacter votre hébergeur. Si vous avez encore besoin d\'aide, vous pouvez toujours visiter les <a href="%2$s">forums de support de Dotclear</a>.</p>';
L10n::$locales['Dotclear release file is not readable'] = 'Le fichier de version de Dotclear n\'a pas pu être lu';
L10n::$locales['Dotclear is not installed or failed to load config file.'] = 'Dotclear n\'est pas installé ou n\'a pas réussi à charger le fichier de configuration.';
L10n::$locales['%s cryptographic algorithm configured is not strong enough, please change it.'] = 'L\'algorithme de chiffrement %s configuré n\'est pas assez fort, veuillez le changer.';
L10n::$locales['%s directory does not exist. Please create it.'] = 'Le répertoire %s n\'existe pas. Veuillez le créer.';
L10n::$locales['Dotclear release key %s was not found'] = 'La clé de version %s n\'a pas été trouvée';
L10n::$locales['Application can not be started twice.'] = 'L\'application ne peut pas être lancée deux fois.';
L10n::$locales['Unable to load deprecated core'] = 'Impossible de charger le noyau déprécié';
L10n::$locales['<p>We apologize for this temporary unavailability.<br>Thank you for your understanding.</p>'] = '<p>Nous nous excusons pour cette indisponibilité temporaire.<br>Nous vous remercions de votre compréhension.</p>';
L10n::$locales['Unable to find class %s'] = 'Impossible de trouver la classe %s';
L10n::$locales['Unable to initialize class %s'] = 'Impossible d\'initialiser la classe %s';
