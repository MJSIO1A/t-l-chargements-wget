<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['%Y-%m-%d %H:%M'] = '%d/%m/%Y %H:%M';
L10n::$locales['_Jan'] = 'janv.';
L10n::$locales['_Feb'] = 'févr.';
L10n::$locales['_Mar'] = 'mars';
L10n::$locales['_Apr'] = 'avr.';
L10n::$locales['_May'] = 'mai';
L10n::$locales['_Jun'] = 'juin';
L10n::$locales['_Jul'] = 'juil.';
L10n::$locales['_Aug'] = 'août';
L10n::$locales['_Sep'] = 'sept.';
L10n::$locales['_Oct'] = 'oct.';
L10n::$locales['_Nov'] = 'nov.';
L10n::$locales['_Dec'] = 'déc.';
L10n::$locales['January'] = 'janvier';
L10n::$locales['February'] = 'février';
L10n::$locales['March'] = 'mars';
L10n::$locales['April'] = 'avril';
L10n::$locales['May'] = 'mai';
L10n::$locales['June'] = 'juin';
L10n::$locales['July'] = 'juillet';
L10n::$locales['August'] = 'août';
L10n::$locales['September'] = 'septembre';
L10n::$locales['October'] = 'octobre';
L10n::$locales['November'] = 'novembre';
L10n::$locales['December'] = 'décembre';
L10n::$locales['_Mon'] = 'lun.';
L10n::$locales['_Tue'] = 'mar.';
L10n::$locales['_Wed'] = 'mer.';
L10n::$locales['_Thu'] = 'jeu.';
L10n::$locales['_Fri'] = 'ven.';
L10n::$locales['_Sat'] = 'sam.';
L10n::$locales['_Sun'] = 'dim.';
L10n::$locales['Monday'] = 'lundi';
L10n::$locales['Tuesday'] = 'mardi';
L10n::$locales['Wednesday'] = 'mercredi';
L10n::$locales['Thursday'] = 'jeudi';
L10n::$locales['Friday'] = 'vendredi';
L10n::$locales['Saturday'] = 'samedi';
L10n::$locales['Sunday'] = 'dimanche';
