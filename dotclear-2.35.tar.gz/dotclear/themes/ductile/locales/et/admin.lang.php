<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Täielik';
L10n::$locales['Home (first page)'] = 'Avaleht (esimene lehekülg)';
L10n::$locales['Home (other pages)'] = 'Avaleht (muud leheküljed)';
L10n::$locales['Entries for a category'] = 'Kategooria kanded';
L10n::$locales['Entries for a tag'] = 'Sildi kanded';
L10n::$locales['Search result entries'] = 'Otsingu tulemuse kirjed';
L10n::$locales['Month archive entries'] = 'Kuu arhiivi kanded';
L10n::$locales['Ductile primary'] = 'Plastiline esmane';
L10n::$locales['Ductile secondary'] = 'Plastiline sekundaarne';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = 'Gruusia';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'Mõju';
L10n::$locales['Monospace'] = 'Monospace';
L10n::$locales['none'] = 'ei ole';
L10n::$locales['javascript (Adobe)'] = 'javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'stiilileht (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'Teema konfiguratsioon uuendatud.';
L10n::$locales['Font family'] = 'Kirjatüüpkond';
L10n::$locales['Header'] = 'Pealkiri';
L10n::$locales['Hide blog description:'] = 'Peida blogi kirjeldus:';
L10n::$locales['Logo URL:'] = 'Logo URL:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'Ülemise menüü konfigureerimiseks minge <a href="%s">lihtsa menüü halduslehele</a>.';
L10n::$locales['Stickers'] = 'Kleebised';
L10n::$locales['Stickers (footer)'] = 'Kleebised (alumine osa)';
L10n::$locales['Image'] = 'Pilt';
L10n::$locales['Entries list types and limits'] = 'Kirjete loetelu tüübid ja piirangud';
L10n::$locales['Entries lists'] = 'Kannete nimekirjad';
L10n::$locales['Context'] = 'Kontekst';
L10n::$locales['Entries list type'] = 'Kannete loetelu tüüp';
L10n::$locales['Miscellaneous options'] = 'Mitmesugused valikud';
L10n::$locales['Comment preview is not mandatory:'] = 'Kommentaaride eelvaade ei ole kohustuslik:';
L10n::$locales['Presentation'] = 'Esitlus';
L10n::$locales['General settings'] = 'Üldised seaded';
L10n::$locales['Fonts'] = 'Kirjatüübid';
L10n::$locales['Main text'] = 'Põhitekst';
L10n::$locales['Main font:'] = 'Peamine font:';
L10n::$locales['Set to Default to use a webfont.'] = 'Webfonti kasutamiseks seadke väärtuseks Default (vaikimisi).';
L10n::$locales['Webfont family:'] = 'Webfont perekond:';
L10n::$locales['Webfont URL:'] = 'Webfont URL:';
L10n::$locales['Webfont API:'] = 'Webfont API:';
L10n::$locales['Secondary text'] = 'Teisene tekst';
L10n::$locales['Secondary font:'] = 'Sekundaarne font:';
L10n::$locales['Titles'] = 'Pealkirjad';
L10n::$locales['Blog title'] = 'Blogi pealkiri';
L10n::$locales['In bold:'] = 'Paksus kirjas:';
L10n::$locales['Font size (in em by default):'] = 'Kirjasuurus (vaikimisi em):';
L10n::$locales['Color:'] = 'Värv:';
L10n::$locales['Post title'] = 'Postituse pealkiri';
L10n::$locales['Titles without link'] = 'Pealkirjad ilma lingita';
L10n::$locales['Inside posts links'] = 'Sisemine postituste lingid';
L10n::$locales['Normal and visited links color:'] = 'Tavaliste ja külastatud linkide värv:';
L10n::$locales['Active, hover and focus links color:'] = 'Aktiivsete, hõljumise ja fookuslinkide värv:';
L10n::$locales['Mobile specific settings'] = 'Mobiilispetsiifilised seaded';
