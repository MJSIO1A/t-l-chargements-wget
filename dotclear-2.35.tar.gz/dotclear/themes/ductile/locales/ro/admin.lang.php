<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Complet';
L10n::$locales['Home (first page)'] = 'Acasă (prima pagină)';
L10n::$locales['Home (other pages)'] = 'Acasă (alte pagini)';
L10n::$locales['Entries for a category'] = 'Înscrieri pentru o categorie';
L10n::$locales['Entries for a tag'] = 'Intrări pentru o etichetă';
L10n::$locales['Search result entries'] = 'Intrări de rezultate ale căutării';
L10n::$locales['Month archive entries'] = 'Intrări în arhiva lunii';
L10n::$locales['Ductile primary'] = 'Ductil primar';
L10n::$locales['Ductile secondary'] = 'Ductil secundar';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = 'Georgia';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'Impact';
L10n::$locales['Monospace'] = 'Monospace';
L10n::$locales['none'] = 'niciunul';
L10n::$locales['javascript (Adobe)'] = 'javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'foaie de stil (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'Configurația temei a fost actualizată.';
L10n::$locales['Font family'] = 'Familia de fonturi';
L10n::$locales['Header'] = 'Antet';
L10n::$locales['Hide blog description:'] = 'Ascundeți descrierea blogului:';
L10n::$locales['Logo URL:'] = 'URL-ul logo-ului:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'Pentru a configura meniul de sus, accesați pagina de administrare <a href="%s">Simple Menu</a>.';
L10n::$locales['Stickers'] = 'Autocolante';
L10n::$locales['Stickers (footer)'] = 'Autocolante (footer)';
L10n::$locales['Image'] = 'Imagine';
L10n::$locales['Entries list types and limits'] = 'Tipuri de liste de intrări și limite';
L10n::$locales['Entries lists'] = 'Liste de intrări';
L10n::$locales['Context'] = 'Context';
L10n::$locales['Entries list type'] = 'Tipul listei de intrări';
L10n::$locales['Miscellaneous options'] = 'Opțiuni diverse';
L10n::$locales['Comment preview is not mandatory:'] = 'Previzualizarea comentariilor nu este obligatorie:';
L10n::$locales['Presentation'] = 'Prezentare';
L10n::$locales['General settings'] = 'Setări generale';
L10n::$locales['Fonts'] = 'Fonturi';
L10n::$locales['Main text'] = 'Textul principal';
L10n::$locales['Main font:'] = 'Font principal:';
L10n::$locales['Set to Default to use a webfont.'] = 'Setați la Default pentru a utiliza un font web.';
L10n::$locales['Webfont family:'] = 'Familia Webfont:';
L10n::$locales['Webfont URL:'] = 'URL-ul webfontului:';
L10n::$locales['Webfont API:'] = 'Webfont API:';
L10n::$locales['Secondary text'] = 'Text secundar';
L10n::$locales['Secondary font:'] = 'Font secundar:';
L10n::$locales['Titles'] = 'Titluri';
L10n::$locales['Blog title'] = 'Titlul blogului';
L10n::$locales['In bold:'] = 'În bold:';
L10n::$locales['Font size (in em by default):'] = 'Mărimea fontului (în em în mod implicit):';
L10n::$locales['Color:'] = 'Culoare:';
L10n::$locales['Post title'] = 'Titlul postului';
L10n::$locales['Titles without link'] = 'Titluri fără link';
L10n::$locales['Inside posts links'] = 'Linkuri pentru posturile din interior';
L10n::$locales['Normal and visited links color:'] = 'Culoarea legăturilor normale și a legăturilor vizitate:';
L10n::$locales['Active, hover and focus links color:'] = 'Culoarea legăturilor active, hover și focus:';
L10n::$locales['Mobile specific settings'] = 'Setări specifice pentru mobil';
