<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Plena';
L10n::$locales['Home (first page)'] = 'Hejmo (unua paĝo)';
L10n::$locales['Home (other pages)'] = 'Hejmo (aliaj paĝoj)';
L10n::$locales['Entries for a category'] = 'Enskriboj por kategorio';
L10n::$locales['Entries for a tag'] = 'Enskriboj por etikedo';
L10n::$locales['Search result entries'] = 'Serĉrezultaj enskriboj';
L10n::$locales['Month archive entries'] = 'Monataj arkivaj enskriboj';
L10n::$locales['Ductile primary'] = 'Duktila primara';
L10n::$locales['Ductile secondary'] = 'Duktila malĉefa';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = 'Kartvelio';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'Efiko';
L10n::$locales['Monospace'] = 'Monospaco';
L10n::$locales['none'] = 'neniu';
L10n::$locales['javascript (Adobe)'] = 'Javaskripto (Adobo)';
L10n::$locales['stylesheet (Google)'] = 'stilfolio (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'Temo-agordo ĝisdatigita.';
L10n::$locales['Font family'] = 'Tipara familio';
L10n::$locales['Header'] = 'Kapo';
L10n::$locales['Hide blog description:'] = 'Kaŝi blogan priskribon:';
L10n::$locales['Logo URL:'] = 'Logo URL:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'Por agordi la supran menuon iru al la <a href="%s">Administra paĝo de Simpla Menuo</a>.';
L10n::$locales['Stickers'] = 'Glumarkoj';
L10n::$locales['Stickers (footer)'] = 'Glumarkoj (piedpiedo)';
L10n::$locales['Image'] = 'Bildo';
L10n::$locales['Entries list types and limits'] = 'Enskriboj listigas tipojn kaj limojn';
L10n::$locales['Entries lists'] = 'Enskribo-listoj';
L10n::$locales['Context'] = 'Kunteksto';
L10n::$locales['Entries list type'] = 'Tipo de listo de enskriboj';
L10n::$locales['Miscellaneous options'] = 'Diversaj opcioj';
L10n::$locales['Comment preview is not mandatory:'] = 'Antaŭrigardo de komentoj ne estas deviga:';
L10n::$locales['Presentation'] = 'Prezento';
L10n::$locales['General settings'] = 'Ĝeneralaj Agordoj';
L10n::$locales['Fonts'] = 'Tiparoj';
L10n::$locales['Main text'] = 'Ĉefa teksto';
L10n::$locales['Main font:'] = 'Ĉefa tiparo:';
L10n::$locales['Set to Default to use a webfont.'] = 'Agordu al Defaŭlta por uzi rettiparo.';
L10n::$locales['Webfont family:'] = 'Rettiparo-familio:';
L10n::$locales['Webfont URL:'] = 'Rettiparo URL:';
L10n::$locales['Webfont API:'] = 'Webfont API:';
L10n::$locales['Secondary text'] = 'Sekundara teksto';
L10n::$locales['Secondary font:'] = 'Malĉefa tiparo:';
L10n::$locales['Titles'] = 'Titoloj';
L10n::$locales['Blog title'] = 'Titolo de la blogo';
L10n::$locales['In bold:'] = 'Grade:';
L10n::$locales['Font size (in em by default):'] = 'Tipara grandeco (en em defaŭlte):';
L10n::$locales['Color:'] = 'Koloro:';
L10n::$locales['Post title'] = 'Afiŝu titolon';
L10n::$locales['Titles without link'] = 'Titoloj sen ligilo';
L10n::$locales['Inside posts links'] = 'Ene de afiŝoj ligiloj';
L10n::$locales['Normal and visited links color:'] = 'Koloro de normalaj kaj vizititaj ligiloj:';
L10n::$locales['Active, hover and focus links color:'] = 'Koloro de aktiva, ŝveba kaj fokusa ligiloj:';
L10n::$locales['Mobile specific settings'] = 'Poŝtelefonaj specifaj agordoj';
