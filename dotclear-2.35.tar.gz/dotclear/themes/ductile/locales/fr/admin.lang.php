<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Complet';
L10n::$locales['Home (first page)'] = 'Accueil (première page)';
L10n::$locales['Home (other pages)'] = 'Accueil (autres pages)';
L10n::$locales['Entries for a category'] = 'Entrées pour une catégorie';
L10n::$locales['Entries for a tag'] = 'Entrées pour un mot-clé';
L10n::$locales['Search result entries'] = 'Entrées des résultats de la recherche';
L10n::$locales['Month archive entries'] = 'Entrées des archives du mois';
L10n::$locales['Ductile primary'] = 'Ductile primaire';
L10n::$locales['Ductile secondary'] = 'Ductile secondaire';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = 'Georgia';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'Impact';
L10n::$locales['Monospace'] = 'Monospace';
L10n::$locales['none'] = 'aucun';
L10n::$locales['javascript (Adobe)'] = 'javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'feuille de style (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'La configuration du thème a été mise à jour.';
L10n::$locales['Font family'] = 'Famille de polices';
L10n::$locales['Header'] = 'Entête';
L10n::$locales['Hide blog description:'] = 'Masquer la description du blog :';
L10n::$locales['Logo URL:'] = 'URL du logo :';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'Pour configurer le menu principal, rendez-vous sur <a href="%s">la page d\'administration du menu simple</a>.';
L10n::$locales['Stickers'] = 'Etiquettes';
L10n::$locales['Stickers (footer)'] = 'Étiquettes (pied de page)';
L10n::$locales['Image'] = 'Image';
L10n::$locales['Entries list types and limits'] = 'Types et limites des listes d\'entrées';
L10n::$locales['Entries lists'] = 'Listes des entrées';
L10n::$locales['Context'] = 'Contexte';
L10n::$locales['Entries list type'] = 'Type de liste d\'entrées';
L10n::$locales['Miscellaneous options'] = 'Options diverses';
L10n::$locales['Comment preview is not mandatory:'] = 'L\'aperçu du commentaire n\'est pas obligatoire :';
L10n::$locales['Presentation'] = 'Présentation';
L10n::$locales['General settings'] = 'Paramètres généraux';
L10n::$locales['Fonts'] = 'Polices de caractères';
L10n::$locales['Main text'] = 'Texte principal';
L10n::$locales['Main font:'] = 'Police principale :';
L10n::$locales['Set to Default to use a webfont.'] = 'Définir sur Défaut pour utiliser une police de caractères web.';
L10n::$locales['Webfont family:'] = 'Famille de police Web:';
L10n::$locales['Webfont URL:'] = 'URL de la police Web :';
L10n::$locales['Webfont API:'] = 'API Webfont :';
L10n::$locales['Secondary text'] = 'Texte secondaire';
L10n::$locales['Secondary font:'] = 'Police secondaire :';
L10n::$locales['Titles'] = 'Titres';
L10n::$locales['Blog title'] = 'Titre du blog';
L10n::$locales['In bold:'] = 'En gras :';
L10n::$locales['Font size (in em by default):'] = 'Taille de la police (en em par défaut) :';
L10n::$locales['Color:'] = 'Couleur :';
L10n::$locales['Post title'] = 'Titre de la publication';
L10n::$locales['Titles without link'] = 'Titres sans lien';
L10n::$locales['Inside posts links'] = 'Liens à l\'intérieur des publications';
L10n::$locales['Normal and visited links color:'] = 'Couleur des liens normaux et visités :';
L10n::$locales['Active, hover and focus links color:'] = 'Couleur des liens actifs, survolés et focalisés :';
L10n::$locales['Mobile specific settings'] = 'Paramètres spécifiques au mobile';
