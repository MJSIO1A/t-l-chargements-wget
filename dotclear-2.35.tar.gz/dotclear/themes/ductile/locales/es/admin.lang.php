<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Completo';
L10n::$locales['Home (first page)'] = 'Inicio (primera página)';
L10n::$locales['Home (other pages)'] = 'Inicio (otras páginas)';
L10n::$locales['Entries for a category'] = 'Entradas para una categoría';
L10n::$locales['Entries for a tag'] = 'Entradas para una etiqueta';
L10n::$locales['Search result entries'] = 'Entradas de resultados de búsqueda';
L10n::$locales['Month archive entries'] = 'Entradas de archivo por mes';
L10n::$locales['Ductile primary'] = 'Primario dúctil';
L10n::$locales['Ductile secondary'] = 'Secundaria dúctil';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = 'Georgia';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'Impacto';
L10n::$locales['Monospace'] = 'Monospace';
L10n::$locales['none'] = 'ninguno';
L10n::$locales['javascript (Adobe)'] = 'javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'hoja de estilo (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'Se ha actualizado la configuración del tema.';
L10n::$locales['Font family'] = 'Familia de fuentes';
L10n::$locales['Header'] = 'Cabecera';
L10n::$locales['Hide blog description:'] = 'Ocultar descripción del blog:';
L10n::$locales['Logo URL:'] = 'URL del logotipo:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'Para configurar el menú superior, vaya a la página de administración <a href="%s">Simple Menu</a>.';
L10n::$locales['Stickers'] = 'Pegatinas';
L10n::$locales['Stickers (footer)'] = 'Adhesivos (pie de página)';
L10n::$locales['Image'] = 'Imagen';
L10n::$locales['Entries list types and limits'] = 'Tipos y límites de la lista de entradas';
L10n::$locales['Entries lists'] = 'Listas de entradas';
L10n::$locales['Context'] = 'Contexto';
L10n::$locales['Entries list type'] = 'Tipo de lista de entradas';
L10n::$locales['Miscellaneous options'] = 'Opciones varias';
L10n::$locales['Comment preview is not mandatory:'] = 'La vista previa de los comentarios no es obligatoria:';
L10n::$locales['Presentation'] = 'Presentación';
L10n::$locales['General settings'] = 'Configuración general';
L10n::$locales['Fonts'] = 'Fuentes';
L10n::$locales['Main text'] = 'Texto principal';
L10n::$locales['Main font:'] = 'Fuente principal:';
L10n::$locales['Set to Default to use a webfont.'] = 'Establézcalo en Predeterminado para utilizar una fuente web.';
L10n::$locales['Webfont family:'] = 'Familia Webfont:';
L10n::$locales['Webfont URL:'] = 'URL de la fuente web:';
L10n::$locales['Webfont API:'] = 'API de Webfont:';
L10n::$locales['Secondary text'] = 'Texto secundario';
L10n::$locales['Secondary font:'] = 'Fuente secundaria:';
L10n::$locales['Titles'] = 'Títulos';
L10n::$locales['Blog title'] = 'Título del blog';
L10n::$locales['In bold:'] = 'En negrita:';
L10n::$locales['Font size (in em by default):'] = 'Tamaño de fuente (en em por defecto):';
L10n::$locales['Color:'] = 'Color:';
L10n::$locales['Post title'] = 'Título del puesto';
L10n::$locales['Titles without link'] = 'Títulos sin enlace';
L10n::$locales['Inside posts links'] = 'Enlaces interiores';
L10n::$locales['Normal and visited links color:'] = 'Color de los enlaces normales y visitados:';
L10n::$locales['Active, hover and focus links color:'] = 'Color de los enlaces activos, hover y focus:';
L10n::$locales['Mobile specific settings'] = 'Ajustes específicos para móviles';
