<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Täysi';
L10n::$locales['Home (first page)'] = 'Etusivu (ensimmäinen sivu)';
L10n::$locales['Home (other pages)'] = 'Etusivu (muut sivut)';
L10n::$locales['Entries for a category'] = 'Luokan merkinnät';
L10n::$locales['Entries for a tag'] = 'Tagin merkinnät';
L10n::$locales['Search result entries'] = 'Hakutulosten merkinnät';
L10n::$locales['Month archive entries'] = 'Kuukauden arkistomerkinnät';
L10n::$locales['Ductile primary'] = 'Sitkeä ensisijainen';
L10n::$locales['Ductile secondary'] = 'Toissijainen duktiivinen';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = 'Georgia';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'Vaikutus';
L10n::$locales['Monospace'] = 'Monospace';
L10n::$locales['none'] = 'ei ole';
L10n::$locales['javascript (Adobe)'] = 'javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'stylesheet (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'Teeman kokoonpanoa päivitetty.';
L10n::$locales['Font family'] = 'Fonttiperhe';
L10n::$locales['Header'] = 'Otsikko';
L10n::$locales['Hide blog description:'] = 'Piilota blogin kuvaus:';
L10n::$locales['Logo URL:'] = 'Logon URL-osoite:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'Ylävalikon määrittäminen tapahtuu osoitteessa <a href="%s">Yksinkertaisen valikon hallintasivu</a>.';
L10n::$locales['Stickers'] = 'Tarrat';
L10n::$locales['Stickers (footer)'] = 'Tarrat (alatunniste)';
L10n::$locales['Image'] = 'Kuva';
L10n::$locales['Entries list types and limits'] = 'Merkintäluettelon tyypit ja rajoitukset';
L10n::$locales['Entries lists'] = 'Merkintäluettelot';
L10n::$locales['Context'] = 'Konteksti';
L10n::$locales['Entries list type'] = 'Merkintäluettelon tyyppi';
L10n::$locales['Miscellaneous options'] = 'Erilaiset vaihtoehdot';
L10n::$locales['Comment preview is not mandatory:'] = 'Kommentin esikatselu ei ole pakollinen:';
L10n::$locales['Presentation'] = 'Esittely';
L10n::$locales['General settings'] = 'Yleiset asetukset';
L10n::$locales['Fonts'] = 'Kirjasimet';
L10n::$locales['Main text'] = 'Pääkirjoitus';
L10n::$locales['Main font:'] = 'Tärkein fontti:';
L10n::$locales['Set to Default to use a webfont.'] = 'Aseta arvoksi Oletus, jos haluat käyttää webfonttia.';
L10n::$locales['Webfont family:'] = 'Webfont-perhe:';
L10n::$locales['Webfont URL:'] = 'Webfontin URL-osoite:';
L10n::$locales['Webfont API:'] = 'Webfont API:';
L10n::$locales['Secondary text'] = 'Toissijainen teksti';
L10n::$locales['Secondary font:'] = 'Toissijainen fontti:';
L10n::$locales['Titles'] = 'Otsikot';
L10n::$locales['Blog title'] = 'Blogin otsikko';
L10n::$locales['In bold:'] = 'Lihavoitu:';
L10n::$locales['Font size (in em by default):'] = 'Kirjasinkoko (oletusarvoisesti em):';
L10n::$locales['Color:'] = 'Väri:';
L10n::$locales['Post title'] = 'Postin otsikko';
L10n::$locales['Titles without link'] = 'Otsikot ilman linkkiä';
L10n::$locales['Inside posts links'] = 'Sisäpuolen virkojen linkit';
L10n::$locales['Normal and visited links color:'] = 'Normaalien ja vierailtujen linkkien väri:';
L10n::$locales['Active, hover and focus links color:'] = 'Aktiivisen, leijuvan ja tarkennetun linkin väri:';
L10n::$locales['Mobile specific settings'] = 'Mobiilikohtaiset asetukset';
