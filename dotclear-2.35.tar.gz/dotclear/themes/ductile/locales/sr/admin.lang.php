<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Пуна';
L10n::$locales['Home (first page)'] = 'Дом (прва страница)';
L10n::$locales['Home (other pages)'] = 'Дом (друге странице)';
L10n::$locales['Entries for a category'] = 'Ставке за категорију';
L10n::$locales['Entries for a tag'] = 'Уноси за ознаку';
L10n::$locales['Search result entries'] = 'Уноси резултата претраге';
L10n::$locales['Month archive entries'] = 'Месечни уноси у архиву';
L10n::$locales['Ductile primary'] = 'Дуктилни примарни';
L10n::$locales['Ductile secondary'] = 'Секундарни секундарни';
L10n::$locales['Times New Roman'] = 'Пута нови римски';
L10n::$locales['Georgia'] = 'Грузија';
L10n::$locales['Garamond'] = 'Гарамонд';
L10n::$locales['Helvetica/Arial'] = 'Хелветика/Ариал';
L10n::$locales['Verdana'] = 'Вердана';
L10n::$locales['Trebuchet MS'] = 'Требучет MS';
L10n::$locales['Impact'] = 'Утицај';
L10n::$locales['Monospace'] = 'Моноспејс';
L10n::$locales['none'] = 'ниједан';
L10n::$locales['javascript (Adobe)'] = 'јаваскрипт (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'стилски лист (Гугл)';
L10n::$locales['Theme configuration upgraded.'] = 'Конфигурација теме надограђена.';
L10n::$locales['Font family'] = 'Породица фонт';
L10n::$locales['Header'] = 'Заглавље';
L10n::$locales['Hide blog description:'] = 'Сакриј опис блога:';
L10n::$locales['Logo URL:'] = 'URL логотипа:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'Да бисте конфигурисали горњи мени идите на <a href="%s">Једноставни Мену администрацију</a>.';
L10n::$locales['Stickers'] = 'Налепнице';
L10n::$locales['Stickers (footer)'] = 'Налепнице (footer)';
L10n::$locales['Image'] = 'Слика';
L10n::$locales['Entries list types and limits'] = 'Типови и ограничења листе уноса';
L10n::$locales['Entries lists'] = 'Листе ставки';
L10n::$locales['Context'] = 'Контекст';
L10n::$locales['Entries list type'] = 'Тип листе уноса';
L10n::$locales['Miscellaneous options'] = 'Разно опције';
L10n::$locales['Comment preview is not mandatory:'] = 'Преглед коментара није обавезан:';
L10n::$locales['Presentation'] = 'Презентација';
L10n::$locales['General settings'] = 'Општа подешавања';
L10n::$locales['Fonts'] = 'Фонтови';
L10n::$locales['Main text'] = 'Главни текст';
L10n::$locales['Main font:'] = 'Главни фонт:';
L10n::$locales['Set to Default to use a webfont.'] = 'Подешен на подразумевану вредност за коришћење веб фонта.';
L10n::$locales['Webfont family:'] = 'Webfont породица:';
L10n::$locales['Webfont URL:'] = 'URL веб фонта:';
L10n::$locales['Webfont API:'] = 'Webфонт АПИ:';
L10n::$locales['Secondary text'] = 'Секундарни текст';
L10n::$locales['Secondary font:'] = 'Секундарни фонт:';
L10n::$locales['Titles'] = 'Наслови';
L10n::$locales['Blog title'] = 'Наслов блога';
L10n::$locales['In bold:'] = 'Подебљано:';
L10n::$locales['Font size (in em by default):'] = 'Величина фонта (у њима подразумевано):';
L10n::$locales['Color:'] = 'Боја:';
L10n::$locales['Post title'] = 'Постави наслов';
L10n::$locales['Titles without link'] = 'Наслови без линка';
L10n::$locales['Inside posts links'] = 'Линкови унутар постова';
L10n::$locales['Normal and visited links color:'] = 'Нормална и посећена боја линкова:';
L10n::$locales['Active, hover and focus links color:'] = 'Активно, поставите курсор и фокусирајте боју линкова:';
L10n::$locales['Mobile specific settings'] = 'Посебне поставке за мобилне уређаје';
