<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = '';
L10n::$locales['Home (first page)'] = '';
L10n::$locales['Home (other pages)'] = '';
L10n::$locales['Entries for a category'] = '';
L10n::$locales['Entries for a tag'] = '';
L10n::$locales['Search result entries'] = '';
L10n::$locales['Month archive entries'] = '';
L10n::$locales['Ductile primary'] = '';
L10n::$locales['Ductile secondary'] = '';
L10n::$locales['Times New Roman'] = '';
L10n::$locales['Georgia'] = '';
L10n::$locales['Garamond'] = '';
L10n::$locales['Helvetica/Arial'] = '';
L10n::$locales['Verdana'] = '';
L10n::$locales['Trebuchet MS'] = '';
L10n::$locales['Impact'] = '';
L10n::$locales['Monospace'] = '';
L10n::$locales['none'] = '';
L10n::$locales['javascript (Adobe)'] = '';
L10n::$locales['stylesheet (Google)'] = '';
L10n::$locales['Theme configuration upgraded.'] = '';
L10n::$locales['Font family'] = '';
L10n::$locales['Header'] = '';
L10n::$locales['Hide blog description:'] = '';
L10n::$locales['Logo URL:'] = '';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = '';
L10n::$locales['Stickers'] = '';
L10n::$locales['Stickers (footer)'] = '';
L10n::$locales['Image'] = '';
L10n::$locales['Entries list types and limits'] = '';
L10n::$locales['Entries lists'] = '';
L10n::$locales['Context'] = '';
L10n::$locales['Entries list type'] = '';
L10n::$locales['Miscellaneous options'] = '';
L10n::$locales['Comment preview is not mandatory:'] = '';
L10n::$locales['Presentation'] = '';
L10n::$locales['General settings'] = '';
L10n::$locales['Fonts'] = '';
L10n::$locales['Main text'] = '';
L10n::$locales['Main font:'] = '';
L10n::$locales['Set to Default to use a webfont.'] = '';
L10n::$locales['Webfont family:'] = '';
L10n::$locales['Webfont URL:'] = '';
L10n::$locales['Webfont API:'] = '';
L10n::$locales['Secondary text'] = '';
L10n::$locales['Secondary font:'] = '';
L10n::$locales['Titles'] = '';
L10n::$locales['Blog title'] = '';
L10n::$locales['In bold:'] = '';
L10n::$locales['Font size (in em by default):'] = '';
L10n::$locales['Color:'] = '';
L10n::$locales['Post title'] = '';
L10n::$locales['Titles without link'] = '';
L10n::$locales['Inside posts links'] = '';
L10n::$locales['Normal and visited links color:'] = '';
L10n::$locales['Active, hover and focus links color:'] = '';
L10n::$locales['Mobile specific settings'] = '';
