<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Пълен';
L10n::$locales['Home (first page)'] = 'Начало (първа страница)';
L10n::$locales['Home (other pages)'] = 'Начало (други страници)';
L10n::$locales['Entries for a category'] = 'Записвания за дадена категория';
L10n::$locales['Entries for a tag'] = 'Записи за етикет';
L10n::$locales['Search result entries'] = 'Вписване на резултатите от търсенето';
L10n::$locales['Month archive entries'] = 'Месечни архивни записи';
L10n::$locales['Ductile primary'] = 'Първична дуктилност';
L10n::$locales['Ductile secondary'] = 'Дуктилен вторичен';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = 'Грузия';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'Въздействие';
L10n::$locales['Monospace'] = 'Monospace';
L10n::$locales['none'] = 'няма';
L10n::$locales['javascript (Adobe)'] = 'javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'таблица със стилове (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'Конфигурацията на темата е обновена.';
L10n::$locales['Font family'] = 'Семейство шрифтове';
L10n::$locales['Header'] = 'Заглавие';
L10n::$locales['Hide blog description:'] = 'Скрийте описанието на блога:';
L10n::$locales['Logo URL:'] = 'URL адрес на логото:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'За да конфигурирате горното меню, отидете на <a href="%s">страницата за администриране на обикновеното меню</a>.';
L10n::$locales['Stickers'] = 'Стикери';
L10n::$locales['Stickers (footer)'] = 'Стикери (колонтитул)';
L10n::$locales['Image'] = 'Изображение';
L10n::$locales['Entries list types and limits'] = 'Видове списъци с вписвания и ограничения';
L10n::$locales['Entries lists'] = 'Списъци с вписвания';
L10n::$locales['Context'] = 'Контекст';
L10n::$locales['Entries list type'] = 'Тип на списъка с вписвания';
L10n::$locales['Miscellaneous options'] = 'Различни опции';
L10n::$locales['Comment preview is not mandatory:'] = 'Прегледът на коментарите не е задължителен:';
L10n::$locales['Presentation'] = 'Презентация';
L10n::$locales['General settings'] = 'Общи настройки';
L10n::$locales['Fonts'] = 'Шрифтове';
L10n::$locales['Main text'] = 'Основен текст';
L10n::$locales['Main font:'] = 'Основен шрифт:';
L10n::$locales['Set to Default to use a webfont.'] = 'Задайте Default (По подразбиране), за да използвате уеб шрифт.';
L10n::$locales['Webfont family:'] = 'Семейство Webfont:';
L10n::$locales['Webfont URL:'] = 'URL адрес на уеб шрифт:';
L10n::$locales['Webfont API:'] = 'API за уеб шрифтове:';
L10n::$locales['Secondary text'] = 'Вторичен текст';
L10n::$locales['Secondary font:'] = 'Вторичен шрифт:';
L10n::$locales['Titles'] = 'Заглавия';
L10n::$locales['Blog title'] = 'Заглавие на блога';
L10n::$locales['In bold:'] = 'С удебелен шрифт:';
L10n::$locales['Font size (in em by default):'] = 'Размер на шрифта (по подразбиране в em):';
L10n::$locales['Color:'] = 'Цвят:';
L10n::$locales['Post title'] = 'Заглавие на публикацията';
L10n::$locales['Titles without link'] = 'Заглавия без връзка';
L10n::$locales['Inside posts links'] = 'Вътрешни публикации връзки';
L10n::$locales['Normal and visited links color:'] = 'Цвят на нормалните и посетените връзки:';
L10n::$locales['Active, hover and focus links color:'] = 'Цвят на активните връзки, връзките при преминаване и фокуса:';
L10n::$locales['Mobile specific settings'] = 'Специфични настройки за мобилни устройства';
