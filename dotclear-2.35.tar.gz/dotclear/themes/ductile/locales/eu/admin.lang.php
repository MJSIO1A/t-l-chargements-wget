<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Osoa';
L10n::$locales['Home (first page)'] = 'Hasiera (lehen orrialdea)';
L10n::$locales['Home (other pages)'] = 'Hasiera (beste orrialdeak)';
L10n::$locales['Entries for a category'] = 'Kategoria baterako sarrerak';
L10n::$locales['Entries for a tag'] = 'Etiketa baterako sarrerak';
L10n::$locales['Search result entries'] = 'Bilaketa-emaitzen sarrerak';
L10n::$locales['Month archive entries'] = 'Hilabeteko artxiboko sarrerak';
L10n::$locales['Ductile primary'] = 'Primario harikorra';
L10n::$locales['Ductile secondary'] = 'Bigarren mailako harikorra';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = 'Georgia';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'Eragina';
L10n::$locales['Monospace'] = 'Monoespazioa';
L10n::$locales['none'] = 'bat ere ez';
L10n::$locales['javascript (Adobe)'] = 'Javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'estilo orria (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'Gaiaren konfigurazioa berritu da.';
L10n::$locales['Font family'] = 'Letra-tipoen familia';
L10n::$locales['Header'] = 'Goiburua';
L10n::$locales['Hide blog description:'] = 'Ezkutatu blogaren deskribapena:';
L10n::$locales['Logo URL:'] = 'Logotipoaren URLa:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'Goiko menua konfiguratzeko, joan <a href="%s">Simple Menu administrazio orrira</a>.';
L10n::$locales['Stickers'] = 'Eranskailuak';
L10n::$locales['Stickers (footer)'] = 'Eranskailuak (oina)';
L10n::$locales['Image'] = 'Irudia';
L10n::$locales['Entries list types and limits'] = 'Sarrerak zerrenda motak eta mugak';
L10n::$locales['Entries lists'] = 'Sarrera zerrendak';
L10n::$locales['Context'] = 'Testuingurua';
L10n::$locales['Entries list type'] = 'Sarrera zerrenda mota';
L10n::$locales['Miscellaneous options'] = 'Askotariko aukerak';
L10n::$locales['Comment preview is not mandatory:'] = 'Iruzkinen aurrebista ez da derrigorrezkoa:';
L10n::$locales['Presentation'] = 'Aurkezpena';
L10n::$locales['General settings'] = 'Ezarpen orokorrak';
L10n::$locales['Fonts'] = 'Letra-tipoak';
L10n::$locales['Main text'] = 'Testu nagusia';
L10n::$locales['Main font:'] = 'Letra-tipo nagusia:';
L10n::$locales['Set to Default to use a webfont.'] = 'Ezarri Lehenetsia web-tipo bat erabiltzeko.';
L10n::$locales['Webfont family:'] = 'Webfont familia:';
L10n::$locales['Webfont URL:'] = 'Webfont URLa:';
L10n::$locales['Webfont API:'] = 'Webfont APIa:';
L10n::$locales['Secondary text'] = 'Bigarren mailako testua';
L10n::$locales['Secondary font:'] = 'Bigarren mailako letra-tipoa:';
L10n::$locales['Titles'] = 'Izenburuak';
L10n::$locales['Blog title'] = 'Blogaren izenburua';
L10n::$locales['In bold:'] = 'lodiz:';
L10n::$locales['Font size (in em by default):'] = 'Letra-tamaina (lehenetsita dago):';
L10n::$locales['Color:'] = 'Kolore:';
L10n::$locales['Post title'] = 'Mezuaren izenburua';
L10n::$locales['Titles without link'] = 'Estekarik gabeko tituluak';
L10n::$locales['Inside posts links'] = 'Argitalpenen barruko estekak';
L10n::$locales['Normal and visited links color:'] = 'Lotura arruntak eta bisitatuak kolorea:';
L10n::$locales['Active, hover and focus links color:'] = 'Aktiboak, pasatzeko eta fokuaren esteken kolorea:';
L10n::$locales['Mobile specific settings'] = 'Mugikorraren ezarpen espezifikoak';
