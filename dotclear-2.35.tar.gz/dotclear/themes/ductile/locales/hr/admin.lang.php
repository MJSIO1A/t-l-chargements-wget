<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'puna';
L10n::$locales['Home (first page)'] = 'Početna (prva stranica)';
L10n::$locales['Home (other pages)'] = 'Početna (ostale stranice)';
L10n::$locales['Entries for a category'] = 'Unosi za kategoriju';
L10n::$locales['Entries for a tag'] = 'Unosi za oznaku';
L10n::$locales['Search result entries'] = 'Unosi rezultata pretraživanja';
L10n::$locales['Month archive entries'] = 'Mjesečni arhivski unosi';
L10n::$locales['Ductile primary'] = 'Duktilni primarni';
L10n::$locales['Ductile secondary'] = 'Duktilni sekundarni';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = 'Gruzija';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'Udarac';
L10n::$locales['Monospace'] = 'Monospace';
L10n::$locales['none'] = 'nikakav';
L10n::$locales['javascript (Adobe)'] = 'javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'tablica stilova (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'Konfiguracija teme je nadograđena.';
L10n::$locales['Font family'] = 'Obitelj fontova';
L10n::$locales['Header'] = 'Zaglavlje';
L10n::$locales['Hide blog description:'] = 'Sakrij opis bloga:';
L10n::$locales['Logo URL:'] = 'URL logotipa:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'Za konfiguraciju gornjeg izbornika idite na <a href="%s">stranicu za administraciju Jednostavnog izbornika</a>.';
L10n::$locales['Stickers'] = 'Naljepnice';
L10n::$locales['Stickers (footer)'] = 'Naljepnice (podnožje)';
L10n::$locales['Image'] = 'Slika';
L10n::$locales['Entries list types and limits'] = 'Vrste popisa unosa i ograničenja';
L10n::$locales['Entries lists'] = 'Liste unosa';
L10n::$locales['Context'] = 'Kontekst';
L10n::$locales['Entries list type'] = 'Vrsta popisa unosa';
L10n::$locales['Miscellaneous options'] = 'Razne opcije';
L10n::$locales['Comment preview is not mandatory:'] = 'Pregled komentara nije obavezan:';
L10n::$locales['Presentation'] = 'Prezentacija';
L10n::$locales['General settings'] = 'Opće postavke';
L10n::$locales['Fonts'] = 'Fontovi';
L10n::$locales['Main text'] = 'Glavni tekst';
L10n::$locales['Main font:'] = 'Glavni font:';
L10n::$locales['Set to Default to use a webfont.'] = 'Postavite na Zadano za korištenje web-fonta.';
L10n::$locales['Webfont family:'] = 'Obitelj Webfontova:';
L10n::$locales['Webfont URL:'] = 'URL web-fonta:';
L10n::$locales['Webfont API:'] = 'Webfont API:';
L10n::$locales['Secondary text'] = 'Sekundarni tekst';
L10n::$locales['Secondary font:'] = 'Sekundarni font:';
L10n::$locales['Titles'] = 'Naslovi';
L10n::$locales['Blog title'] = 'Naslov bloga';
L10n::$locales['In bold:'] = 'Podebljano:';
L10n::$locales['Font size (in em by default):'] = 'Veličina fonta (u em prema zadanim postavkama):';
L10n::$locales['Color:'] = 'Boja:';
L10n::$locales['Post title'] = 'Naslov objave';
L10n::$locales['Titles without link'] = 'Naslovi bez linka';
L10n::$locales['Inside posts links'] = 'Linkovi unutar postova';
L10n::$locales['Normal and visited links color:'] = 'Boja normalnih i posjećenih poveznica:';
L10n::$locales['Active, hover and focus links color:'] = 'Boja aktivnih, lebdećih i fokusnih veza:';
L10n::$locales['Mobile specific settings'] = 'Postavke specifične za mobitel';
