<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Volledig';
L10n::$locales['Home (first page)'] = 'Home (eerste pagina)';
L10n::$locales['Home (other pages)'] = 'Home (andere pagina\'s)';
L10n::$locales['Entries for a category'] = 'Inzendingen voor een categorie';
L10n::$locales['Entries for a tag'] = 'Invoer voor een tag';
L10n::$locales['Search result entries'] = 'Vermeldingen zoekresultaat';
L10n::$locales['Month archive entries'] = 'Maand archiefvermeldingen';
L10n::$locales['Ductile primary'] = 'Kneedbaar primair';
L10n::$locales['Ductile secondary'] = 'Kneedbaar secundair';
L10n::$locales['Times New Roman'] = 'Times Nieuw Romein';
L10n::$locales['Georgia'] = 'Georgië';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'Impact';
L10n::$locales['Monospace'] = 'Monospace';
L10n::$locales['none'] = 'geen';
L10n::$locales['javascript (Adobe)'] = 'javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'stylesheet (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'Themaconfiguratie bijgewerkt.';
L10n::$locales['Font family'] = 'Lettertype';
L10n::$locales['Header'] = 'Kop';
L10n::$locales['Hide blog description:'] = 'Verberg blogbeschrijving:';
L10n::$locales['Logo URL:'] = 'URL logo:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'Ga naar de <a href="%s">beheerpagina Eenvoudig menu</a> om het bovenste menu te configureren.';
L10n::$locales['Stickers'] = 'Stickers';
L10n::$locales['Stickers (footer)'] = 'Stickers (voettekst)';
L10n::$locales['Image'] = 'Afbeelding';
L10n::$locales['Entries list types and limits'] = 'Soorten lijsten en limieten';
L10n::$locales['Entries lists'] = 'Invoerlijsten';
L10n::$locales['Context'] = 'Context';
L10n::$locales['Entries list type'] = 'Type invoerlijst';
L10n::$locales['Miscellaneous options'] = 'Diverse opties';
L10n::$locales['Comment preview is not mandatory:'] = 'Commentaar vooraf is niet verplicht:';
L10n::$locales['Presentation'] = 'Presentatie';
L10n::$locales['General settings'] = 'Algemene instellingen';
L10n::$locales['Fonts'] = 'Lettertypen';
L10n::$locales['Main text'] = 'Hoofdtekst';
L10n::$locales['Main font:'] = 'Hoofdlettertype:';
L10n::$locales['Set to Default to use a webfont.'] = 'Stel in op Standaard om een webfont te gebruiken.';
L10n::$locales['Webfont family:'] = 'Weblettertype-familie:';
L10n::$locales['Webfont URL:'] = 'Webfont URL:';
L10n::$locales['Webfont API:'] = 'Webfont API:';
L10n::$locales['Secondary text'] = 'Secundaire tekst';
L10n::$locales['Secondary font:'] = 'Secundair lettertype:';
L10n::$locales['Titles'] = 'Titels';
L10n::$locales['Blog title'] = 'Blog titel';
L10n::$locales['In bold:'] = 'Vetgedrukt:';
L10n::$locales['Font size (in em by default):'] = 'Lettergrootte (standaard in em):';
L10n::$locales['Color:'] = 'Kleur:';
L10n::$locales['Post title'] = 'Titel';
L10n::$locales['Titles without link'] = 'Titels zonder link';
L10n::$locales['Inside posts links'] = 'Links binnen berichten';
L10n::$locales['Normal and visited links color:'] = 'Kleur normale en bezochte links:';
L10n::$locales['Active, hover and focus links color:'] = 'Kleur van actieve, hover- en focuslinks:';
L10n::$locales['Mobile specific settings'] = 'Specifieke instellingen voor mobiel';
