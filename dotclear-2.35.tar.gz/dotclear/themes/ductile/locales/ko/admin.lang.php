<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = '전체';
L10n::$locales['Home (first page)'] = '홈(첫 페이지)';
L10n::$locales['Home (other pages)'] = '홈(기타 페이지)';
L10n::$locales['Entries for a category'] = '카테고리에 대한 항목';
L10n::$locales['Entries for a tag'] = '태그 항목';
L10n::$locales['Search result entries'] = '검색 결과 항목';
L10n::$locales['Month archive entries'] = '월별 아카이브 항목';
L10n::$locales['Ductile primary'] = '연성 기본';
L10n::$locales['Ductile secondary'] = '연성 보조';
L10n::$locales['Times New Roman'] = '타임즈 뉴 로마';
L10n::$locales['Georgia'] = 'Georgia';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = '헬베티카/아랄';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = '트레뷰셋 MS';
L10n::$locales['Impact'] = '영향';
L10n::$locales['Monospace'] = '모노스페이스';
L10n::$locales['none'] = '없음';
L10n::$locales['javascript (Adobe)'] = '자바스크립트(Adobe)';
L10n::$locales['stylesheet (Google)'] = '스타일시트(Google)';
L10n::$locales['Theme configuration upgraded.'] = '테마 구성이 업그레이드되었습니다.';
L10n::$locales['Font family'] = '글꼴 패밀리';
L10n::$locales['Header'] = '헤더';
L10n::$locales['Hide blog description:'] = '블로그 설명을 숨깁니다:';
L10n::$locales['Logo URL:'] = '로고 URL:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = '상단 메뉴를 구성하려면 <a href="%s">간편 메뉴 관리 페이지</a>로 이동하세요.';
L10n::$locales['Stickers'] = '스티커';
L10n::$locales['Stickers (footer)'] = '스티커(바닥글)';
L10n::$locales['Image'] = '이미지';
L10n::$locales['Entries list types and limits'] = '항목 목록 유형 및 한도';
L10n::$locales['Entries lists'] = '항목 목록';
L10n::$locales['Context'] = '컨텍스트';
L10n::$locales['Entries list type'] = '항목 목록 유형';
L10n::$locales['Miscellaneous options'] = '기타 옵션';
L10n::$locales['Comment preview is not mandatory:'] = '댓글 미리 보기는 필수가 아닙니다:';
L10n::$locales['Presentation'] = '프레젠테이션';
L10n::$locales['General settings'] = '일반 설정';
L10n::$locales['Fonts'] = '글꼴';
L10n::$locales['Main text'] = '주요 텍스트';
L10n::$locales['Main font:'] = '기본 글꼴:';
L10n::$locales['Set to Default to use a webfont.'] = '웹폰트를 사용하려면 기본값으로 설정합니다.';
L10n::$locales['Webfont family:'] = '웹폰트 제품군:';
L10n::$locales['Webfont URL:'] = '웹폰트 URL:';
L10n::$locales['Webfont API:'] = '웹폰트 API:';
L10n::$locales['Secondary text'] = '보조 텍스트';
L10n::$locales['Secondary font:'] = '보조 글꼴:';
L10n::$locales['Titles'] = '타이틀';
L10n::$locales['Blog title'] = '블로그 제목';
L10n::$locales['In bold:'] = '굵게 표시:';
L10n::$locales['Font size (in em by default):'] = '글꼴 크기(기본값은 em):';
L10n::$locales['Color:'] = '색상:';
L10n::$locales['Post title'] = '게시물 제목';
L10n::$locales['Titles without link'] = '링크 없는 제목';
L10n::$locales['Inside posts links'] = '내부 게시물 링크';
L10n::$locales['Normal and visited links color:'] = '일반 및 방문한 링크 색상:';
L10n::$locales['Active, hover and focus links color:'] = '활성, 마우스오버 및 포커스 링크 색상:';
L10n::$locales['Mobile specific settings'] = '모바일 전용 설정';
