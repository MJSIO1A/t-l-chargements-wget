<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Tam';
L10n::$locales['Home (first page)'] = 'Ana Sayfa (ilk sayfa)';
L10n::$locales['Home (other pages)'] = 'Ana Sayfa (diğer sayfalar)';
L10n::$locales['Entries for a category'] = 'Bir kategori için girişler';
L10n::$locales['Entries for a tag'] = 'Bir etiket için girişler';
L10n::$locales['Search result entries'] = 'Arama sonucu girişleri';
L10n::$locales['Month archive entries'] = 'Ay arşivi girişleri';
L10n::$locales['Ductile primary'] = 'Sünek birincil';
L10n::$locales['Ductile secondary'] = 'Sünek ikincil';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = 'Gürcistan';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'Etki';
L10n::$locales['Monospace'] = 'Monospace';
L10n::$locales['none'] = 'Hiçbiri';
L10n::$locales['javascript (Adobe)'] = 'javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'stil sayfası (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'Tema yapılandırması yükseltildi.';
L10n::$locales['Font family'] = 'Yazı tipi ailesi';
L10n::$locales['Header'] = 'Başlık';
L10n::$locales['Hide blog description:'] = 'Blog açıklamasını gizle:';
L10n::$locales['Logo URL:'] = 'Logo URL\'si:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'Üst menüyü yapılandırmak için <a href="%s">Basit Menü yönetim sayfasına</a>gidin.';
L10n::$locales['Stickers'] = 'Çıkartmalar';
L10n::$locales['Stickers (footer)'] = 'Çıkartmalar (altbilgi)';
L10n::$locales['Image'] = 'Resim';
L10n::$locales['Entries list types and limits'] = 'Giriş listesi türleri ve sınırları';
L10n::$locales['Entries lists'] = 'Giriş listeleri';
L10n::$locales['Context'] = 'Bağlam';
L10n::$locales['Entries list type'] = 'Giriş listesi türü';
L10n::$locales['Miscellaneous options'] = 'Çeşitli seçenekler';
L10n::$locales['Comment preview is not mandatory:'] = 'Yorum önizlemesi zorunlu değildir:';
L10n::$locales['Presentation'] = 'Sunum';
L10n::$locales['General settings'] = 'Genel ayarlar';
L10n::$locales['Fonts'] = 'Yazı Tipleri';
L10n::$locales['Main text'] = 'Ana metin';
L10n::$locales['Main font:'] = 'Ana yazı tipi:';
L10n::$locales['Set to Default to use a webfont.'] = 'Bir webfont kullanmak için Varsayılan olarak ayarlayın.';
L10n::$locales['Webfont family:'] = 'Webfont ailesi:';
L10n::$locales['Webfont URL:'] = 'Webfont URL\'si:';
L10n::$locales['Webfont API:'] = 'Webfont API:';
L10n::$locales['Secondary text'] = 'İkincil metin';
L10n::$locales['Secondary font:'] = 'İkincil yazı tipi:';
L10n::$locales['Titles'] = 'Başlıklar';
L10n::$locales['Blog title'] = 'Blog başlığı';
L10n::$locales['In bold:'] = 'Kalın harflerle:';
L10n::$locales['Font size (in em by default):'] = 'Yazı tipi boyutu (varsayılan olarak em cinsinden):';
L10n::$locales['Color:'] = 'Renk:';
L10n::$locales['Post title'] = 'Gönderi başlığı';
L10n::$locales['Titles without link'] = 'Bağlantısız başlıklar';
L10n::$locales['Inside posts links'] = 'Inside posts bağlantıları';
L10n::$locales['Normal and visited links color:'] = 'Normal ve ziyaret edilen bağlantıların rengi:';
L10n::$locales['Active, hover and focus links color:'] = 'Aktif, fareyle üzerine gelinen ve odak bağlantılarının rengi:';
L10n::$locales['Mobile specific settings'] = 'Mobile özel ayarlar';
