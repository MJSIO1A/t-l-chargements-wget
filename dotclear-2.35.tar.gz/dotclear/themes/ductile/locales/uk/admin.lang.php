<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Повний';
L10n::$locales['Home (first page)'] = 'Головна (перша сторінка)';
L10n::$locales['Home (other pages)'] = 'Головна (інші сторінки)';
L10n::$locales['Entries for a category'] = 'Заявки на участь у категорії';
L10n::$locales['Entries for a tag'] = 'Записи для тегу';
L10n::$locales['Search result entries'] = 'Записи в результатах пошуку';
L10n::$locales['Month archive entries'] = 'Архівні записи за місяць';
L10n::$locales['Ductile primary'] = 'Пластична первинна сировина';
L10n::$locales['Ductile secondary'] = 'Пластична вторинна сировина';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = 'Грузія';
L10n::$locales['Garamond'] = 'Гарамонд.';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Вердана.';
L10n::$locales['Trebuchet MS'] = 'Требуше МС';
L10n::$locales['Impact'] = 'Вплив';
L10n::$locales['Monospace'] = 'Монопростір';
L10n::$locales['none'] = 'ні';
L10n::$locales['javascript (Adobe)'] = 'javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'таблиця стилів (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'Оновлена конфігурація теми.';
L10n::$locales['Font family'] = 'Сімейство шрифтів';
L10n::$locales['Header'] = 'Заголовок';
L10n::$locales['Hide blog description:'] = 'Приховати опис блогу:';
L10n::$locales['Logo URL:'] = 'URL-адреса логотипу:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'Для налаштування верхнього меню перейдіть на сторінку адміністрування простого меню <a href="%s"></a>.';
L10n::$locales['Stickers'] = 'Наклейки';
L10n::$locales['Stickers (footer)'] = 'Наклейки (нижній колонтитул)';
L10n::$locales['Image'] = 'Зображення';
L10n::$locales['Entries list types and limits'] = 'Типи та обмеження списку записів';
L10n::$locales['Entries lists'] = 'Списки конкурсних робіт';
L10n::$locales['Context'] = 'Контекст';
L10n::$locales['Entries list type'] = 'Тип списку записів';
L10n::$locales['Miscellaneous options'] = 'Різні опції';
L10n::$locales['Comment preview is not mandatory:'] = 'Попередній перегляд коментарів не є обов\'язковим:';
L10n::$locales['Presentation'] = 'Презентація';
L10n::$locales['General settings'] = 'Загальні налаштування';
L10n::$locales['Fonts'] = 'Шрифти';
L10n::$locales['Main text'] = 'Основний текст';
L10n::$locales['Main font:'] = 'Основний шрифт:';
L10n::$locales['Set to Default to use a webfont.'] = 'Встановіть значення За замовчуванням, щоб використовувати веб-шрифт.';
L10n::$locales['Webfont family:'] = 'Сімейство веб-шрифтів:';
L10n::$locales['Webfont URL:'] = 'URL-адреса веб-шрифту:';
L10n::$locales['Webfont API:'] = 'Webfont API:';
L10n::$locales['Secondary text'] = 'Вторинний текст';
L10n::$locales['Secondary font:'] = 'Другий шрифт:';
L10n::$locales['Titles'] = 'Назви';
L10n::$locales['Blog title'] = 'Назва блогу';
L10n::$locales['In bold:'] = 'Жирним шрифтом:';
L10n::$locales['Font size (in em by default):'] = 'Розмір шрифту (за замовчуванням - em):';
L10n::$locales['Color:'] = 'Колір:';
L10n::$locales['Post title'] = 'Назва посади';
L10n::$locales['Titles without link'] = 'Назви без посилання';
L10n::$locales['Inside posts links'] = 'Посилання всередині постів';
L10n::$locales['Normal and visited links color:'] = 'Колір звичайних та відвіданих посилань:';
L10n::$locales['Active, hover and focus links color:'] = 'Активні посилання, посилання при наведенні курсору та фокусуванні - кольорові:';
L10n::$locales['Mobile specific settings'] = 'Налаштування для мобільних пристроїв';
