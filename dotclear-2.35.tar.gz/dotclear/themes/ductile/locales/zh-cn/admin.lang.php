<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = '全部';
L10n::$locales['Home (first page)'] = '主页（第一页）';
L10n::$locales['Home (other pages)'] = '主页（其他页面）';
L10n::$locales['Entries for a category'] = '参赛作品类别';
L10n::$locales['Entries for a tag'] = '标签条目';
L10n::$locales['Search result entries'] = '搜索结果条目';
L10n::$locales['Month archive entries'] = '月档案条目';
L10n::$locales['Ductile primary'] = '韧性初级';
L10n::$locales['Ductile secondary'] = '韧性二级管';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = '格鲁吉亚';
L10n::$locales['Garamond'] = '加拉蒙德';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = '影响';
L10n::$locales['Monospace'] = 'Monospace';
L10n::$locales['none'] = '无';
L10n::$locales['javascript (Adobe)'] = 'javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = '样式表';
L10n::$locales['Theme configuration upgraded.'] = '主题配置已升级。';
L10n::$locales['Font family'] = '字体系列';
L10n::$locales['Header'] = '页眉';
L10n::$locales['Hide blog description:'] = '隐藏博客描述：';
L10n::$locales['Logo URL:'] = '徽标 URL：';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = '要配置顶部菜单，请访问 <a href="%s">简单菜单管理页面</a>。';
L10n::$locales['Stickers'] = '贴纸';
L10n::$locales['Stickers (footer)'] = '贴纸（页脚）';
L10n::$locales['Image'] = '图片';
L10n::$locales['Entries list types and limits'] = '条目列表类型和限制';
L10n::$locales['Entries lists'] = '条目列表';
L10n::$locales['Context'] = '背景';
L10n::$locales['Entries list type'] = '条目列表类型';
L10n::$locales['Miscellaneous options'] = '杂项选项';
L10n::$locales['Comment preview is not mandatory:'] = '评论预览不是强制性的：';
L10n::$locales['Presentation'] = '介绍';
L10n::$locales['General settings'] = '常规设置';
L10n::$locales['Fonts'] = '字体';
L10n::$locales['Main text'] = '正文';
L10n::$locales['Main font:'] = '主要字体';
L10n::$locales['Set to Default to use a webfont.'] = '设为默认值即可使用网络字体。';
L10n::$locales['Webfont family:'] = '网络字体系列：';
L10n::$locales['Webfont URL:'] = '网络字体 URL：';
L10n::$locales['Webfont API:'] = '网络字体 API：';
L10n::$locales['Secondary text'] = '辅助文本';
L10n::$locales['Secondary font:'] = '辅助字体：';
L10n::$locales['Titles'] = '标题';
L10n::$locales['Blog title'] = '博客标题';
L10n::$locales['In bold:'] = '粗体字：';
L10n::$locales['Font size (in em by default):'] = '字体大小（默认单位为 em）：';
L10n::$locales['Color:'] = '颜色';
L10n::$locales['Post title'] = '职位名称';
L10n::$locales['Titles without link'] = '无链接的标题';
L10n::$locales['Inside posts links'] = '内部职位链接';
L10n::$locales['Normal and visited links color:'] = '正常链接和已访问链接的颜色：';
L10n::$locales['Active, hover and focus links color:'] = '活动、悬停和焦点链接的颜色：';
L10n::$locales['Mobile specific settings'] = '手机专用设置';
