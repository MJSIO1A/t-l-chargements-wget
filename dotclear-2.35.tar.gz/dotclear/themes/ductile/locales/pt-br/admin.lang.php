<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Completo';
L10n::$locales['Home (first page)'] = 'Início (primeira página)';
L10n::$locales['Home (other pages)'] = 'Início (outras páginas)';
L10n::$locales['Entries for a category'] = 'Entradas para uma categoria';
L10n::$locales['Entries for a tag'] = 'Entradas para uma etiqueta';
L10n::$locales['Search result entries'] = 'Entradas de resultados de pesquisa';
L10n::$locales['Month archive entries'] = 'Entradas de arquivo do mês';
L10n::$locales['Ductile primary'] = 'Primário dúctil';
L10n::$locales['Ductile secondary'] = 'Secundário dúctil';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = 'Geórgia';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'Impacto';
L10n::$locales['Monospace'] = 'Monoespaço';
L10n::$locales['none'] = 'nenhum';
L10n::$locales['javascript (Adobe)'] = 'javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'folha de estilos (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'Configuração do tema actualizada.';
L10n::$locales['Font family'] = 'Família de fontes';
L10n::$locales['Header'] = 'Cabeçalho';
L10n::$locales['Hide blog description:'] = 'Ocultar a descrição do blogue:';
L10n::$locales['Logo URL:'] = 'URL do logótipo:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'Para configurar o menu superior, aceda à página de administração do menu simples <a href="%s"></a>.';
L10n::$locales['Stickers'] = 'Autocolantes';
L10n::$locales['Stickers (footer)'] = 'Autocolantes (rodapé)';
L10n::$locales['Image'] = 'Imagem';
L10n::$locales['Entries list types and limits'] = 'Tipos e limites da lista de entradas';
L10n::$locales['Entries lists'] = 'Listas de entradas';
L10n::$locales['Context'] = 'Contexto';
L10n::$locales['Entries list type'] = 'Tipo de lista de entradas';
L10n::$locales['Miscellaneous options'] = 'Opções diversas';
L10n::$locales['Comment preview is not mandatory:'] = 'A pré-visualização dos comentários não é obrigatória:';
L10n::$locales['Presentation'] = 'Apresentação';
L10n::$locales['General settings'] = 'Definições gerais';
L10n::$locales['Fonts'] = 'Fontes';
L10n::$locales['Main text'] = 'Texto principal';
L10n::$locales['Main font:'] = 'Fonte principal:';
L10n::$locales['Set to Default to use a webfont.'] = 'Defina como Predefinição para utilizar uma fonte web.';
L10n::$locales['Webfont family:'] = 'Família Webfont:';
L10n::$locales['Webfont URL:'] = 'URL do Webfont:';
L10n::$locales['Webfont API:'] = 'API Webfont:';
L10n::$locales['Secondary text'] = 'Texto secundário';
L10n::$locales['Secondary font:'] = 'Tipo de letra secundário:';
L10n::$locales['Titles'] = 'Títulos';
L10n::$locales['Blog title'] = 'Título do blogue';
L10n::$locales['In bold:'] = 'Em negrito:';
L10n::$locales['Font size (in em by default):'] = 'Tamanho do tipo de letra (em em por defeito):';
L10n::$locales['Color:'] = 'Cor:';
L10n::$locales['Post title'] = 'Título da publicação';
L10n::$locales['Titles without link'] = 'Títulos sem ligação';
L10n::$locales['Inside posts links'] = 'Ligações para os artigos internos';
L10n::$locales['Normal and visited links color:'] = 'Cor das ligações normais e visitadas:';
L10n::$locales['Active, hover and focus links color:'] = 'Cor das hiperligações activas, de foco e de passagem:';
L10n::$locales['Mobile specific settings'] = 'Definições específicas do telemóvel';
