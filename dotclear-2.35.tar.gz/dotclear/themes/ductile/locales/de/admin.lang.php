<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Vollständig';
L10n::$locales['Home (first page)'] = 'Startseite (erste Seite)';
L10n::$locales['Home (other pages)'] = 'Home (andere Seiten)';
L10n::$locales['Entries for a category'] = 'Eingaben für eine Kategorie';
L10n::$locales['Entries for a tag'] = 'Eingaben für einen Tag';
L10n::$locales['Search result entries'] = 'Suchergebnis-Einträge';
L10n::$locales['Month archive entries'] = 'Monatliche Archiveinträge';
L10n::$locales['Ductile primary'] = 'Duktil primär';
L10n::$locales['Ductile secondary'] = 'Duktil sekundär';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = 'Georgien';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'Auswirkungen';
L10n::$locales['Monospace'] = 'Monospace';
L10n::$locales['none'] = 'keine';
L10n::$locales['javascript (Adobe)'] = 'javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'Stylesheet (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'Die Konfiguration des Themas wurde aktualisiert.';
L10n::$locales['Font family'] = 'Schriftfamilie';
L10n::$locales['Header'] = 'Kopfzeile';
L10n::$locales['Hide blog description:'] = 'Blogbeschreibung ausblenden:';
L10n::$locales['Logo URL:'] = 'Logo URL:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'Um das Top-Menü zu konfigurieren, gehen Sie auf die Verwaltungsseite <a href="%s">Simple Menu</a>.';
L10n::$locales['Stickers'] = 'Aufkleber';
L10n::$locales['Stickers (footer)'] = 'Aufkleber (Fußzeile)';
L10n::$locales['Image'] = 'Bild';
L10n::$locales['Entries list types and limits'] = 'Eintragslistenarten und -grenzen';
L10n::$locales['Entries lists'] = 'Listen mit Einträgen';
L10n::$locales['Context'] = 'Kontext';
L10n::$locales['Entries list type'] = 'Typ der Eintragsliste';
L10n::$locales['Miscellaneous options'] = 'Verschiedene Optionen';
L10n::$locales['Comment preview is not mandatory:'] = 'Die Vorschau der Kommentare ist nicht obligatorisch:';
L10n::$locales['Presentation'] = 'Präsentation';
L10n::$locales['General settings'] = 'Allgemeine Einstellungen';
L10n::$locales['Fonts'] = 'Schriftarten';
L10n::$locales['Main text'] = 'Haupttext';
L10n::$locales['Main font:'] = 'Hauptschriftart:';
L10n::$locales['Set to Default to use a webfont.'] = 'Setzen Sie diese Option auf Standard, um einen Webfont zu verwenden.';
L10n::$locales['Webfont family:'] = 'Webfont-Familie:';
L10n::$locales['Webfont URL:'] = 'Webfont-URL:';
L10n::$locales['Webfont API:'] = 'Webfont-API:';
L10n::$locales['Secondary text'] = 'Sekundärer Text';
L10n::$locales['Secondary font:'] = 'Sekundäre Schriftart:';
L10n::$locales['Titles'] = 'Titel';
L10n::$locales['Blog title'] = 'Blog-Titel';
L10n::$locales['In bold:'] = 'Fett gedruckt:';
L10n::$locales['Font size (in em by default):'] = 'Schriftgröße (standardmäßig in em):';
L10n::$locales['Color:'] = 'Farbe:';
L10n::$locales['Post title'] = 'Titel des Beitrags';
L10n::$locales['Titles without link'] = 'Titel ohne Link';
L10n::$locales['Inside posts links'] = 'Links zu Innenstellen';
L10n::$locales['Normal and visited links color:'] = 'Farbe der normalen und besuchten Links:';
L10n::$locales['Active, hover and focus links color:'] = 'Farbe der aktiven, schwebenden und fokussierten Links:';
L10n::$locales['Mobile specific settings'] = 'Handy-spezifische Einstellungen';
