<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Visas';
L10n::$locales['Home (first page)'] = 'Pradžia (pirmasis puslapis)';
L10n::$locales['Home (other pages)'] = 'Pradžia (kiti puslapiai)';
L10n::$locales['Entries for a category'] = 'Kategorijos įrašai';
L10n::$locales['Entries for a tag'] = 'Žymos įrašai';
L10n::$locales['Search result entries'] = 'Paieškos rezultatų įrašai';
L10n::$locales['Month archive entries'] = 'Mėnesio archyvo įrašai';
L10n::$locales['Ductile primary'] = 'Pirminis plastiškumas';
L10n::$locales['Ductile secondary'] = 'Kietasis antrinis';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = 'Gruzija';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'Poveikis';
L10n::$locales['Monospace'] = 'Monospace';
L10n::$locales['none'] = 'nėra';
L10n::$locales['javascript (Adobe)'] = 'javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'stilių rinkinys (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'Atnaujinta temos konfigūracija.';
L10n::$locales['Font family'] = 'Šriftų šeima';
L10n::$locales['Header'] = 'Antraštė';
L10n::$locales['Hide blog description:'] = 'Paslėpti tinklaraščio aprašymą:';
L10n::$locales['Logo URL:'] = 'Logotipo URL:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'Norėdami konfigūruoti viršutinį meniu, eikite į <a href="%s">paprastojo meniu administravimo puslapį</a>.';
L10n::$locales['Stickers'] = 'Lipdukai';
L10n::$locales['Stickers (footer)'] = 'Lipdukai (poraštė)';
L10n::$locales['Image'] = 'Vaizdas';
L10n::$locales['Entries list types and limits'] = 'Įrašų sąrašo tipai ir ribos';
L10n::$locales['Entries lists'] = 'Įrašų sąrašai';
L10n::$locales['Context'] = 'Kontekstas';
L10n::$locales['Entries list type'] = 'Įrašų sąrašo tipas';
L10n::$locales['Miscellaneous options'] = 'Įvairios parinktys';
L10n::$locales['Comment preview is not mandatory:'] = 'Komentarų peržiūra nėra privaloma:';
L10n::$locales['Presentation'] = 'Pristatymas';
L10n::$locales['General settings'] = 'Bendrieji nustatymai';
L10n::$locales['Fonts'] = 'Šriftai';
L10n::$locales['Main text'] = 'Pagrindinis tekstas';
L10n::$locales['Main font:'] = 'Pagrindinis šriftas:';
L10n::$locales['Set to Default to use a webfont.'] = 'Nustatykite Numatytoji reikšmė, jei norite naudoti žiniatinklio šriftą.';
L10n::$locales['Webfont family:'] = 'Žiniatinklio šriftų šeima:';
L10n::$locales['Webfont URL:'] = 'Interneto šrifto URL:';
L10n::$locales['Webfont API:'] = 'Webfont API:';
L10n::$locales['Secondary text'] = 'Antrinis tekstas';
L10n::$locales['Secondary font:'] = 'Antrinis šriftas:';
L10n::$locales['Titles'] = 'Pavadinimai';
L10n::$locales['Blog title'] = 'Tinklaraščio pavadinimas';
L10n::$locales['In bold:'] = 'Paryškintu šriftu:';
L10n::$locales['Font size (in em by default):'] = 'Šrifto dydis (pagal numatytuosius nustatymus - em):';
L10n::$locales['Color:'] = 'Spalva:';
L10n::$locales['Post title'] = 'Pranešimo pavadinimas';
L10n::$locales['Titles without link'] = 'Pavadinimai be nuorodos';
L10n::$locales['Inside posts links'] = 'Vidiniai pranešimai nuorodos';
L10n::$locales['Normal and visited links color:'] = 'Įprasta ir aplankytų nuorodų spalva:';
L10n::$locales['Active, hover and focus links color:'] = 'Aktyvių, užvedimo ir fokusavimo nuorodų spalva:';
L10n::$locales['Mobile specific settings'] = 'Specifiniai mobiliojo telefono nustatymai';
