<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'كامل';
L10n::$locales['Home (first page)'] = 'الصفحة الرئيسية (الصفحة الأولى)';
L10n::$locales['Home (other pages)'] = 'الصفحة الرئيسية (صفحات أخرى)';
L10n::$locales['Entries for a category'] = 'إدخالات لفئة';
L10n::$locales['Entries for a tag'] = 'إدخالات العلامة';
L10n::$locales['Search result entries'] = 'إدخالات نتائج البحث';
L10n::$locales['Month archive entries'] = 'إدخالات أرشيف الشهر';
L10n::$locales['Ductile primary'] = 'الدوتيل الأساسي';
L10n::$locales['Ductile secondary'] = 'ثانوية الدوتيل';
L10n::$locales['Times New Roman'] = 'أوقات رومانية جديدة';
L10n::$locales['Georgia'] = 'جورجيا';
L10n::$locales['Garamond'] = 'غاراموند';
L10n::$locales['Helvetica/Arial'] = 'هيلفيتيكا/ريال';
L10n::$locales['Verdana'] = 'فردانا';
L10n::$locales['Trebuchet MS'] = 'ميغابايت';
L10n::$locales['Impact'] = 'التأثير';
L10n::$locales['Monospace'] = 'فضاء أحادي';
L10n::$locales['none'] = 'لا';
L10n::$locales['javascript (Adobe)'] = 'جافا سكريبت (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'stylesheet (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'تم ترقية تكوين السمة.';
L10n::$locales['Font family'] = 'عائلة الخط';
L10n::$locales['Header'] = 'رأس';
L10n::$locales['Hide blog description:'] = 'إخفاء وصف المدونة:';
L10n::$locales['Logo URL:'] = 'رابط الشعار:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'لتكوين القائمة العلوية انتقل إلى <a href="%s">صفحة إدارة القائمة البسيطة</a>.';
L10n::$locales['Stickers'] = 'ملصقات';
L10n::$locales['Stickers (footer)'] = 'ملصقات (تذييل)';
L10n::$locales['Image'] = 'صورة';
L10n::$locales['Entries list types and limits'] = 'أنواع وحدود قائمة المدخلات';
L10n::$locales['Entries lists'] = 'قوائم الإدخالات';
L10n::$locales['Context'] = 'السياق';
L10n::$locales['Entries list type'] = 'نوع قائمة المدخلات';
L10n::$locales['Miscellaneous options'] = 'خيارات متنوعة';
L10n::$locales['Comment preview is not mandatory:'] = 'معاينة التعليق ليست إلزامية:';
L10n::$locales['Presentation'] = 'عرض';
L10n::$locales['General settings'] = 'الإعدادات العامة';
L10n::$locales['Fonts'] = 'الخطوط';
L10n::$locales['Main text'] = 'النص الرئيسي';
L10n::$locales['Main font:'] = 'الخط الرئيسي:';
L10n::$locales['Set to Default to use a webfont.'] = 'تعيين إلى الافتراضي لاستخدام خط ويب.';
L10n::$locales['Webfont family:'] = 'عائلة الخط الشبكي:';
L10n::$locales['Webfont URL:'] = 'Webfont URL:';
L10n::$locales['Webfont API:'] = 'Webfont API:';
L10n::$locales['Secondary text'] = 'النص الثانوي';
L10n::$locales['Secondary font:'] = 'الخط الثانوي:';
L10n::$locales['Titles'] = 'العناوين';
L10n::$locales['Blog title'] = 'عنوان المدونة';
L10n::$locales['In bold:'] = 'In bold:';
L10n::$locales['Font size (in em by default):'] = 'Font size (in em by default):';
L10n::$locales['Color:'] = 'اللون:';
L10n::$locales['Post title'] = 'عنوان المشاركة';
L10n::$locales['Titles without link'] = 'عناوين بدون رابط';
L10n::$locales['Inside posts links'] = 'داخل روابط المشاركات';
L10n::$locales['Normal and visited links color:'] = 'لون الروابط العادية والزائرة:';
L10n::$locales['Active, hover and focus links color:'] = 'لون الروابط النشطة والمركّزة:';
L10n::$locales['Mobile specific settings'] = 'إعدادات محددة للجوال';
