<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Penuh';
L10n::$locales['Home (first page)'] = 'Beranda (halaman pertama)';
L10n::$locales['Home (other pages)'] = 'Beranda (halaman lain)';
L10n::$locales['Entries for a category'] = 'Entri untuk sebuah kategori';
L10n::$locales['Entries for a tag'] = 'Entri untuk sebuah tag';
L10n::$locales['Search result entries'] = 'Entri hasil pencarian';
L10n::$locales['Month archive entries'] = 'Entri arsip bulan';
L10n::$locales['Ductile primary'] = 'Primer ulet';
L10n::$locales['Ductile secondary'] = 'Sekunder ulet';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = 'Georgia';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'Dampak';
L10n::$locales['Monospace'] = 'Monospace';
L10n::$locales['none'] = 'tidak ada';
L10n::$locales['javascript (Adobe)'] = 'javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'lembar gaya (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'Konfigurasi tema ditingkatkan.';
L10n::$locales['Font family'] = 'Keluarga font';
L10n::$locales['Header'] = 'Header';
L10n::$locales['Hide blog description:'] = 'Sembunyikan deskripsi blog:';
L10n::$locales['Logo URL:'] = 'URL Logo:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'Untuk mengonfigurasi menu atas, buka <a href="%s">halaman administrasi Menu Sederhana</a>.';
L10n::$locales['Stickers'] = 'Stiker';
L10n::$locales['Stickers (footer)'] = 'Stiker (footer)';
L10n::$locales['Image'] = 'Gambar';
L10n::$locales['Entries list types and limits'] = 'Jenis dan batasan daftar entri';
L10n::$locales['Entries lists'] = 'Daftar entri';
L10n::$locales['Context'] = 'Konteks';
L10n::$locales['Entries list type'] = 'Jenis daftar entri';
L10n::$locales['Miscellaneous options'] = 'Opsi lain-lain';
L10n::$locales['Comment preview is not mandatory:'] = 'Pratinjau komentar tidak wajib:';
L10n::$locales['Presentation'] = 'Presentasi';
L10n::$locales['General settings'] = 'Pengaturan umum';
L10n::$locales['Fonts'] = 'Font';
L10n::$locales['Main text'] = 'Teks utama';
L10n::$locales['Main font:'] = 'Jenis huruf utama:';
L10n::$locales['Set to Default to use a webfont.'] = 'Atur ke Default untuk menggunakan font web.';
L10n::$locales['Webfont family:'] = 'Keluarga Webfont:';
L10n::$locales['Webfont URL:'] = 'URL Webfont:';
L10n::$locales['Webfont API:'] = 'API Webfont:';
L10n::$locales['Secondary text'] = 'Teks sekunder';
L10n::$locales['Secondary font:'] = 'Font sekunder:';
L10n::$locales['Titles'] = 'Judul';
L10n::$locales['Blog title'] = 'Judul blog';
L10n::$locales['In bold:'] = 'Cetak tebal:';
L10n::$locales['Font size (in em by default):'] = 'Ukuran font (dalam em secara default):';
L10n::$locales['Color:'] = 'Warna:';
L10n::$locales['Post title'] = 'Judul postingan';
L10n::$locales['Titles without link'] = 'Judul tanpa tautan';
L10n::$locales['Inside posts links'] = 'Tautan posting di dalam';
L10n::$locales['Normal and visited links color:'] = 'Warna tautan normal dan yang dikunjungi:';
L10n::$locales['Active, hover and focus links color:'] = 'Warna tautan aktif, arahkan dan fokus:';
L10n::$locales['Mobile specific settings'] = 'Pengaturan khusus seluler';
