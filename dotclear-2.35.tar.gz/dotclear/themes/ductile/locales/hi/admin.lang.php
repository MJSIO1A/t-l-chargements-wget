<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'पूर्ण';
L10n::$locales['Home (first page)'] = 'घर (प्रथम पृष्ठ)';
L10n::$locales['Home (other pages)'] = 'घर (अन्य पृष्ठ)';
L10n::$locales['Entries for a category'] = 'एक श्रेणी के लिए प्रविष्टियां';
L10n::$locales['Entries for a tag'] = 'टैग के लिए प्रविष्टियाँ';
L10n::$locales['Search result entries'] = 'खोज परिणाम प्रविष्टियों';
L10n::$locales['Month archive entries'] = 'मासिक अभिलेख प्रविष्टि';
L10n::$locales['Ductile primary'] = 'नलिकाकार प्राथमिक';
L10n::$locales['Ductile secondary'] = 'द्विचर द्वितीयक';
L10n::$locales['Times New Roman'] = 'टाइम्स न्यू रोमन';
L10n::$locales['Georgia'] = 'जार्जिया';
L10n::$locales['Garamond'] = 'गरमण्ड';
L10n::$locales['Helvetica/Arial'] = 'हेल्वेटिका/अरिमल';
L10n::$locales['Verdana'] = 'वरदाना';
L10n::$locales['Trebuchet MS'] = 'ट्रेबुसेट एमएस';
L10n::$locales['Impact'] = 'प्रभाव';
L10n::$locales['Monospace'] = 'मोनोस्पेस';
L10n::$locales['none'] = 'कोई नहीं';
L10n::$locales['javascript (Adobe)'] = 'Javascript (एडोब)';
L10n::$locales['stylesheet (Google)'] = 'स्टाइलशीट (गूगल)';
L10n::$locales['Theme configuration upgraded.'] = 'प्रसंग विन्यास उन्नत.';
L10n::$locales['Font family'] = 'फ़ॉन्ट परिवार';
L10n::$locales['Header'] = 'शीर्षिका';
L10n::$locales['Hide blog description:'] = 'ब्लॉग विवरण छुपाएं:';
L10n::$locales['Logo URL:'] = 'लोगो यूआरएलः';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'शीर्ष मेनू को कॉन्फ़िगर करने के लिए, <a href="%s">सरल मेनू व्यवस्थापन पृष्ठ पर जाएँ</a>.';
L10n::$locales['Stickers'] = 'स्टिकर';
L10n::$locales['Stickers (footer)'] = 'स्टिकर (पाद)';
L10n::$locales['Image'] = 'छवि';
L10n::$locales['Entries list types and limits'] = 'प्रविष्टियों सूची प्रकार और सीमा';
L10n::$locales['Entries lists'] = 'प्रविष्टियों की सूची';
L10n::$locales['Context'] = 'संदर्भ';
L10n::$locales['Entries list type'] = 'प्रविष्टियों सूची प्रकार';
L10n::$locales['Miscellaneous options'] = 'विविध विकल्प';
L10n::$locales['Comment preview is not mandatory:'] = 'टिप्पणी पूर्वावलोकन अनिवार्य नहीं है:';
L10n::$locales['Presentation'] = 'प्रस्तुतीकरण';
L10n::$locales['General settings'] = 'सामान्य विन्यास';
L10n::$locales['Fonts'] = 'फ़ॉन्ट्स';
L10n::$locales['Main text'] = 'मुख्य पाठ';
L10n::$locales['Main font:'] = 'मुख्य फ़ॉन्टः';
L10n::$locales['Set to Default to use a webfont.'] = 'वेब फ़ॉन्ट का उपयोग करने के लिए डिफ़ॉल्ट पर सेट करें.';
L10n::$locales['Webfont family:'] = 'वेबफ़ॉन्ट परिवार:';
L10n::$locales['Webfont URL:'] = 'वेबफान्ट यूआरएलः';
L10n::$locales['Webfont API:'] = 'वेबफाक्स एपीआई:';
L10n::$locales['Secondary text'] = 'द्वितीयक पाठ';
L10n::$locales['Secondary font:'] = 'द्वितीयक फ़ॉन्ट:';
L10n::$locales['Titles'] = 'शीर्षक';
L10n::$locales['Blog title'] = 'ब्लॉग शीर्षक';
L10n::$locales['In bold:'] = 'बोल्ड में:';
L10n::$locales['Font size (in em by default):'] = 'फ़ॉन्ट आकार (उन्हें डिफ़ॉल्ट रूप से में):';
L10n::$locales['Color:'] = 'रंगः';
L10n::$locales['Post title'] = 'पोस्ट शीर्षक';
L10n::$locales['Titles without link'] = 'लिंक के बिना शीर्षक';
L10n::$locales['Inside posts links'] = 'आंतरिक लिंक लिंक';
L10n::$locales['Normal and visited links color:'] = 'सामान्य और देखा लिंक रंग:';
L10n::$locales['Active, hover and focus links color:'] = 'सक्रिय, हॉवर और फोकस लिंक रंग:';
L10n::$locales['Mobile specific settings'] = 'मोबाइल विशिष्ट सेटिंग्स';
