<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = 'Teljes';
L10n::$locales['Home (first page)'] = 'Főoldal (első oldal)';
L10n::$locales['Home (other pages)'] = 'Főoldal (egyéb oldalak)';
L10n::$locales['Entries for a category'] = 'Egy kategória bejegyzései';
L10n::$locales['Entries for a tag'] = 'Bejegyzések egy címkéhez';
L10n::$locales['Search result entries'] = 'Keresés eredménye bejegyzések';
L10n::$locales['Month archive entries'] = 'Havi archív bejegyzések';
L10n::$locales['Ductile primary'] = 'Duktilis elsődleges';
L10n::$locales['Ductile secondary'] = 'Duktilis másodlagos';
L10n::$locales['Times New Roman'] = 'Times New Roman';
L10n::$locales['Georgia'] = 'Georgia';
L10n::$locales['Garamond'] = 'Garamond';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'Hatás';
L10n::$locales['Monospace'] = 'Monospace';
L10n::$locales['none'] = 'nincs';
L10n::$locales['javascript (Adobe)'] = 'javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'stílustábla (Google)';
L10n::$locales['Theme configuration upgraded.'] = 'Téma konfiguráció frissítve.';
L10n::$locales['Font family'] = 'Betűcsalád';
L10n::$locales['Header'] = 'Fejléc';
L10n::$locales['Hide blog description:'] = 'Blog leírás elrejtése:';
L10n::$locales['Logo URL:'] = 'Logó URL:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'A felső menü konfigurálásához lépjen a <a href="%s">Simple Menu adminisztrációs oldalra</a>.';
L10n::$locales['Stickers'] = 'Matricák';
L10n::$locales['Stickers (footer)'] = 'Matricák (lábléc)';
L10n::$locales['Image'] = 'Kép';
L10n::$locales['Entries list types and limits'] = 'Bejegyzések listatípusok és korlátozások';
L10n::$locales['Entries lists'] = 'Bejegyzések listái';
L10n::$locales['Context'] = 'Kontextus';
L10n::$locales['Entries list type'] = 'Bejegyzések listájának típusa';
L10n::$locales['Miscellaneous options'] = 'Egyéb lehetőségek';
L10n::$locales['Comment preview is not mandatory:'] = 'A megjegyzés előnézet nem kötelező:';
L10n::$locales['Presentation'] = 'Bemutatkozás';
L10n::$locales['General settings'] = 'Általános beállítások';
L10n::$locales['Fonts'] = 'Betűtípusok';
L10n::$locales['Main text'] = 'Fő szöveg';
L10n::$locales['Main font:'] = 'Fő betűtípus:';
L10n::$locales['Set to Default to use a webfont.'] = 'A webes betűtípus használatához állítsa be az alapértelmezett értéket.';
L10n::$locales['Webfont family:'] = 'Webfont család:';
L10n::$locales['Webfont URL:'] = 'Webfont URL:';
L10n::$locales['Webfont API:'] = 'Webfont API:';
L10n::$locales['Secondary text'] = 'Másodlagos szöveg';
L10n::$locales['Secondary font:'] = 'Másodlagos betűtípus:';
L10n::$locales['Titles'] = 'Címek';
L10n::$locales['Blog title'] = 'Blog címe';
L10n::$locales['In bold:'] = 'Félkövérrel:';
L10n::$locales['Font size (in em by default):'] = 'Betűméret (alapértelmezés szerint em-ben):';
L10n::$locales['Color:'] = 'Szín:';
L10n::$locales['Post title'] = 'A poszt címe';
L10n::$locales['Titles without link'] = 'Címek link nélkül';
L10n::$locales['Inside posts links'] = 'Belső hozzászólások linkek';
L10n::$locales['Normal and visited links color:'] = 'Normál és látogatott linkek színe:';
L10n::$locales['Active, hover and focus links color:'] = 'Aktív, lebegő és fókusz linkek színe:';
L10n::$locales['Mobile specific settings'] = 'Mobil specifikus beállítások';
