<?php
/**
 * @package Dotclear
 *
 * @copyright Olivier Meunier & Association Dotclear
 */
#
# DOT NOT MODIFY THIS FILE !
#

use Dotclear\Helper\L10n;

L10n::$locales['Full'] = '@ option: radio';
L10n::$locales['Home (first page)'] = 'হোম (প্রথম পৃষ্ঠা)';
L10n::$locales['Home (other pages)'] = 'বাড়ির (অন্যান্য পাতা)';
L10n::$locales['Entries for a category'] = 'একটি শ্রেণীতে এন্ট্রি';
L10n::$locales['Entries for a tag'] = 'একটি ট্যাগের জন্য প্রচেষ্টা';
L10n::$locales['Search result entries'] = 'অনুসন্ধানের ফলাফল এন্ট্রি';
L10n::$locales['Month archive entries'] = 'মাস আর্কাইভ এন্ট্রি';
L10n::$locales['Ductile primary'] = 'Ductile প্রাথমিক';
L10n::$locales['Ductile secondary'] = 'Ductile সেকেন্ডারি';
L10n::$locales['Times New Roman'] = 'টাইমস নিউ রোমান';
L10n::$locales['Georgia'] = 'জর্জিয়া';
L10n::$locales['Garamond'] = 'গ্যারামন্ড';
L10n::$locales['Helvetica/Arial'] = 'Helvetica/Arial';
L10n::$locales['Verdana'] = 'Verdana';
L10n::$locales['Trebuchet MS'] = 'Trebuchet MS';
L10n::$locales['Impact'] = 'ইমপ্যাক্ট';
L10n::$locales['Monospace'] = 'Monospace';
L10n::$locales['none'] = 'কেউই';
L10n::$locales['javascript (Adobe)'] = 'Javascript (Adobe)';
L10n::$locales['stylesheet (Google)'] = 'Stylesheet (গুগল)';
L10n::$locales['Theme configuration upgraded.'] = 'থিম কনফিগারেশন উন্নীত করা হয়েছে.';
L10n::$locales['Font family'] = 'ফন্ট পরিবার';
L10n::$locales['Header'] = 'শীর্ষচরণ';
L10n::$locales['Hide blog description:'] = 'ব্লগ বর্ণনা আড়াল করা হবে:';
L10n::$locales['Logo URL:'] = 'লোগো ইউ-আর-এল:';
L10n::$locales['To configure the top menu go to the <a href="%s">Simple Menu administration page</a>.'] = 'শীর্ষ মেনুটি কনফিগার করতে <a href="%s">Simple Menu প্রশাসন পৃষ্ঠায় যান</a>।';
L10n::$locales['Stickers'] = 'Stickers';
L10n::$locales['Stickers (footer)'] = 'Stickers (footer)';
L10n::$locales['Image'] = 'ছবি';
L10n::$locales['Entries list types and limits'] = 'তালিকার ধরন এবং সীমা';
L10n::$locales['Entries lists'] = 'এন্ট্রি তালিকা';
L10n::$locales['Context'] = 'কনটেক্সট';
L10n::$locales['Entries list type'] = 'প্রচেষ্টা তালিকার ধরন';
L10n::$locales['Miscellaneous options'] = 'বিবিধ অপশন';
L10n::$locales['Comment preview is not mandatory:'] = 'মন্তব্য প্রাকদর্শন বাধ্যতামূলক নয়:';
L10n::$locales['Presentation'] = 'উপস্থাপনা';
L10n::$locales['General settings'] = 'সাধারণ বৈশিষ্ট্য';
L10n::$locales['Fonts'] = 'ফন্ট';
L10n::$locales['Main text'] = 'মূল টেক্সট';
L10n::$locales['Main font:'] = 'প্রধান ফন্ট:';
L10n::$locales['Set to Default to use a webfont.'] = 'একটি ওয়েব ফন্ট ব্যবহার করার জন্য ডিফল্ট নির্ধারণ করুন.';
L10n::$locales['Webfont family:'] = 'ওয়েবফন্ট পরিবার:';
L10n::$locales['Webfont URL:'] = 'ওয়েব ফন্ট ইউ-আর-এল:';
L10n::$locales['Webfont API:'] = 'ওয়েবফন্ট API:';
L10n::$locales['Secondary text'] = 'দ্বিতীয় টেক্সট';
L10n::$locales['Secondary font:'] = 'দ্বিতীয় ফন্ট:';
L10n::$locales['Titles'] = 'টাইটেল';
L10n::$locales['Blog title'] = 'ব্লগ শিরোনাম';
L10n::$locales['In bold:'] = 'সাহসী:';
L10n::$locales['Font size (in em by default):'] = 'ফন্ট মাপ (ডিফল্ট দ্বারা তাদের মধ্যে):';
L10n::$locales['Color:'] = 'রং:';
L10n::$locales['Post title'] = 'পোস্টের শিরোনাম';
L10n::$locales['Titles without link'] = 'লিঙ্ক ছাড়াই টাইটেল';
L10n::$locales['Inside posts links'] = 'ইনসাইড পোস্টের লিঙ্ক';
L10n::$locales['Normal and visited links color:'] = 'স্বাভাবিক এবং পরিদর্শিত লিংক রং:';
L10n::$locales['Active, hover and focus links color:'] = 'সক্রিয়, hover এবং ফোকাস লিংক রং:';
L10n::$locales['Mobile specific settings'] = 'মোবাইল নির্দিষ্ট সেটিংস';
